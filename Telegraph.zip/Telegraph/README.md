# Telegraph — تلگراف

A production-oriented, Persian (RTL) realtime messaging app that deploys as **one Cloudflare Worker**:
Workers + D1 + R2 + Durable Objects (WebSockets) + Web Crypto. No external services, no build step.

> **Encryption honesty:** messages and filenames are encrypted **server-side at rest** (AES-256-GCM). The server can read
> plaintext while processing a request. This is **not** end-to-end encryption. See [SECURITY.md](SECURITY.md).

## Features
- Accounts (PBKDF2-SHA256 passwords, hashed server-side session tokens, HttpOnly cookie, rate limiting)
- Chats: create, rename, delete/leave, members, pagination, reply, edit, delete, copy, pin, sent/delivered/read, presence, typing
- Message priority: normal (white), good (green), important (yellow), critical (red) — the sender taps a message to change it; "!" notification badge uses the same color
- Attachments (R2): images (lightbox), video (player), PDF and documents (cards), upload progress, paste / drag-and-drop
- Voice messages (MediaRecorder): record / cancel / send / playback
- Timed messages: 30 s, 5 min, 1 h, 24 h, custom — enforced server-side, R2 objects removed, cron purge every 5 min
- Search: chat titles, message text (blind index), attachment filenames, priority filter
- Dark, responsive UI. Desktop: sidebar on the left. Mobile: drawer, New Chat on the right of the header, menu on the left, keyboard-aware composer

## Layout
```
worker.js            entry: fetch + scheduled + Durable Object exports
wrangler.toml        bindings: DB, FILES, CHAT_ROOM, USER_HUB, ASSETS
schema.sql           consolidated schema (same as migrations/*)
migrations/          0001_init.sql, 0002_search_keys_ratelimit.sql
src/api, auth, chat, files, notifications, realtime, security, ui
public/              static frontend (ES modules, no inline script/style) + logo/
test/                Node smoke tests (D1/R2/DO shims)
scripts/             check-syntax.mjs, check-frontend.mjs
```

## Deploy (Cloudflare)
Requires Node 20+ and a Cloudflare account (the Workers **Paid** plan is recommended: Durable Objects with SQLite and R2 are used).

```bash
npm install
npx wrangler login

# 1. Database
npx wrangler d1 create telegraph-db
#    -> copy the printed database_id into wrangler.toml  ([[d1_databases]] database_id)

# 2. File storage
npx wrangler r2 bucket create telegraph-files

# 3. Secrets (generate two different 32-byte keys)
openssl rand -base64 32          # -> use as the value for key "1" in MASTER_KEYS
openssl rand -base64 32          # -> INDEX_KEY
npx wrangler secret put MASTER_KEYS    # paste JSON, e.g. {"1":"<base64-key>"}
npx wrangler secret put INDEX_KEY      # paste the base64 key

# 4. Schema
npx wrangler d1 migrations apply telegraph-db --remote

# 5. Ship it
npx wrangler deploy
```
Open the printed `*.workers.dev` URL, register, and start chatting. To close sign-ups afterwards set `REGISTRATION_OPEN = "false"` in `wrangler.toml` and redeploy.
If you use a custom domain, set `APP_ORIGIN = "https://chat.example.com"` for a strict Origin check.

## Local development
```bash
cp .dev.vars.example .dev.vars        # then put real random keys in it (never commit it)
npm run db:migrate:local
npm run dev                           # http://localhost:8787
```
Tests (Node 22+, uses built-in SQLite; no Cloudflare needed): `npm test` and `npm run check`.

## Key rotation (server-side encryption)
Ciphertext is stored as `enc1:<keyId>:<iv>:<ciphertext>`, so old data stays readable after rotating.
1. Generate a new key and add it: `MASTER_KEYS = {"1":"<old>","2":"<new>"}` (`wrangler secret put MASTER_KEYS`).
2. Set `ACTIVE_KEY_ID = "2"` in `wrangler.toml` and redeploy. New data uses key 2; old data still decrypts with key 1.
3. Never delete a key that still protects stored data. Rotating `INDEX_KEY` invalidates message search for existing messages.

## Limits
| Type | Max size |
|---|---|
| Images (jpeg, png, gif, webp) | 15 MB |
| Video (mp4, mov, webm) | 50 MB |
| Audio / voice | 20 MB (voice recording capped at 5 min) |
| PDF | 30 MB |
| Office docs, zip | 25 MB (zip is download-only) |
| txt / csv | 5 MB |

Uploads are streamed straight to R2 (raw body, `Content-Length` required), so the Worker never buffers whole files; the platform request-body ceiling (100 MB on Free/Pro) is above every limit here.
Passwords use PBKDF2-SHA256 at **100,000 iterations** — the maximum Workers' Web Crypto accepts.

## Not verified on real Cloudflare
The code was exercised end-to-end with Node shims for D1/R2/Durable Objects (48 checks), and statically cross-checked
(routes, WebSocket events, bindings, CSP rules). It has **not** been run on live Cloudflare or in a browser during
authoring, so expect to do a first-deploy smoke test and possibly small adjustments.
Drop the Vazirmatn font into `public/fonts` for the intended typography (see `public/fonts/README.md`).
