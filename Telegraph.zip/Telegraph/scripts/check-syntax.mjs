// Verifies every JS module parses and every relative import resolves to an existing file.
import { readdirSync, readFileSync, existsSync, statSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { execFileSync } from 'node:child_process';

const root = new URL('..', import.meta.url).pathname;
const files = [];
(function walk(d) {
  for (const f of readdirSync(d)) {
    if (f === 'node_modules' || f.startsWith('.')) continue;
    const p = join(d, f);
    if (statSync(p).isDirectory()) walk(p);
    else if (/\.(m?js)$/.test(f)) files.push(p);
  }
})(root);

let bad = 0;
for (const f of files) {
  try { execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' }); }
  catch (e) { bad++; console.error('SYNTAX', f, String(e.stderr).split('\n').slice(0, 4).join('\n')); }
  const src = readFileSync(f, 'utf8');
  for (const m of src.matchAll(/(?:import|export)[^'"`]*?from\s+['"]([^'"]+)['"]|import\(['"]([^'"]+)['"]\)/g)) {
    const spec = m[1] || m[2];
    if (!spec.startsWith('.') && !spec.startsWith('/')) continue;
    const target = spec.startsWith('/') ? join(root, 'public', spec) : resolve(dirname(f), spec);
    if (!existsSync(target)) { bad++; console.error('MISSING IMPORT', f, '->', spec); }
  }
}
console.log(`${files.length} files checked, ${bad} problems`);
process.exit(bad ? 1 : 0);
