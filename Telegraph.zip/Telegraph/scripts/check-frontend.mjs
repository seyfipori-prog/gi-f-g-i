// Static consistency check: frontend API paths vs the router table, WS events vs server emits, wrangler bindings vs code.
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
const root = new URL('..', import.meta.url).pathname;
const read = (p) => readFileSync(join(root, p), 'utf8');
const walk = (d) => readdirSync(join(root, d)).flatMap((f) => { const p = join(d, f); return statSync(join(root, p)).isDirectory() ? walk(p) : [p]; });
let bad = 0; const fail = (m) => { bad++; console.error('  FAIL', m); };

// 1. API paths
const router = read('src/api/router.js');
const routes = [...router.matchAll(/\['(GET|POST|PATCH|PUT|DELETE)', '([^']+)'/g)].map(([, m, p]) => ({ m, re: new RegExp('^' + p.replace(/:[a-zA-Z]+/g, '[^/]+') + '$') }));
const api = read('public/js/api.js');
for (const mm of api.matchAll(/request\('(GET|POST|PATCH|PUT|DELETE)', [`']([^`'?$]*(?:\$\{[^}]+\}[^`'?$]*)*)/g)) {
  const path = mm[2].replace(/\$\{[^}]+\}/g, 'x');
  if (!routes.some((r) => r.m === mm[1] && r.re.test(path))) fail(`api.js ${mm[1]} ${path} has no route`);
}
if (!routes.some((r) => r.m === 'POST' && r.re.test('/api/files'))) fail('upload route missing');

// 2. WS events handled by the client must be emitted by the server
const emitted = new Set();
for (const f of walk('src')) for (const m of read(f).matchAll(/type: '([a-z.]+)'/g)) emitted.add(m[1]);
const client = read('public/js/views/chat.js') + read('public/js/app.js');
for (const m of client.matchAll(/case '([a-z.]+)'/g)) if (!emitted.has(m[1])) fail(`client handles '${m[1]}' but server never emits it`);
for (const m of client.matchAll(/m\.type === '([a-z.]+)'/g)) if (!emitted.has(m[1])) fail(`client handles '${m[1]}' but server never emits it`);

// 3. bindings
const wr = read('wrangler.toml');
const code = walk('src').map(read).join('\n') + read('worker.js');
for (const b of ['DB', 'FILES', 'CHAT_ROOM', 'USER_HUB', 'ASSETS']) {
  if (!new RegExp(`(binding|name)\\s*=\\s*"${b}"`).test(wr)) fail(`wrangler.toml lacks binding ${b}`);
  if (!new RegExp(`env\\.${b}\\b`).test(code)) fail(`code never uses env.${b}`);
}
for (const c of ['ChatRoom', 'UserHub']) if (!new RegExp(`export\\s+(\\{[^}]*\\b${c}\\b|class ${c})`).test(read('worker.js'))) fail(`worker.js does not export ${c}`);

// 4. CSP-safety: no inline handlers / inline scripts / style attributes in HTML or setAttribute('style')
const html = read('public/index.html');
if (/\son[a-z]+=|<script(?![^>]*src=)|\sstyle=/.test(html)) fail('index.html has inline script/handler/style');
for (const f of walk('public/js')) if (/setAttribute\(\s*['"]style|\.innerHTML\s*=|insertAdjacentHTML|\beval\(|new Function/.test(read(f))) fail(`${f}: unsafe DOM/CSP pattern`);
// 5. referenced assets exist
for (const m of html.matchAll(/(?:href|src)="(\/[^"]+)"/g)) { try { statSync(join(root, 'public', m[1])); } catch { fail(`index.html references missing ${m[1]}`); } }

console.log(bad ? `${bad} problem(s)` : 'frontend/server consistency OK');
process.exit(bad ? 1 : 0);
