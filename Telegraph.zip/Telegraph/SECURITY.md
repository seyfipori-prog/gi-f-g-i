# Telegraph security notes

## What is protected today
| Layer | Implementation |
|---|---|
| Transport | HTTPS/WSS (Cloudflare), HSTS on https |
| Passwords | PBKDF2-SHA256, 100k iterations (Workers limit), per-user salt, constant-time compare, dummy verify for unknown users |
| Sessions | random 256-bit token in HttpOnly, SameSite cookie; only the SHA-256 hash is stored; sliding expiry with 30-day absolute cap; logout closes sockets |
| CSRF | custom header `x-telegraph-request: 1` + `Origin` check on every API call and WebSocket upgrade |
| Browser hardening | strict CSP (no inline script/style, same-origin only), nosniff, frame-ancestors none, no-referrer, COOP/CORP |
| Authorization | membership checked on every chat/message/file/WebSocket action; owner-only actions; sender-only edit/priority/expiry/delete |
| Files | MIME allow-list, per-type size limits, magic-number validation while streaming, sanitized filenames, random R2 keys (never exposed), authorized + range-aware downloads, `scanFile` hook for AV integration |
| Abuse | D1 fixed-window rate limits (login, register, upload, WebSocket) |
| Expiry | `expires_at` enforced on every read, DO alarm for live rooms, cron purge deletes rows **and** R2 objects |

## Server-side encryption at rest (implemented) — NOT end-to-end
- Message bodies, attachment filenames and notification previews are encrypted with AES-256-GCM.
- Per-chat keys are derived with HKDF from a master key (`MASTER_KEYS`, a Worker secret); the ciphertext is bound to its row via AAD, so it cannot be swapped between rows.
- Search uses an HMAC **blind index** of normalized words (`INDEX_KEY`): the database never holds searchable plaintext, but it does leak which messages share a word.
- **The Worker holds the keys and sees plaintext** while handling requests. Anyone who can read Worker secrets plus the database can read messages. Cloudflare and the operator are inside the trust boundary.
- R2 objects are encrypted at rest by Cloudflare; file *contents* are not additionally encrypted by Telegraph.

## True E2EE (scaffold only, disabled)
`public/js/e2ee.js` (`E2EE_ENABLED = false`) and `PUT/GET /api/keys` + the `user_keys` table provide the building blocks. The UI never claims E2EE. To ship it you must still build:
1. **Key generation** — per device ECDH P-256 identity; keep the private key non-extractable in IndexedDB.
2. **Key exchange** — fetch peer public keys (`GET /api/keys/:username`), derive a shared AES-GCM key (ECDH + HKDF); for groups use per-conversation sender keys or MLS.
3. **Per-conversation keys & rotation** — new key on member add/remove; ratchet for forward secrecy.
4. **Authenticated encryption** — AES-GCM with AAD = chat id + message id + sender id; never reuse IVs.
5. **Attachments** — encrypt file bytes client-side with a random key, upload ciphertext, send the key inside the E2EE message.
6. **Identity verification** — safety numbers / QR comparison so the server cannot silently substitute keys.
7. **Trade-offs** — server-side search, notification previews and multi-device history cannot work on ciphertext without client-side indexing.

## Production checklist
- [ ] Unique random `MASTER_KEYS` and `INDEX_KEY`; store them in a password manager; never commit `.dev.vars`
- [ ] `REGISTRATION_OPEN="false"` after onboarding (or add invitations)
- [ ] Custom domain + `APP_ORIGIN`
- [ ] Cloudflare WAF / Turnstile on `/api/auth/*` for bot protection
- [ ] Plug a malware scanner into `scanFile` (`src/files/sniff.js`) if users upload documents from untrusted sources
- [ ] Review `application/zip` (allowed as download-only; remove from `policy.js` if not needed)
- [ ] Monitor with Workers Logs (`observability` is enabled); logs never contain message text
- [ ] Back up D1 (`wrangler d1 export`) and enable R2 lifecycle/versioning as appropriate
- [ ] First live deploy: test two browsers end-to-end (messages, files, voice, expiry, reconnect)
