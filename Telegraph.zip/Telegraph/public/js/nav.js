// Client-side routing: "/" (home) and "/c/<chatId>" (+ optional ?m=<messageId> to jump to a message).
import { bus } from './store.js';
const ID = /^[0-9a-f-]{36}$/i;
export function parseRoute(loc = location) {
  const m = loc.pathname.match(/^\/c\/([^/]+)\/?$/);
  if (m && ID.test(m[1])) return { chatId: m[1], messageId: new URLSearchParams(loc.search).get('m') };
  return { chatId: null, messageId: null };
}
export function go(chatId, messageId = null, { replace = false } = {}) {
  const path = chatId ? `/c/${chatId}${messageId ? '?m=' + encodeURIComponent(messageId) : ''}` : '/';
  if (path !== location.pathname + location.search) history[replace ? 'replaceState' : 'pushState']({}, '', path);
  bus.emit('route', parseRoute());
}
window.addEventListener('popstate', () => bus.emit('route', parseRoute()));
