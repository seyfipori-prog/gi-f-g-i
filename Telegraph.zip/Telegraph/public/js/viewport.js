// Keeps the composer above the on-screen keyboard. `interactive-widget=resizes-content` handles Chrome;
// visualViewport covers iOS Safari. Sets --kb and pins the app to the visual viewport height.
export function initViewport() {
  const vv = window.visualViewport;
  const root = document.documentElement.style;
  if (!vv) return;
  const apply = () => {
    const kb = Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
    root.setProperty('--kb', kb + 'px');
    const app = document.querySelector('.app');
    if (app) { app.style.height = vv.height + 'px'; app.style.top = vv.offsetTop + 'px'; app.style.bottom = 'auto'; }
    if (kb > 80) document.dispatchEvent(new CustomEvent('tg:keyboard'));
  };
  vv.addEventListener('resize', apply); vv.addEventListener('scroll', apply); apply();
}
