import { errText } from './i18n.js';

export class ApiError extends Error {
  constructor(status, code, message) { super(message || errText(code)); this.status = status; this.code = code; }
}
let onUnauthorized = () => {};
export const setUnauthorizedHandler = (fn) => { onUnauthorized = fn; };
const HDR = { 'x-telegraph-request': '1' };

async function request(method, path, body, opts = {}) {
  const init = { method, headers: { ...HDR }, credentials: 'same-origin' };
  if (body !== undefined) { init.headers['content-type'] = 'application/json'; init.body = JSON.stringify(body); }
  let res;
  try { res = await fetch(path, init); } catch { throw new ApiError(0, 'network'); }
  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) {
    const code = data?.error?.code || 'unknown';
    if (res.status === 401 && !opts.quiet && code === 'unauthorized') onUnauthorized();
    throw new ApiError(res.status, code);
  }
  return data;
}
const q = (o) => { const p = new URLSearchParams(); for (const [k, v] of Object.entries(o || {})) if (v != null && v !== '') p.set(k, v); const s = p.toString(); return s ? '?' + s : ''; };

export const api = {
  register: (b) => request('POST', '/api/auth/register', b),
  login: (b) => request('POST', '/api/auth/login', b),
  logout: () => request('POST', '/api/auth/logout', {}),
  me: () => request('GET', '/api/me', undefined, { quiet: true }),
  updateMe: (b) => request('PATCH', '/api/me', b),
  changePassword: (b) => request('POST', '/api/auth/password', b),
  chats: (search) => request('GET', '/api/chats' + q({ q: search })),
  createChat: (b) => request('POST', '/api/chats', b),
  chat: (id) => request('GET', `/api/chats/${id}`),
  renameChat: (id, title) => request('PATCH', `/api/chats/${id}`, { title }),
  deleteChat: (id) => request('DELETE', `/api/chats/${id}`),
  addMember: (id, username) => request('POST', `/api/chats/${id}/members`, { username }),
  removeMember: (id, uid) => request('DELETE', `/api/chats/${id}/members/${uid}`),
  markRead: (id) => request('POST', `/api/chats/${id}/read`, {}),
  messages: (id, before, limit = 30) => request('GET', `/api/chats/${id}/messages` + q({ before, limit })),
  send: (id, b) => request('POST', `/api/chats/${id}/messages`, b),
  edit: (id, body) => request('PATCH', `/api/messages/${id}`, { body }),
  del: (id) => request('DELETE', `/api/messages/${id}`),
  setPriority: (id, priority) => request('PATCH', `/api/messages/${id}/priority`, { priority }),
  setExpiry: (id, ttl_seconds) => request('PATCH', `/api/messages/${id}/expiry`, { ttl_seconds }),
  pin: (id) => request('POST', `/api/messages/${id}/pin`, {}),
  search: (o) => request('GET', '/api/search' + q(o)),
  notifications: (o) => request('GET', '/api/notifications' + q(o)),
  readNotification: (id) => request('PATCH', `/api/notifications/${id}/read`, {}),
  readAllNotifications: () => request('POST', '/api/notifications/read-all', {}),
  discardUpload: (id) => request('DELETE', `/api/files/${id}`),
};

// XHR upload with progress. Raw body + Content-Length (set by the browser) — streams straight to R2.
export function uploadFile(chatId, file, { voice = false, durationMs = 0, onProgress } = {}) {
  let xhr;
  const promise = new Promise((resolve, reject) => {
    xhr = new XMLHttpRequest();
    const qs = q({ chat: chatId, name: file.name || 'file', voice: voice ? '1' : '', duration: voice ? Math.round(durationMs) : '' });
    xhr.open('POST', '/api/files' + qs);
    xhr.setRequestHeader('x-telegraph-request', '1');
    xhr.setRequestHeader('content-type', file.type || 'application/octet-stream');
    xhr.upload.onprogress = (e) => { if (e.lengthComputable && onProgress) onProgress(e.loaded / e.total); };
    xhr.onload = () => {
      let data = null; try { data = JSON.parse(xhr.responseText); } catch { /* ignore */ }
      if (xhr.status >= 200 && xhr.status < 300 && data?.attachment) resolve(data.attachment);
      else reject(new ApiError(xhr.status, data?.error?.code || 'upload_failed'));
    };
    xhr.onerror = () => reject(new ApiError(0, 'network'));
    xhr.onabort = () => reject(new ApiError(0, 'aborted'));
    xhr.send(file);
  });
  return { promise, abort: () => xhr && xhr.abort() };
}
