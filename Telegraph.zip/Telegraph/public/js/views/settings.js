import { h } from '../dom.js';
import { t, errText } from '../i18n.js';
import { api } from '../api.js';
import { state } from '../store.js';
import { openModal } from '../ui/modal.js';
import { toastInfo, toastError } from '../ui/toast.js';
import { E2EE_ENABLED } from '../e2ee.js';

export function openSettings({ onLogout }) {
  const name = h('input', { class: 'input', value: state.user.display_name, maxlength: '40' });
  const cur = h('input', { class: 'input', type: 'password', dir: 'ltr', autocomplete: 'current-password' });
  const nw = h('input', { class: 'input', type: 'password', dir: 'ltr', autocomplete: 'new-password' });
  const err = h('div', { class: 'error-text', role: 'alert' });
  let close;
  const perm = typeof Notification !== 'undefined' ? Notification.permission : 'unsupported';
  const notifBtn = h('button', { class: 'btn', type: 'button', onclick: async () => { const r = await Notification.requestPermission(); notifBtn.disabled = r !== 'default'; toastInfo(r === 'granted' ? t.saved : t.enableNotifs + ': ' + r); } }, t.enableNotifs);
  if (perm !== 'default') notifBtn.hidden = true;
  const nameForm = h('form', { class: 'f', onsubmit: async (e) => { e.preventDefault(); try { const r = await api.updateMe({ display_name: name.value }); state.user.display_name = r.user.display_name; toastInfo(t.saved); } catch (ex) { toastError(ex); } } },
    h('label', { class: 'field' }, h('span', { text: t.displayName }), name), h('button', { class: 'btn', type: 'submit', text: t.save }));
  const pwForm = h('form', { class: 'f', onsubmit: async (e) => { e.preventDefault(); err.textContent = ''; try { await api.changePassword({ current_password: cur.value, new_password: nw.value }); cur.value = nw.value = ''; toastInfo(t.passwordChanged); } catch (ex) { err.textContent = errText(ex.code); } } },
    h('label', { class: 'field' }, h('span', { text: t.currentPassword }), cur), h('label', { class: 'field' }, h('span', { text: t.newPassword }), nw), err,
    h('button', { class: 'btn', type: 'submit', text: t.changePassword }));
  for (const f of [nameForm, pwForm]) { f.style.display = 'flex'; f.style.flexDirection = 'column'; f.style.gap = '12px'; }
  close = openModal([
    h('h2', { text: t.settings }),
    h('p', { class: 'hint', text: `@${state.user.username}` }),
    nameForm, notifBtn, pwForm,
    h('p', { class: 'hint', text: t.e2eeNote + (E2EE_ENABLED ? '' : '') }),
    h('div', { class: 'actions' },
      h('button', { class: 'btn danger', type: 'button', onclick: () => { close(); onLogout(); }, text: t.logout }),
      h('button', { class: 'btn', type: 'button', onclick: () => close(), text: t.close })),
  ]);
}
