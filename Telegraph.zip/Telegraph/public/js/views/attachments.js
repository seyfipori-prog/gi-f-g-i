import { h, bdi, $ } from '../dom.js';
import { icon } from '../icons.js';
import { t, fmt } from '../i18n.js';

export function openLightbox(url, name) {
  const prev = document.activeElement;
  const img = h('img', { src: url, alt: name || '' });
  const closeBtn = h('button', { type: 'button', 'aria-label': t.close, onclick: close }, icon('x'));
  const dl = h('a', { href: url + '?download=1', 'aria-label': t.download, download: name || '' }, icon('download'));
  const lb = h('div', { class: 'lightbox', role: 'dialog', 'aria-modal': 'true', 'aria-label': name || 'image' },
    h('div', { class: 'lb-bar' }, closeBtn, dl), img);
  lb.addEventListener('click', (e) => { if (e.target === lb) close(); });
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  function close() { lb.remove(); document.removeEventListener('keydown', onKey); prev && prev.focus && prev.focus(); }
  document.addEventListener('keydown', onKey);
  $('#overlay-root').append(lb); closeBtn.focus();
}

// One shared audio element so only one voice message plays at a time.
let playing = null;
function voicePlayer(a) {
  const audio = new Audio(); audio.preload = 'none'; audio.src = a.url;
  const bar = h('i'); const dur = h('span', { class: 'dur', text: fmt.dur(a.duration_ms || 0) });
  const btn = h('button', { class: 'play', type: 'button', 'aria-label': t.voice });
  const setIcon = (p) => { btn.replaceChildren(icon(p ? 'pause' : 'play')); btn.setAttribute('aria-pressed', String(p)); };
  setIcon(false);
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    if (audio.paused) { if (playing && playing !== audio) playing.pause(); playing = audio; audio.play().catch(() => {}); } else audio.pause();
  });
  audio.addEventListener('play', () => setIcon(true));
  audio.addEventListener('pause', () => setIcon(false));
  audio.addEventListener('ended', () => { setIcon(false); bar.style.width = '0'; dur.textContent = fmt.dur(a.duration_ms || 0); });
  audio.addEventListener('timeupdate', () => {
    const total = (isFinite(audio.duration) && audio.duration) || (a.duration_ms || 0) / 1000;
    if (total) bar.style.width = Math.min(100, (audio.currentTime / total) * 100) + '%';
    dur.textContent = fmt.dur(audio.currentTime * 1000);
  });
  const track = h('div', { class: 'track', role: 'progressbar' }, bar);
  return h('div', { class: 'voice', onclick: (e) => e.stopPropagation() }, btn, track, dur);
}

export function renderAttachments(m) {
  const out = [];
  for (const a of m.attachments || []) {
    if (a.is_voice || a.category === 'audio') { out.push(voicePlayer(a)); continue; }
    if (a.category === 'image') {
      const img = h('img', { src: a.url, alt: a.filename, loading: 'lazy', decoding: 'async' });
      img.addEventListener('click', (e) => { e.stopPropagation(); openLightbox(a.url, a.filename); });
      out.push(h('div', { class: 'att-img' }, img)); continue;
    }
    if (a.category === 'video') {
      const v = h('video', { class: 'att-video', controls: true, preload: 'metadata', playsinline: true, src: a.url, 'aria-label': a.filename });
      v.addEventListener('click', (e) => e.stopPropagation()); out.push(v); continue;
    }
    const isPdf = a.category === 'pdf';
    out.push(h('div', { class: 'att-card', onclick: (e) => e.stopPropagation() },
      h('span', { class: 'ico' }, icon('file')),
      h('span', { class: 'nm' }, bdi(a.filename, true), h('small', { text: `${isPdf ? 'PDF' : (a.filename.split('.').pop() || '').toUpperCase()} · ${fmt.size(a.size)}` })),
      isPdf ? h('a', { class: 'icon-btn', href: a.url, target: '_blank', rel: 'noopener', 'aria-label': t.open }, icon('play')) : null,
      h('a', { class: 'icon-btn', href: a.url + '?download=1', download: a.filename, 'aria-label': t.download }, icon('download'))));
  }
  return out;
}
