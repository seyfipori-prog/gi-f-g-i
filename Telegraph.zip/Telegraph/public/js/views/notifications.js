import { h, clear } from '../dom.js';
import { icon } from '../icons.js';
import { t, fmt } from '../i18n.js';
import { api } from '../api.js';
import { state, bus } from '../store.js';
import { go } from '../nav.js';
import { openModal } from '../ui/modal.js';
import { toast, toastError } from '../ui/toast.js';

const RANK = { normal: 0, good: 1, important: 2, critical: 3 };

export function createBell() {
  const pip = h('span', { class: 'pip', hidden: true });
  const btn = h('button', { class: 'icon-btn bell', type: 'button', 'aria-label': t.notifications, onclick: () => openCenter() }, icon('bell'), pip);
  function paint() {
    pip.hidden = !state.unreadNotifs;
    pip.textContent = fmt.num(Math.min(state.unreadNotifs, 99));
    pip.style.setProperty('--pip', `var(--p-${state.notifPriority})`);
  }
  bus.on('notifs', paint); paint();
  return btn;
}

export async function refreshNotifs() {
  try {
    const r = await api.notifications({ unread: 1, limit: 100 });
    let top = 'normal';
    for (const n of r.notifications) if (RANK[n.priority] > RANK[top]) top = n.priority;
    state.unreadNotifs = r.unread_count; state.notifPriority = top; bus.emit('notifs');
  } catch { /* offline */ }
}

async function openCenter() {
  const list = h('div', { class: 'list' });
  let close;
  const draw = (items) => {
    clear(list);
    if (!items.length) { list.append(h('p', { text: t.noNotifs })); return; }
    for (const n of items) {
      list.append(h('button', { class: 'notif' + (n.read_at ? '' : ' unread'), type: 'button', dataset: { priority: n.priority }, onclick: async () => {
        close(); go(n.chat_id, n.message_id); if (!n.read_at) { api.readNotification(n.id).then(refreshNotifs).catch(() => {}); }
      } }, h('span', { class: 'bang', text: '!', 'aria-label': t.prio[n.priority] }),
        h('span', { class: 'grow' }, h('b', { text: n.chat_title }), h('span', { text: n.preview || n.title })),
        h('time', { text: fmt.listTime(n.created_at) })));
    }
  };
  close = openModal([
    h('h2', { text: t.notifications }), list,
    h('div', { class: 'actions' },
      h('button', { class: 'btn', type: 'button', text: t.markAllRead, onclick: async () => { try { await api.readAllNotifications(); await refreshNotifs(); close(); } catch (e) { toastError(e); } } }),
      h('button', { class: 'btn', type: 'button', text: t.close, onclick: () => close() })),
  ]);
  try { draw((await api.notifications({ limit: 40 })).notifications); } catch (e) { toastError(e); }
}

// Called for each incoming `chat.updated` carrying a notification (via the inbox socket).
export function handleIncoming(n) {
  state.unreadNotifs += 1;
  if (RANK[n.priority] > RANK[state.notifPriority]) state.notifPriority = n.priority;
  bus.emit('notifs');
  const viewing = state.activeChatId === n.chat_id && !document.hidden;
  if (viewing) { api.readNotification(n.id).then(refreshNotifs).catch(() => {}); return; }
  if (document.hidden && typeof Notification !== 'undefined' && Notification.permission === 'granted') {
    try {
      const nt = new Notification(n.chat_title || t.appName, { body: n.preview || n.title, icon: '/logo/icon-192.png', tag: n.chat_id, lang: 'fa', dir: 'rtl' });
      nt.onclick = () => { window.focus(); go(n.chat_id, n.message_id); nt.close(); };
    } catch { /* some mobile browsers require a service worker */ }
  }
  toast({ title: n.chat_title, text: n.preview || n.title, priority: n.priority, ms: n.priority === 'critical' ? 9000 : 4500, onClick: () => go(n.chat_id, n.message_id) });
}
