import { h, clear } from '../dom.js';
import { t, errText } from '../i18n.js';
import { api } from '../api.js';

export function renderAuth(root, onSuccess) {
  let mode = 'login';
  const err = h('div', { class: 'error-text', role: 'alert' });
  const user = h('input', { class: 'input', name: 'username', dir: 'ltr', autocomplete: 'username', autocapitalize: 'none', autocorrect: 'off', spellcheck: 'false', required: true, maxlength: '32' });
  const display = h('input', { class: 'input', name: 'display_name', autocomplete: 'nickname', maxlength: '40' });
  const pass = h('input', { class: 'input', name: 'password', type: 'password', dir: 'ltr', autocomplete: 'current-password', required: true, maxlength: '128' });
  const displayField = h('label', { class: 'field' }, h('span', { text: t.displayName }), display);
  const hint = h('span', { class: 'hint' });
  const submit = h('button', { class: 'btn primary', type: 'submit' });
  const tabLogin = h('button', { type: 'button', role: 'tab', onclick: () => set('login'), text: t.login });
  const tabReg = h('button', { type: 'button', role: 'tab', onclick: () => set('register'), text: t.register });
  const form = h('form', { novalidate: true, onsubmit: async (e) => {
    e.preventDefault(); err.textContent = ''; submit.disabled = true;
    try {
      const body = { username: user.value, password: pass.value };
      if (mode === 'register') body.display_name = display.value;
      const r = await (mode === 'login' ? api.login(body) : api.register(body));
      onSuccess(r.user);
    } catch (ex) { err.textContent = errText(ex.code); submit.disabled = false; pass.focus(); }
  } },
    h('label', { class: 'field' }, h('span', { text: t.username }), user),
    displayField,
    h('label', { class: 'field' }, h('span', { text: t.password }), pass, hint),
    err, submit);
  function set(m) {
    mode = m; err.textContent = '';
    tabLogin.setAttribute('aria-selected', String(m === 'login')); tabReg.setAttribute('aria-selected', String(m === 'register'));
    displayField.hidden = m === 'login';
    submit.textContent = m === 'login' ? t.login : t.register;
    pass.autocomplete = m === 'login' ? 'current-password' : 'new-password';
    hint.textContent = m === 'register' ? `${t.usernameHint} — ${t.passwordHint}` : '';
  }
  clear(root).append(h('main', { class: 'auth' },
    h('div', { class: 'auth-card' },
      h('div', { class: 'auth-logo' }, h('img', { src: '/logo/telegraph-lockup.png', alt: t.appName })),
      h('div', { class: 'auth-tabs', role: 'tablist' }, tabLogin, tabReg),
      form,
      h('p', { class: 'auth-note', text: t.e2eeNote }))));
  set('login'); user.focus();
}
