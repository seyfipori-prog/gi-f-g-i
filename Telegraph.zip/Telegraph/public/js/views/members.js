import { h, avatar } from '../dom.js';
import { t, errText } from '../i18n.js';
import { api } from '../api.js';
import { state } from '../store.js';
import { go } from '../nav.js';
import { openModal, confirmDialog } from '../ui/modal.js';
import { toastError } from '../ui/toast.js';

export function openNewChat() {
  const title = h('input', { class: 'input', maxlength: '60', placeholder: t.newChat });
  const members = h('input', { class: 'input', dir: 'ltr', autocapitalize: 'none', autocorrect: 'off', spellcheck: 'false', placeholder: 'ali, sara' });
  const err = h('div', { class: 'error-text', role: 'alert' });
  const btn = h('button', { class: 'btn primary', type: 'submit', text: t.create });
  let close;
  const form = h('form', { onsubmit: async (e) => {
    e.preventDefault(); err.textContent = ''; btn.disabled = true;
    try {
      const names = members.value.split(/[,،\s]+/).map((s) => s.trim()).filter(Boolean);
      const r = await api.createChat({ title: title.value, members: names });
      close(); go(r.chat.id);
    } catch (ex) { err.textContent = errText(ex.code); btn.disabled = false; }
  } },
    h('label', { class: 'field' }, h('span', { text: t.chatTitle }), title),
    h('label', { class: 'field' }, h('span', { text: t.membersHint }), members),
    err, h('div', { class: 'actions' }, btn, h('button', { class: 'btn', type: 'button', onclick: () => close(), text: t.cancel })));
  form.style.display = 'flex'; form.style.flexDirection = 'column'; form.style.gap = '14px';
  close = openModal([h('h2', { text: t.newChat }), form]);
}

// Members dialog: list, add (owner), remove (owner), rename (owner), leave/delete.
export async function openMembers(chatId, onChanged) {
  let data;
  try { data = await api.chat(chatId); } catch (e) { toastError(e); return; }
  const owner = data.chat.role === 'owner';
  const listEl = h('div', { class: 'list' });
  const input = h('input', { class: 'input', dir: 'ltr', autocapitalize: 'none', placeholder: 'username' });
  const err = h('div', { class: 'error-text', role: 'alert' });
  let close;
  const draw = () => {
    listEl.replaceChildren(...data.members.map((m) => h('div', { class: 'row' }, avatar(m, 'sm'),
      h('div', { class: 'grow' }, m.display_name, h('small', { class: 'ltr', text: '@' + m.username + (m.role === 'owner' ? ' · مالک' : '') })),
      owner && m.id !== state.user.id ? h('button', { class: 'icon-btn', type: 'button', 'aria-label': t.delete, onclick: async () => {
        try { await api.removeMember(chatId, m.id); data = await api.chat(chatId); draw(); onChanged && onChanged(); } catch (ex) { toastError(ex); }
      } }, '✕') : null)));
  };
  const add = h('form', { onsubmit: async (e) => {
    e.preventDefault(); err.textContent = '';
    try { await api.addMember(chatId, input.value); input.value = ''; data = await api.chat(chatId); draw(); onChanged && onChanged(); } catch (ex) { err.textContent = errText(ex.code); }
  } }, h('label', { class: 'field' }, h('span', { text: t.addMember }), h('div', { style: null }, input)), err,
    h('button', { class: 'btn', type: 'submit', text: t.add }));
  add.style.display = 'flex'; add.style.flexDirection = 'column'; add.style.gap = '10px';
  draw();
  const actions = h('div', { class: 'actions' });
  if (owner) actions.append(h('button', { class: 'btn', type: 'button', text: t.rename, onclick: async () => {
    const { promptDialog } = await import('../ui/modal.js');
    const v = await promptDialog({ title: t.rename, label: t.chatTitle, value: data.chat.title }); if (v == null) return;
    try { await api.renameChat(chatId, v); close(); onChanged && onChanged(); } catch (ex) { toastError(ex); }
  } }));
  actions.append(h('button', { class: 'btn danger', type: 'button', text: owner ? t.deleteChat : t.leave, onclick: async () => {
    if (!(await confirmDialog(owner ? t.confirmDeleteChat : t.confirmLeave, { danger: true }))) return;
    try { await api.deleteChat(chatId); close(); go(null); onChanged && onChanged(); } catch (ex) { toastError(ex); }
  } }));
  actions.append(h('button', { class: 'btn', type: 'button', text: t.close, onclick: () => close() }));
  close = openModal([h('h2', { text: data.chat.title }), listEl, owner ? add : null, actions]);
}
