import { h } from '../dom.js';
import { icon } from '../icons.js';
import { t, errText, fmt } from '../i18n.js';
import { api, uploadFile } from '../api.js';
import { isTouch } from '../dom.js';
import { openMenu } from '../ui/menu.js';
import { promptDialog } from '../ui/modal.js';
import { toast, toastError } from '../ui/toast.js';
import { startRecording, voiceSupported, MAX_VOICE_MS } from './voice.js';

const ACCEPT = 'image/jpeg,image/png,image/gif,image/webp,video/mp4,video/quicktime,video/webm,application/pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.zip,audio/*';

export function createComposer({ chatId, onSent, onTyping }) {
  let replyTo = null; let editing = null; let ttl = null; let priority = 'normal';
  let pending = []; let rec = null; let sending = false; let typingOn = false; let typingT = null;

  const ta = h('textarea', { rows: '1', placeholder: t.typeMsg, 'aria-label': t.typeMsg, enterkeyhint: 'send', maxlength: '8000' });
  const fileInput = h('input', { type: 'file', multiple: true, accept: ACCEPT, hidden: true });
  const sendBtn = h('button', { class: 'icon-btn send', type: 'button', 'aria-label': t.send, onclick: () => submit() }, icon('send'));
  const attachBtn = h('button', { class: 'icon-btn', type: 'button', 'aria-label': t.attach, onclick: () => fileInput.click() }, icon('clip'));
  const optBtn = h('button', { class: 'icon-btn prio-btn', type: 'button', 'aria-label': `${t.timer} / ${t.priority}`, onclick: () => showOptions() }, icon('clock'), h('i'));
  const micBtn = h('button', { class: 'icon-btn', type: 'button', 'aria-label': t.voice, onclick: () => beginVoice() }, icon('mic'));
  const ctxBar = h('div'); const pendBar = h('div', { class: 'pending' });
  const row = h('div', { class: 'composer' }, attachBtn, optBtn, ta, micBtn, sendBtn);
  const el = h('div', { class: 'composer-wrap' }, ctxBar, pendBar, row, fileInput);
  pendBar.hidden = true;

  function autosize() { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 160) + 'px'; }
  function syncOpt() {
    optBtn.classList.toggle('ttl-on', !!ttl);
    optBtn.querySelector('i').style.display = priority === 'normal' ? 'none' : 'block';
    optBtn.style.setProperty('--pc', `var(--p-${priority})`);
    optBtn.title = ttl ? `${t.expiresIn}: ${fmt.remaining(Date.now() + ttl * 1000)}` : '';
  }
  async function customTtl() {
    const v = await promptDialog({ title: t.customTimer, label: t.customTtlPrompt + ' — ' + t.seconds, value: '120', type: 'number', hint: `${t.seconds}: ۵ – ${fmt.num(2592000)}` });
    const n = Math.round(Number(v)); if (!v || !Number.isFinite(n)) return;
    if (n < 5 || n > 2592000) { toast({ text: errText('bad_ttl'), err: true }); return; }
    ttl = n; syncOpt();
  }
  function showOptions() {
    openMenu(optBtn, [
      ...t.ttlOpts.map(([label, s]) => ({ label: `${t.timer}: ${label}`, icon: 'clock', onClick: () => { ttl = s; syncOpt(); } })),
      { label: t.customTimer, icon: 'edit', onClick: customTtl },
      ...(ttl ? [{ label: t.removeTimer, icon: 'x', onClick: () => { ttl = null; syncOpt(); } }] : []),
    ], { prio: { current: priority, onPick: (p) => { priority = p; syncOpt(); } } });
  }
  function renderCtx() {
    ctxBar.replaceChildren();
    const target = editing || replyTo; if (!target) return;
    const prev = (target.body || (target.attachments[0] && target.attachments[0].filename) || '').slice(0, 100);
    ctxBar.append(h('div', { class: 'ctx' }, icon(editing ? 'edit' : 'reply'),
      h('div', { class: 't' }, h('b', { text: editing ? t.edit : `${t.reply} · ${target.sender.display_name}` }), h('span', { text: prev })),
      h('button', { class: 'icon-btn', type: 'button', 'aria-label': t.cancel, onclick: () => { if (editing) ta.value = ''; editing = null; replyTo = null; renderCtx(); autosize(); } }, icon('x'))));
  }
  function renderPending() {
    pendBar.hidden = !pending.length;
    pendBar.replaceChildren(...pending.map((p) => {
      const bar = h('i'); bar.style.width = Math.round(p.progress * 100) + '%';
      return h('div', { class: 'pend' + (p.error ? ' fail' : '') },
        h('bdi', { dir: 'ltr', text: p.file.name }),
        h('small', { text: p.error ? errText(p.error) : (p.att ? fmt.size(p.att.size) : fmt.num(Math.round(p.progress * 100)) + '٪') }),
        h('div', { class: 'bar' }, bar),
        h('button', { class: 'x', type: 'button', 'aria-label': t.cancel, onclick: () => removePending(p) }, icon('x')));
    }));
  }
  function removePending(p) {
    p.abort && p.abort(); pending = pending.filter((x) => x !== p);
    if (p.att) api.discardUpload(p.att.id).catch(() => {});
    renderPending();
  }
  function addFiles(files) {
    if (editing) return;
    for (const file of files) {
      if (pending.length >= 10) break;
      const p = { file, progress: 0, att: null, error: null, abort: null };
      pending.push(p);
      const up = uploadFile(chatId, file, { onProgress: (f) => { p.progress = f; renderPending(); } });
      p.abort = up.abort;
      up.promise.then((att) => { p.att = att; p.progress = 1; }).catch((e) => { if (e.code !== 'aborted') { p.error = e.code; toastError(e); } }).finally(() => { p.abort = null; renderPending(); });
    }
    renderPending();
  }
  fileInput.addEventListener('change', () => { addFiles([...fileInput.files]); fileInput.value = ''; });
  ta.addEventListener('paste', (e) => { const fs = [...(e.clipboardData?.files || [])]; if (fs.length) { e.preventDefault(); addFiles(fs); } });

  async function submit(extra = {}) {
    if (sending) return;
    const body = ta.value.trim();
    const ready = pending.filter((p) => p.att);
    if (pending.some((p) => !p.att && !p.error)) { toast({ text: 'بارگذاری فایل هنوز تمام نشده است.', priority: 'normal' }); return; }
    const ids = ready.map((p) => p.att.id).concat(extra.attachment_ids || []);
    if (!body && !ids.length) return;
    sending = true; sendBtn.disabled = true;
    try {
      if (editing) {
        await api.edit(editing.id, body); editing = null;
      } else {
        const r = await api.send(chatId, { body, attachment_ids: ids, reply_to_id: replyTo ? replyTo.id : undefined, priority, ttl_seconds: ttl || undefined });
        onSent && onSent(r.message);
      }
      ta.value = ''; pending = pending.filter((p) => p.error); replyTo = null; renderCtx(); renderPending(); autosize(); stopTyping();
    } catch (e) { toastError(e); } finally { sending = false; sendBtn.disabled = false; ta.focus(); }
  }
  ta.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && !isTouch()) { e.preventDefault(); submit(); }
    if (e.key === 'Escape' && (editing || replyTo)) { if (editing) ta.value = ''; editing = null; replyTo = null; renderCtx(); autosize(); }
  });
  ta.addEventListener('input', () => {
    autosize();
    if (!typingOn && ta.value) { typingOn = true; onTyping && onTyping(true); }
    clearTimeout(typingT); typingT = setTimeout(stopTyping, 3000);
  });
  function stopTyping() { clearTimeout(typingT); if (typingOn) { typingOn = false; onTyping && onTyping(false); } }

  // ---- voice ----
  async function beginVoice() {
    if (rec || editing) return;
    if (!voiceSupported()) { toast({ text: t.mic_unsupported, err: true }); return; }
    const time = h('span', { class: 'time', text: '0:00' });
    let r;
    try { r = await startRecording({ onTick: (ms) => { time.textContent = fmt.dur(ms); }, onAutoStop: () => finish(true) }); }
    catch (e) { toast({ text: e.code === 'denied' ? t.mic_denied : t.mic_unsupported, err: true }); return; }
    const cancelBtn = h('button', { class: 'icon-btn', type: 'button', 'aria-label': t.cancel, onclick: () => finish(false) }, icon('trash'));
    const sendV = h('button', { class: 'icon-btn send', type: 'button', 'aria-label': t.send, onclick: () => finish(true) }, icon('send'));
    const ui = h('div', { class: 'composer', role: 'group', 'aria-label': t.recording }, cancelBtn,
      h('div', { class: 'rec' }, h('span', { class: 'dot' }), time, h('span', { class: 'lvl', text: t.recording })), sendV);
    row.hidden = true; el.append(ui); rec = { r, ui };
    async function finish(send) {
      if (!rec) return; const cur = rec; rec = null; sendV.disabled = true;
      const res = send ? await cur.r.stop() : await cur.r.cancel();
      cur.ui.remove(); row.hidden = false;
      if (!res || !send) return;
      if (res.durationMs < 600) { toast({ text: 'پیام صوتی خیلی کوتاه است.', priority: 'normal' }); return; }
      const ext = res.mime.includes('mp4') ? 'm4a' : res.mime.includes('ogg') ? 'ogg' : 'webm';
      const file = new File([res.blob], `voice.${ext}`, { type: res.mime });
      const prog = { file, progress: 0, att: null, error: null, abort: null }; pending.push(prog); renderPending();
      const up = uploadFile(chatId, file, { voice: true, durationMs: res.durationMs, onProgress: (f) => { prog.progress = f; renderPending(); } });
      try {
        const att = await up.promise; pending = pending.filter((x) => x !== prog); renderPending();
        const saved = ta.value; ta.value = '';
        const m = await api.send(chatId, { body: '', attachment_ids: [att.id], priority, ttl_seconds: ttl || undefined, reply_to_id: replyTo ? replyTo.id : undefined });
        ta.value = saved; replyTo = null; renderCtx(); onSent && onSent(m.message);
      } catch (e) { pending = pending.filter((x) => x !== prog); renderPending(); toastError(e); }
    }
  }

  syncOpt();
  return {
    el, textarea: ta, addFiles,
    focus: () => ta.focus(),
    setReply(m) { editing = null; replyTo = m; renderCtx(); ta.focus(); },
    setEdit(m) { replyTo = null; editing = m; ta.value = m.body; renderCtx(); autosize(); ta.focus(); },
    destroy() { stopTyping(); if (rec) rec.r.cancel(); pending.forEach((p) => p.abort && p.abort()); },
  };
}
