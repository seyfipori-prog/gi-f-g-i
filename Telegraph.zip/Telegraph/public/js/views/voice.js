// MediaRecorder wrapper. Picks the first supported mime among webm/opus, mp4, ogg.
const CANDIDATES = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus', 'audio/ogg'];
export const MAX_VOICE_MS = 5 * 60 * 1000;
export const voiceSupported = () => !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder);

export async function startRecording({ onTick, onAutoStop }) {
  if (!voiceSupported()) throw Object.assign(new Error('unsupported'), { code: 'unsupported' });
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); }
  catch (e) { throw Object.assign(e, { code: 'denied' }); }
  const mimeType = CANDIDATES.find((m) => MediaRecorder.isTypeSupported(m)) || '';
  const rec = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
  const chunks = []; const t0 = Date.now(); let cancelled = false; let stopped = false;
  rec.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
  const tick = setInterval(() => { const el = Date.now() - t0; onTick && onTick(el); if (el >= MAX_VOICE_MS) { onAutoStop && onAutoStop(); } }, 250);
  const release = () => { clearInterval(tick); stream.getTracks().forEach((tr) => tr.stop()); };
  rec.start(500);
  const done = new Promise((resolve) => {
    rec.onstop = () => {
      release();
      const type = (rec.mimeType || mimeType || 'audio/webm').split(';')[0];
      resolve(cancelled ? null : { blob: new Blob(chunks, { type }), mime: type, durationMs: Math.min(Date.now() - t0, MAX_VOICE_MS) });
    };
  });
  return {
    stop() { if (!stopped) { stopped = true; try { rec.stop(); } catch { release(); } } return done; },
    cancel() { cancelled = true; if (!stopped) { stopped = true; try { rec.stop(); } catch { release(); } } return done; },
  };
}
