import { h, clear, avatar, debounce } from '../dom.js';
import { icon } from '../icons.js';
import { t, fmt } from '../i18n.js';
import { api } from '../api.js';
import { state, bus } from '../store.js';
import { go } from '../nav.js';
import { toastError } from '../ui/toast.js';
import { openSettings } from './settings.js';
import { openNewChat } from './members.js';

const PRIOS = ['critical', 'important', 'good'];

export function createSidebar({ onLogout, closeDrawer }) {
  let query = ''; let prio = null; let results = null; let seq = 0;
  const list = h('div', { class: 'sb-list', role: 'navigation', 'aria-label': t.chats });
  const input = h('input', { class: 'input', type: 'search', placeholder: t.search, 'aria-label': t.search, autocomplete: 'off', enterkeyhint: 'search' });
  const chips = h('div', { class: 'sb-filters', role: 'group', 'aria-label': t.priority },
    PRIOS.map((p) => { const c = h('button', { class: 'chip', type: 'button', 'aria-pressed': 'false', onclick: () => { prio = prio === p ? null : p; syncChips(); run(); } }, h('i', { class: 'dot' }), t.prio[p]); c.style.setProperty('--dot', `var(--p-${p})`); c.dataset.p = p; return c; }));
  function syncChips() { chips.querySelectorAll('.chip').forEach((c) => c.setAttribute('aria-pressed', String(c.dataset.p === prio))); }
  const newBtn = h('button', { class: 'sb-new', type: 'button', onclick: () => { closeDrawer(); openNewChat(); } }, icon('plus'), h('span', { text: t.newChat }));
  const me = state.user;
  const userBtn = h('button', { class: 'sb-user', type: 'button', onclick: () => openSettings({ onLogout }), 'aria-label': t.settings },
    avatar(me, 'sm'), h('span', { style: null }, h('span', { class: 'name', text: me.display_name }), h('br'), h('span', { class: 'handle ltr', text: '@' + me.username })));
  const el = h('aside', { class: 'sidebar', 'aria-label': t.appName },
    h('div', { class: 'sb-top' },
      h('div', { class: 'sb-brand' }, h('img', { src: '/logo/telegraph-lockup.png', alt: t.appName }),
        h('button', { class: 'icon-btn only-mobile-flex', type: 'button', 'aria-label': t.close, onclick: closeDrawer }, icon('x'))),
      newBtn,
      h('div', { class: 'sb-search' }, icon('search'), input)),
    chips, list,
    h('div', { class: 'sb-bottom' }, userBtn,
      h('button', { class: 'icon-btn', type: 'button', 'aria-label': t.settings, onclick: () => openSettings({ onLogout }) }, icon('settings')),
      h('button', { class: 'icon-btn', type: 'button', 'aria-label': t.logout, onclick: onLogout }, icon('logout'))));
  el.querySelector('.only-mobile-flex').style.display = matchMedia('(max-width: 860px)').matches ? '' : 'none';
  matchMedia('(max-width: 860px)').addEventListener('change', (e) => { el.querySelector('.only-mobile-flex').style.display = e.matches ? '' : 'none'; });

  const run = debounce(async () => {
    query = input.value.trim(); const my = ++seq;
    if (!query && !prio) { results = null; render(); return; }
    try {
      const [chats, msgs, files] = await Promise.all([
        query && !prio ? api.chats(query) : { chats: [] },
        query.length >= 2 || prio ? api.search({ q: query, priority: prio, limit: 20 }) : { results: [] },
        query.length >= 2 && !prio ? api.search({ q: query, scope: 'files', limit: 10 }) : { results: [] },
      ]);
      if (my !== seq) return;
      results = { chats: chats.chats, msgs: msgs.results, files: files.results.filter((f) => !msgs.results.some((m) => m.id === f.id)) };
      render();
    } catch (e) { if (my === seq) toastError(e); }
  }, 250);
  input.addEventListener('input', run);

  function item(c) {
    const lm = c.last_message;
    const prev = lm ? (lm.kind === 'voice' ? '🎤 ' + t.voice : lm.kind === 'file' && !lm.preview ? '📎 ' + t.files : (lm.mine ? t.you + ': ' : '') + lm.preview) : '';
    const b = h('button', { class: 'sb-item', type: 'button', 'aria-current': String(state.activeChatId === c.id), dataset: { id: c.id }, onclick: () => { closeDrawer(); go(c.id); } },
      h('span', { class: 'avatar', 'aria-hidden': 'true', text: [...c.title][0] || '؟' }),
      h('span', { class: 'meta' },
        h('span', { class: 'row' }, h('span', { class: 'title', text: c.title }), h('span', { class: 'time', text: fmt.listTime(c.last_activity) })),
        h('span', { class: 'row' }, h('span', { class: 'preview' + (lm && (lm.priority === 'important' || lm.priority === 'critical') ? ' p-' + lm.priority : ''), text: prev || '—' }),
          c.unread ? h('span', { class: 'badge', 'aria-label': `${fmt.num(c.unread)} خوانده‌نشده`, text: fmt.num(c.unread > 99 ? 99 : c.unread) }) : null)));
    b.firstChild.style.setProperty('--av', '#' + ((c.id.slice(0, 6)) || '34d399'));
    b.firstChild.style.setProperty('--av', ['#34d399', '#60a5fa', '#f472b6', '#fbbf24', '#a78bfa', '#fb923c'][parseInt(c.id.slice(0, 2), 16) % 6]);
    return b;
  }
  function msgItem(m) {
    const a = m.attachments && m.attachments[0];
    const text = m.body || (a ? a.filename : '');
    return h('button', { class: 'sb-item', type: 'button', onclick: () => { closeDrawer(); go(m.chat_id, m.id); } },
      h('span', { class: 'bang', style: null, text: '!' }),
      h('span', { class: 'meta' },
        h('span', { class: 'row' }, h('span', { class: 'title', text: m.chat_title || '' }), h('span', { class: 'time', text: fmt.listTime(m.created_at) })),
        h('span', { class: 'row' }, h('span', { class: 'preview' }, a && !m.body ? h('bdi', { text: a.filename }) : text.slice(0, 120)))));
  }
  function group(title, nodes) { return nodes.length ? [h('div', { class: 'sb-group', text: title }), ...nodes] : []; }
  function render() {
    clear(list);
    if (results) {
      const mk = (m) => { const n = msgItem(m); const bang = n.firstChild; bang.style.setProperty('--pc', `var(--p-${m.priority})`); bang.style.width = '22px'; bang.style.height = '22px'; bang.style.fontSize = '.75rem'; bang.style.border = '2px solid var(--pc)'; bang.style.color = 'var(--pc)'; bang.style.borderRadius = '50%'; bang.style.display = 'grid'; bang.style.placeItems = 'center'; bang.style.flex = 'none'; return n; };
      const nodes = [...group(t.chats, results.chats.map(item)), ...group(t.messages, results.msgs.map(mk)), ...group(t.files, results.files.map(mk))];
      list.append(...(nodes.length ? nodes : [h('div', { class: 'sb-empty', text: t.noResults })]));
      return;
    }
    if (!state.chats.length) { list.append(h('div', { class: 'sb-empty', text: t.noChats })); return; }
    const groups = new Map();
    for (const c of state.chats) { const k = fmt.dayLabel(c.last_activity); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(c); }
    for (const [k, cs] of groups) list.append(...group(k, cs.map(item)));
  }
  bus.on('chats', () => { if (!results) render(); });
  bus.on('active', () => { list.querySelectorAll('.sb-item[data-id]').forEach((n) => n.setAttribute('aria-current', String(n.dataset.id === state.activeChatId))); });
  render();
  return { el, render, focusSearch: () => input.focus() };
}
