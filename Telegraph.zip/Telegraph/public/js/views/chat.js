import { h, clear, avatar, linkify, bdi } from '../dom.js';
import { icon, ticks } from '../icons.js';
import { t, fmt } from '../i18n.js';
import { api } from '../api.js';
import { state, bus } from '../store.js';
import { connect } from '../socket.js';
import { openMenu } from '../ui/menu.js';
import { confirmDialog, promptDialog } from '../ui/modal.js';
import { toast, toastError, toastInfo } from '../ui/toast.js';
import { renderAttachments } from './attachments.js';
import { createComposer } from './composer.js';
import { openMembers } from './members.js';
import { errText } from '../i18n.js';

// ChatView owns one open conversation: history, live socket, composer, pins.
export class ChatView {
  constructor(chatId, { setHeader, highlight, onGone }) {
    this.chatId = chatId; this.setHeader = setHeader; this.onGone = onGone;
    this.items = []; this.els = new Map(); this.hasMore = false; this.nextBefore = null; this.loadingMore = false;
    this.info = null; this.online = new Set(); this.typers = new Map(); this.atBottom = true; this.newCount = 0; this.dead = false;
    this.highlight = highlight || null;
    this.msgs = h('div', { class: 'msgs', role: 'log', 'aria-live': 'polite', 'aria-label': t.messages, tabindex: '0' });
    this.pinbar = h('button', { class: 'pinbar', type: 'button', hidden: true });
    this.typingEl = h('div', { class: 'typing', 'aria-live': 'polite' });
    this.jumpBadge = h('span', { class: 'badge', hidden: true });
    this.jump = h('button', { class: 'jump', type: 'button', hidden: true, 'aria-label': t.jumpLatest, onclick: () => this.scrollBottom(true) }, icon('down'), this.jumpBadge);
    this.drop = h('div', { class: 'drop', hidden: true, text: t.dropFiles });
    this.composer = createComposer({
      chatId, onSent: (m) => { this.upsert(m); this.scrollBottom(true); },
      onTyping: (on) => this.ws && this.ws.send({ type: 'typing', on }),
    });
    this.el = h('section', { class: 'chat', 'aria-label': t.messages }, this.pinbar, this.msgs, this.jump, this.typingEl, this.composer.el, this.drop);
    this.msgs.addEventListener('scroll', () => this.onScroll(), { passive: true });
    this.bindDrop();
    this.onKb = () => { if (this.atBottom) this.scrollBottom(); };
    document.addEventListener('tg:keyboard', this.onKb);
    this.tick = setInterval(() => this.refreshTtl(), 1000);
    this.onVis = () => { if (!document.hidden) this.markRead(); };
    document.addEventListener('visibilitychange', this.onVis);
    this.init();
  }

  async init() {
    try {
      const [info, page] = await Promise.all([api.chat(this.chatId), api.messages(this.chatId)]);
      if (this.dead) return;
      this.info = info; this.applyPage(page, false); this.paintHeader(); this.paintPins();
      this.openSocket();
      if (this.highlight) await this.jumpTo(this.highlight); else { this.scrollBottom(); this.markRead(); }
    } catch (e) {
      if (this.dead) return;
      if (e.code === 'chat_not_found') { toastError(e); this.onGone && this.onGone(); } else { toastError(e); }
    }
  }
  openSocket() {
    this.ws = connect(`/ws/${this.chatId}`, {
      onOpen: (re) => { if (re) this.resync(); },
      onMessage: (m) => this.onEvent(m),
    });
  }
  async resync() {
    try { const [info, page] = await Promise.all([api.chat(this.chatId), api.messages(this.chatId)]); if (this.dead) return;
      this.info = info; const keep = this.items.filter((m) => !page.messages.some((p) => p.id === m.id) && m.seq < (page.messages[0]?.seq ?? Infinity));
      this.items = [...keep, ...page.messages].sort((a, b) => a.seq - b.seq); this.hasMore = page.has_more || this.hasMore; if (!keep.length) this.nextBefore = page.next_before;
      this.renderAll(); this.paintHeader(); this.paintPins(); if (this.atBottom) this.scrollBottom(); this.markRead();
    } catch { /* socket will retry */ }
  }

  // ---------- socket events ----------
  onEvent(m) {
    switch (m.type) {
      case 'hello': this.online = new Set(m.online || []); this.paintHeader(); break;
      case 'presence': m.online ? this.online.add(m.user_id) : this.online.delete(m.user_id); this.paintHeader(); break;
      case 'typing': {
        clearTimeout(this.typers.get(m.user_id)?.t);
        if (m.on) this.typers.set(m.user_id, { name: m.name, t: setTimeout(() => { this.typers.delete(m.user_id); this.paintTyping(); }, 5000) }); else this.typers.delete(m.user_id);
        this.paintTyping(); break;
      }
      case 'message.new': {
        const wasBottom = this.atBottom; this.upsert(m.message);
        if (m.message.sender.id !== state.user.id) { this.typers.delete(m.message.sender.id); this.paintTyping(); }
        if (wasBottom || m.message.sender.id === state.user.id) this.scrollBottom(true); else { this.newCount++; this.paintJump(); }
        if (m.message.sender.id !== state.user.id) this.markRead(); break;
      }
      case 'message.updated': this.upsert(m.message); this.paintPins(true); break;
      case 'message.deleted': this.markDeleted(m.id); break;
      case 'messages.expired': this.removeIds(m.ids || []); break;
      case 'status': for (const it of m.items || []) { const cur = this.items.find((x) => x.id === it.id); if (cur) { cur.status = it.status; this.paintTicks(cur); } } break;
      case 'chat.renamed': if (this.info) { this.info.chat.title = m.title; this.paintHeader(); } break;
      case 'members.changed': api.chat(this.chatId).then((i) => { this.info = i; this.paintHeader(); }).catch(() => {}); break;
      case 'chat.removed': toastInfo(t.deletedMsg); this.onGone && this.onGone(); break;
      default: break;
    }
  }

  // ---------- data ----------
  applyPage(page, prepend) {
    const known = new Set(this.items.map((m) => m.id));
    const add = page.messages.filter((m) => !known.has(m.id));
    this.items = [...add, ...this.items].sort((a, b) => a.seq - b.seq);
    this.hasMore = page.has_more; this.nextBefore = page.next_before;
    this.renderAll();
  }
  async loadMore() {
    if (this.loadingMore || !this.hasMore) return false;
    this.loadingMore = true; const prevH = this.msgs.scrollHeight; const prevTop = this.msgs.scrollTop;
    try { const page = await api.messages(this.chatId, this.nextBefore); this.applyPage(page, true); this.msgs.scrollTop = prevTop + (this.msgs.scrollHeight - prevH); return true; }
    catch (e) { toastError(e); return false; } finally { this.loadingMore = false; }
  }
  async jumpTo(id) {
    for (let i = 0; i < 12 && !this.els.has(id) && this.hasMore; i++) { if (!(await this.loadMore())) break; }
    const el = this.els.get(id);
    if (!el) { this.scrollBottom(); toast({ text: errText('message_not_found'), priority: 'normal' }); return; }
    el.scrollIntoView({ block: 'center' }); const b = el.querySelector('.bubble'); b.classList.remove('flash'); void b.offsetWidth; b.classList.add('flash');
  }
  upsert(m) {
    const i = this.items.findIndex((x) => x.id === m.id);
    if (i >= 0) { const old = this.items[i]; m.status = m.status || old.status; this.items[i] = m; this.replaceEl(m); return; }
    this.items.push(m); this.items.sort((a, b) => a.seq - b.seq);
    if (this.items[this.items.length - 1] === m) this.appendEl(m); else this.renderAll();
  }
  markDeleted(id) {
    const m = this.items.find((x) => x.id === id); if (!m) return;
    m.deleted = true; m.body = ''; m.attachments = []; m.pinned = false; this.replaceEl(m); this.paintPins(true);
  }
  removeIds(ids) { const s = new Set(ids); const n = this.items.length; this.items = this.items.filter((m) => !s.has(m.id)); if (this.items.length !== n) { this.renderAll(); this.paintPins(true); } }
  async markRead() {
    if (document.hidden || !this.atBottom) return;
    try { await api.markRead(this.chatId); const c = state.chats.find((x) => x.id === this.chatId); if (c && c.unread) { c.unread = 0; bus.emit('chats'); } } catch { /* ignore */ }
  }

  // ---------- rendering ----------
  isCont(m, prev) { return !!prev && !prev.deleted && prev.sender.id === m.sender.id && fmt.dayKey(prev.created_at) === fmt.dayKey(m.created_at) && m.created_at - prev.created_at < 5 * 60e3; }
  renderAll() {
    clear(this.msgs); this.els.clear();
    this.msgs.append(this.hasMore ? h('div', { class: 'loader-more', text: t.loadingMore }) : h('div', { class: 'spacer' }));
    let prev = null;
    for (const m of this.items) { this.msgs.append(...this.nodesFor(m, prev)); prev = m; }
    if (this.msgs.firstChild && this.hasMore) this.msgs.firstChild.dataset.more = '1';
  }
  nodesFor(m, prev) {
    const out = [];
    if (!prev || fmt.dayKey(prev.created_at) !== fmt.dayKey(m.created_at)) out.push(h('div', { class: 'day', text: fmt.dayLabel(m.created_at) }));
    const el = this.build(m, this.isCont(m, prev)); this.els.set(m.id, el); out.push(el); return out;
  }
  appendEl(m) {
    const prev = this.items[this.items.length - 2] || null;
    this.msgs.append(...this.nodesFor(m, prev));
  }
  replaceEl(m) {
    const old = this.els.get(m.id); if (!old) { this.renderAll(); return; }
    const idx = this.items.indexOf(m); const el = this.build(m, this.isCont(m, this.items[idx - 1] || null));
    old.replaceWith(el); this.els.set(m.id, el);
  }
  build(m, cont) {
    const own = m.sender.id === state.user.id;
    const bubble = h('div', { class: 'bubble', dataset: { priority: m.priority }, role: 'button', tabindex: '0', 'aria-haspopup': 'menu', 'aria-label': `${m.sender.display_name}، ${t.prio[m.priority]}` });
    if (m.deleted) bubble.append(h('div', { class: 'text', text: t.deletedMsg }));
    else {
      if (m.priority !== 'normal') bubble.append(h('span', { class: 'prio-mark', 'aria-hidden': 'true', text: '!' }));
      if (m.reply_to) {
        const q = h('button', { class: 'reply-q', type: 'button', onclick: (e) => { e.stopPropagation(); if (m.reply_to.id && this.els.has(m.reply_to.id)) this.jumpTo(m.reply_to.id); } },
          h('b', { text: m.reply_to.deleted ? '' : m.reply_to.sender_name || '' }), h('span', { text: m.reply_to.deleted ? t.deletedMsg : m.reply_to.preview || '' }));
        bubble.append(q);
      }
      bubble.append(...renderAttachments(m));
      if (m.body) bubble.append(h('div', { class: 'text' }, linkify(m.body)));
    }
    const foot = h('div', { class: 'foot' });
    if (!m.deleted) {
      if (m.pinned) foot.append(h('span', { class: 'pin' }, icon('pin')));
      if (m.expires_at) foot.append(h('span', { class: 'ttl ttl-bar', dataset: { exp: String(m.expires_at) } }, icon('clock'), h('span', { text: fmt.remaining(m.expires_at) })));
      if (m.edited_at) foot.append(h('span', { class: 'edited', text: t.edited }));
    }
    foot.append(h('time', { datetime: new Date(m.created_at).toISOString(), text: fmt.time(m.created_at) }));
    if (own && !m.deleted) foot.append(h('span', { class: 'ticks ' + (m.status === 'read' ? 'read' : ''), 'aria-label': m.status || 'sent' }, ticks(m.status === 'sent' || !m.status ? 1 : 2)));
    bubble.append(foot);
    const open = (e) => { if (m.deleted) return; if (e.target.closest('a, video, audio, button.play, .att-card')) return; this.openActions(m, bubble); };
    bubble.addEventListener('click', open);
    bubble.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(e); } });
    const wrap = h('div', { class: 'm' + (own ? ' own' : '') + (cont ? ' cont' : '') + (m.deleted ? ' deleted' : ''), dataset: { id: m.id } });
    if (!own && this.info && this.info.members.length > 2) { const w = h('span', { class: 'who', text: m.sender.display_name }); w.style.setProperty('--c', m.sender.color); wrap.append(w); }
    wrap.append(bubble); return wrap;
  }
  paintTicks(m) {
    const el = this.els.get(m.id); if (!el) return; const tk = el.querySelector('.ticks'); if (!tk) return;
    tk.className = 'ticks ' + (m.status === 'read' ? 'read' : ''); tk.replaceChildren(ticks(m.status === 'sent' || !m.status ? 1 : 2)); tk.setAttribute('aria-label', m.status || 'sent');
  }
  refreshTtl() {
    const now = Date.now(); let expired = false;
    for (const m of this.items) {
      if (!m.expires_at) continue; if (m.expires_at <= now) { expired = true; continue; }
      const el = this.els.get(m.id); const s = el && el.querySelector('.ttl span'); if (s) s.textContent = fmt.remaining(m.expires_at);
    }
    if (expired) { this.items = this.items.filter((m) => !m.expires_at || m.expires_at > now); this.renderAll(); this.paintPins(true); }
  }

  // ---------- header / pins / typing ----------
  paintHeader() {
    if (!this.info) return;
    const others = this.info.members.filter((x) => x.id !== state.user.id);
    const onlineCount = others.filter((x) => this.online.has(x.id)).length;
    const sub = this.info.members.length > 2 ? `${fmt.num(this.info.members.length)} ${t.members}${onlineCount ? ` · ${fmt.num(onlineCount)} ${t.online}` : ''}` : (onlineCount ? t.online : '');
    this.setHeader({ title: this.info.chat.title, sub, onMembers: () => openMembers(this.chatId, () => this.refreshInfo()) });
  }
  refreshInfo() { api.chat(this.chatId).then((i) => { this.info = i; this.paintHeader(); this.paintPins(); }).catch(() => {}); }
  paintTyping() {
    const names = [...this.typers.values()].map((x) => x.name);
    this.typingEl.textContent = names.length ? `${names.join('، ')} ${t.typing}` : '';
  }
  paintPins(refetch) {
    if (refetch) { api.chat(this.chatId).then((i) => { this.info = i; this.paintPins(); }).catch(() => {}); return; }
    const pins = (this.info && this.info.pinned) || [];
    this.pinbar.hidden = !pins.length; if (!pins.length) return;
    const p = pins[0];
    this.pinbar.replaceChildren(icon('pin'), h('span', { text: p.body || (p.attachments[0] && p.attachments[0].filename) || t.pinned }), pins.length > 1 ? h('small', { text: fmt.num(pins.length) }) : null);
    this.pinbar.onclick = () => this.jumpTo(p.id);
    this.pinbar.setAttribute('aria-label', t.pinned);
  }
  paintJump() { this.jump.hidden = this.atBottom; this.jumpBadge.hidden = !this.newCount; this.jumpBadge.textContent = fmt.num(this.newCount); }

  // ---------- scroll ----------
  onScroll() {
    const el = this.msgs; this.atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
    if (this.atBottom) { this.newCount = 0; this.markRead(); }
    this.paintJump();
    if (el.scrollTop < 120 && this.hasMore) this.loadMore();
  }
  scrollBottom(smooth = false) { requestAnimationFrame(() => { this.msgs.scrollTo({ top: this.msgs.scrollHeight, behavior: smooth ? 'smooth' : 'auto' }); }); this.atBottom = true; this.newCount = 0; this.paintJump(); }
  bindDrop() {
    let n = 0;
    this.el.addEventListener('dragenter', (e) => { if (e.dataTransfer?.types.includes('Files')) { n++; this.drop.hidden = false; } });
    this.el.addEventListener('dragleave', () => { n = Math.max(0, n - 1); if (!n) this.drop.hidden = true; });
    this.el.addEventListener('dragover', (e) => { if (e.dataTransfer?.types.includes('Files')) e.preventDefault(); });
    this.el.addEventListener('drop', (e) => { e.preventDefault(); n = 0; this.drop.hidden = true; if (e.dataTransfer.files.length) this.composer.addFiles([...e.dataTransfer.files]); });
  }

  // ---------- message actions ----------
  openActions(m, anchor) {
    const own = m.sender.id === state.user.id;
    const items = [{ label: t.reply, icon: 'reply', onClick: () => this.composer.setReply(m) }];
    if (m.body) items.push({ label: t.copy, icon: 'copy', onClick: () => navigator.clipboard.writeText(m.body).then(() => toastInfo(t.copied)).catch(() => toastError({ message: 'کپی ممکن نشد' })) });
    const att = m.attachments && m.attachments[0];
    if (att) items.push({ label: t.download, icon: 'download', onClick: () => { const a = h('a', { href: att.url + '?download=1', download: att.filename }); document.body.append(a); a.click(); a.remove(); } });
    items.push({ label: m.pinned ? t.unpin : t.pin, icon: 'pin', onClick: () => api.pin(m.id).catch(toastError) });
    if (own) {
      items.push('sep');
      if (m.kind === 'text') items.push({ label: t.edit, icon: 'edit', onClick: () => this.composer.setEdit(m) });
      for (const [label, s] of t.ttlOpts) items.push({ label: `${t.timer}: ${label}`, icon: 'clock', onClick: () => api.setExpiry(m.id, s).catch(toastError) });
      items.push({ label: `${t.timer}: ${t.customTimer}`, icon: 'clock', onClick: async () => {
        const v = await promptDialog({ title: t.customTimer, label: `${t.customTtlPrompt} — ${t.seconds}`, value: '120', type: 'number' });
        const n = Math.round(Number(v)); if (!v || !Number.isFinite(n)) return; api.setExpiry(m.id, n).catch(toastError);
      } });
      if (m.expires_at) items.push({ label: t.removeTimer, icon: 'x', onClick: () => api.setExpiry(m.id, null).catch(toastError) });
      items.push('sep', { label: t.delete, icon: 'trash', danger: true, onClick: async () => { if (await confirmDialog(t.confirmDeleteMsg, { danger: true, okText: t.delete })) api.del(m.id).catch(toastError); } });
    }
    openMenu(anchor, items, own ? { prio: { current: m.priority, onPick: (p) => { if (p !== m.priority) api.setPriority(m.id, p).catch(toastError); } } } : undefined);
  }

  destroy() {
    this.dead = true; clearInterval(this.tick); this.ws && this.ws.close(); this.composer.destroy();
    document.removeEventListener('tg:keyboard', this.onKb); document.removeEventListener('visibilitychange', this.onVis);
  }
}
