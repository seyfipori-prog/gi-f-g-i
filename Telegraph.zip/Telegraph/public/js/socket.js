// Reconnecting WebSocket with exponential backoff, 25s keepalive ping, and an onopen(isReconnect) hook.
export function connect(path, { onMessage, onOpen, onClose }) {
  let ws = null; let closed = false; let tries = 0; let pingT = null; let retryT = null; let hadOpen = false;
  function open() {
    if (closed) return;
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    ws = new WebSocket(`${proto}://${location.host}${path}`);
    ws.onopen = () => {
      const re = hadOpen; hadOpen = true; tries = 0;
      clearInterval(pingT); pingT = setInterval(() => { try { ws.send('ping'); } catch { /* ignore */ } }, 25000);
      onOpen && onOpen(re);
    };
    ws.onmessage = (e) => {
      if (e.data === 'pong' || e.data === 'ping') return;
      let m; try { m = JSON.parse(e.data); } catch { return; }
      onMessage && onMessage(m);
    };
    ws.onclose = (e) => {
      clearInterval(pingT); onClose && onClose(e);
      if (closed) return;
      if (e.code === 4401 || e.code === 4403) return; // unauthorized / kicked: do not retry
      const delay = Math.min(15000, 500 * 2 ** tries++) + Math.random() * 400;
      retryT = setTimeout(open, delay);
    };
    ws.onerror = () => { try { ws.close(); } catch { /* ignore */ } };
  }
  open();
  const onVisible = () => { if (!document.hidden && ws && ws.readyState > 1 && !closed) { clearTimeout(retryT); tries = 0; open(); } };
  document.addEventListener('visibilitychange', onVisible);
  window.addEventListener('online', onVisible);
  return {
    send(obj) { if (ws && ws.readyState === 1) { ws.send(typeof obj === 'string' ? obj : JSON.stringify(obj)); return true; } return false; },
    close() { closed = true; clearInterval(pingT); clearTimeout(retryT); document.removeEventListener('visibilitychange', onVisible); window.removeEventListener('online', onVisible); try { ws && ws.close(1000); } catch { /* ignore */ } },
    get open() { return !!ws && ws.readyState === 1; },
  };
}
