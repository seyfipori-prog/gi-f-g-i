import { h, $ } from '../dom.js';
import { t } from '../i18n.js';

let stack = [];
export function openModal(content, { onClose, dismissible = true } = {}) {
  const prev = document.activeElement;
  const m = h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' }, content);
  const back = h('div', { class: 'backdrop' }, m);
  const close = () => { back.remove(); stack = stack.filter((x) => x !== close); document.removeEventListener('keydown', onKey, true); onClose && onClose(); prev && prev.focus && prev.focus(); };
  const onKey = (e) => { if (e.key === 'Escape' && stack[stack.length - 1] === close && dismissible) { e.stopPropagation(); close(); } };
  back.addEventListener('mousedown', (e) => { if (e.target === back && dismissible) close(); });
  document.addEventListener('keydown', onKey, true);
  $('#overlay-root').append(back); stack.push(close);
  const first = m.querySelector('input, textarea, button'); first && first.focus();
  return close;
}
export function confirmDialog(message, { okText = t.confirm, danger = false } = {}) {
  return new Promise((resolve) => {
    let done = false;
    const fin = (v) => { if (!done) { done = true; close(); resolve(v); } };
    const close = openModal([
      h('p', { text: message }),
      h('div', { class: 'actions' },
        h('button', { class: 'btn ' + (danger ? 'danger' : 'primary'), type: 'button', onclick: () => fin(true), text: okText }),
        h('button', { class: 'btn', type: 'button', onclick: () => fin(false), text: t.cancel })),
    ], { onClose: () => { if (!done) { done = true; resolve(false); } } });
  });
}
export function promptDialog({ title, label, value = '', okText = t.save, type = 'text', hint, multiline = false }) {
  return new Promise((resolve) => {
    let done = false;
    const input = multiline ? h('textarea', { class: 'input', rows: 4, style: null }) : h('input', { class: 'input', type, value, autocomplete: 'off' });
    if (multiline) input.value = value;
    const fin = (v) => { if (!done) { done = true; close(); resolve(v); } };
    const form = h('form', { class: 'modal-form', onsubmit: (e) => { e.preventDefault(); fin(input.value); } },
      h('label', { class: 'field' }, label ? h('span', { text: label }) : null, input, hint ? h('span', { class: 'hint', text: hint }) : null),
      h('div', { class: 'actions' },
        h('button', { class: 'btn primary', type: 'submit', text: okText }),
        h('button', { class: 'btn', type: 'button', onclick: () => fin(null), text: t.cancel })));
    form.style.display = 'flex'; form.style.flexDirection = 'column'; form.style.gap = '14px';
    const close = openModal([h('h2', { text: title }), form], { onClose: () => { if (!done) { done = true; resolve(null); } } });
  });
}
