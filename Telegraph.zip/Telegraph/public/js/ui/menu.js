import { h, $, isMobile } from '../dom.js';
import { icon } from '../icons.js';
import { t } from '../i18n.js';

let current = null;
export function closeMenu() { if (current) { current(); current = null; } }

// items: [{label, icon, onClick, danger}] | 'sep'. anchor: DOMRect|Element. prio: {current, onPick} (optional priority row).
export function openMenu(anchor, items, { prio } = {}) {
  closeMenu();
  const el = h('div', { class: 'pop', role: 'menu' });
  if (prio) {
    el.append(h('div', { class: 'prio-row', role: 'radiogroup', 'aria-label': t.priority },
      ['normal', 'good', 'important', 'critical'].map((p) => {
        const b = h('button', { type: 'button', role: 'radio', 'aria-checked': String(prio.current === p), dataset: { priority: p }, onclick: () => { closeMenu(); prio.onPick(p); } },
          h('span', { class: 'bang', text: '!' }), h('span', { text: t.prio[p] }));
        b.style.setProperty('--pc', `var(--p-${p})`);
        return b;
      })));
  }
  for (const it of items) {
    if (it === 'sep') { el.append(h('div', { class: 'sep' })); continue; }
    el.append(h('button', { class: 'item' + (it.danger ? ' danger' : ''), type: 'button', role: 'menuitem', onclick: () => { closeMenu(); it.onClick(); } },
      it.icon ? icon(it.icon) : null, h('span', { text: it.label })));
  }
  const back = h('div', { class: 'backdrop', style: null });
  back.style.background = isMobile() ? 'rgba(0,0,0,.5)' : 'transparent'; back.style.display = 'block'; back.style.zIndex = '105';
  back.addEventListener('mousedown', closeMenu); back.addEventListener('touchstart', (e) => { if (e.target === back) closeMenu(); }, { passive: true });
  const root = $('#overlay-root'); root.append(back, el);
  if (isMobile()) el.classList.add('sheet');
  else {
    const r = anchor.getBoundingClientRect ? anchor.getBoundingClientRect() : anchor;
    const w = el.offsetWidth; const hh = el.offsetHeight;
    let left = r.left + r.width / 2 - w / 2; left = Math.max(8, Math.min(left, innerWidth - w - 8));
    let top = r.bottom + 6; if (top + hh > innerHeight - 8) top = Math.max(8, r.top - hh - 6);
    el.style.left = left + 'px'; el.style.top = top + 'px';
  }
  const onKey = (e) => { if (e.key === 'Escape') closeMenu(); };
  document.addEventListener('keydown', onKey);
  const first = el.querySelector('button'); first && first.focus();
  current = () => { back.remove(); el.remove(); document.removeEventListener('keydown', onKey); };
  return closeMenu;
}
