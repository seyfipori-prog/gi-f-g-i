import { h, $ } from '../dom.js';
import { icon } from '../icons.js';
import { errText } from '../i18n.js';

export function toast({ title, text, priority = 'normal', err = false, onClick, ms = 4500 }) {
  const root = $('#toast-root');
  const el = h('button', { class: 'toast' + (err ? ' err' : ''), type: 'button', dataset: { priority } },
    err ? h('span', { class: 'bang', text: '!' }) : h('span', { class: 'bang', text: '!' }),
    h('span', { class: 'grow' }, title ? h('b', { text: title }) : null, text ? h('span', { text }) : null));
  const close = () => { el.classList.add('out'); setTimeout(() => el.remove(), 220); };
  el.addEventListener('click', () => { close(); onClick && onClick(); });
  root.append(el);
  while (root.children.length > 3) root.firstChild.remove();
  setTimeout(close, ms);
  return close;
}
export const toastError = (e) => toast({ text: e?.code ? errText(e.code) : (e?.message || errText()), err: true });
export const toastInfo = (text) => toast({ text, priority: 'good' });
