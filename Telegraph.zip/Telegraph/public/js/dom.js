// Tiny DOM helpers. Text is always set via textContent — user content never touches innerHTML.
export function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  if (props) {
    for (const [k, v] of Object.entries(props)) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'dataset') Object.assign(el.dataset, v);
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === 'text') el.textContent = v;
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
  }
  add(el, kids);
  return el;
}
function add(el, kids) {
  for (const k of kids.flat(Infinity)) {
    if (k == null || k === false) continue;
    el.append(k.nodeType ? k : document.createTextNode(String(k)));
  }
}
export const $ = (sel, root = document) => root.querySelector(sel);
export function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }
export function bdi(text, ltr = false) { const b = document.createElement('bdi'); if (ltr) b.dir = 'ltr'; b.textContent = text; return b; }
export const isTouch = () => matchMedia('(pointer: coarse)').matches;
export const isMobile = () => matchMedia('(max-width: 860px)').matches;
export function initials(name) { const t = String(name || '?').trim(); return [...t][0]?.toUpperCase() || '?'; }
export function avatar(user, cls = '') {
  const a = h('span', { class: 'avatar ' + cls, 'aria-hidden': 'true', text: initials(user.display_name || user.username) });
  a.style.setProperty('--av', user.color || '#34d399');
  return a;
}
const URL_RE = /(https?:\/\/[^\s<>"']+)/g;
// Linkify safely: build nodes, only http(s) URLs, rel=noopener, isolated LTR.
export function linkify(text) {
  const frag = document.createDocumentFragment();
  let last = 0; let m;
  URL_RE.lastIndex = 0;
  while ((m = URL_RE.exec(text))) {
    let url = m[0]; let trail = '';
    const t = url.match(/[.,;:!?)\]،؛؟]+$/); if (t) { trail = t[0]; url = url.slice(0, -trail.length); }
    if (m.index > last) frag.append(text.slice(last, m.index));
    try {
      const u = new URL(url);
      if (u.protocol === 'http:' || u.protocol === 'https:') {
        const a = h('a', { href: u.href, target: '_blank', rel: 'noopener noreferrer nofollow', dir: 'ltr' });
        a.textContent = url; frag.append(a);
      } else frag.append(url);
    } catch { frag.append(url); }
    if (trail) frag.append(trail);
    last = m.index + m[0].length;
  }
  if (last < text.length) frag.append(text.slice(last));
  return frag;
}
export function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }
