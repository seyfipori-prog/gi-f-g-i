import { h, clear, $ } from './dom.js';
import { icon } from './icons.js';
import { t } from './i18n.js';
import { api, setUnauthorizedHandler } from './api.js';
import { state, bus } from './store.js';
import { connect } from './socket.js';
import { parseRoute, go } from './nav.js';
import { initViewport } from './viewport.js';
import { renderAuth } from './views/auth.js';
import { createSidebar } from './views/sidebar.js';
import { ChatView } from './views/chat.js';
import { createBell, refreshNotifs, handleIncoming } from './views/notifications.js';
import { openNewChat } from './views/members.js';
import { toastInfo } from './ui/toast.js';

const root = $('#root');
let inbox = null; let view = null; let sidebar = null; let shell = null; let chatsT = null;

function showAuth() {
  teardown();
  document.title = t.appName;
  renderAuth(root, (user) => { state.user = user; start(); });
}
function teardown() {
  if (view) { view.destroy(); view = null; }
  if (inbox) { inbox.close(); inbox = null; }
  state.activeChatId = null; state.chats = []; state.unreadNotifs = 0; shell = null; sidebar = null;
  root.classList.remove('boot'); clear(root);
}

async function loadChats() {
  try { const r = await api.chats(); state.chats = r.chats; bus.emit('chats'); } catch { /* offline */ }
}
const loadChatsSoon = () => { clearTimeout(chatsT); chatsT = setTimeout(loadChats, 150); };

async function logout() {
  try { await api.logout(); } catch { /* ignore */ }
  showAuth();
}

function start() {
  teardown();
  const app = h('div', { class: 'app' });
  const closeDrawer = () => app.classList.remove('drawer-open');
  sidebar = createSidebar({ onLogout: logout, closeDrawer });
  const title = h('b', { text: t.appName }); const sub = h('small');
  const membersBtn = h('button', { class: 'icon-btn', type: 'button', 'aria-label': t.members, hidden: true }, icon('users'));
  const header = h('header', { class: 'header' },
    // DOM order inside an RTL header: first = visually RIGHT (New Chat), last = LEFT (menu).
    h('button', { class: 'icon-btn only-mobile', type: 'button', 'aria-label': t.newChat, onclick: openNewChat }, icon('plus')),
    h('div', { class: 'h-title' }, title, sub),
    h('div', { class: 'h-actions' }, membersBtn, createBell()),
    h('button', { class: 'icon-btn only-mobile', type: 'button', 'aria-label': t.menu || 'منو', 'aria-expanded': 'false', onclick: () => app.classList.toggle('drawer-open') }, icon('menu')));
  const content = h('div', { class: 'chat-slot', style: null });
  content.style.flex = '1'; content.style.minHeight = '0'; content.style.display = 'flex'; content.style.flexDirection = 'column';
  const main = h('main', { class: 'main' }, header, content);
  const scrim = h('div', { class: 'scrim', onclick: closeDrawer });
  app.append(sidebar.el, scrim, main);
  root.append(app); shell = { app, content, title, sub, membersBtn };
  initViewport();

  const setHeader = ({ title: ti, sub: s, onMembers }) => {
    title.textContent = ti || t.appName; sub.textContent = s || ''; document.title = ti ? `${ti} · ${t.appName}` : t.appName;
    membersBtn.hidden = !onMembers; membersBtn.onclick = onMembers || null;
  };
  const showEmpty = () => {
    if (view) { view.destroy(); view = null; }
    state.activeChatId = null; bus.emit('active'); setHeader({});
    clear(content).append(h('div', { class: 'empty-state' }, h('div', {},
      h('img', { src: '/logo/telegraph-mark.png', alt: '' }), h('h2', { text: t.pickChat }), h('p', { text: t.pickChatSub }),
      h('button', { class: 'btn primary', type: 'button', onclick: openNewChat }, icon('plus'), t.newChat))));
  };
  const route = ({ chatId, messageId }) => {
    closeDrawer();
    if (!chatId) { showEmpty(); return; }
    if (view && state.activeChatId === chatId) { if (messageId) view.jumpTo(messageId); return; }
    if (view) view.destroy();
    state.activeChatId = chatId; bus.emit('active'); setHeader({ title: '…' });
    view = new ChatView(chatId, { setHeader, highlight: messageId, onGone: () => { go(null, null, { replace: true }); loadChats(); } });
    clear(content).append(view.el);
    if (!matchMedia('(pointer: coarse)').matches) setTimeout(() => view && view.composer.focus(), 50);
  };
  bus.on('route', route);

  // Inbox socket: chat-list updates and notifications for every conversation.
  inbox = connect('/ws/inbox', {
    onOpen: (re) => { if (re) { loadChats(); refreshNotifs(); } },
    onMessage: (m) => {
      if (m.type === 'chat.updated') { loadChatsSoon(); if (m.notification) handleIncoming(m.notification); }
      else if (m.type === 'notification.updated') refreshNotifs();
      else if (m.type === 'chat.removed') { loadChatsSoon(); if (state.activeChatId === m.chat_id) { go(null, null, { replace: true }); } }
    },
    onClose: (e) => { if (e.code === 4401) showAuth(); },
  });
  document.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); sidebar && sidebar.focusSearch(); } });
  loadChats().then(() => route(parseRoute()));
  refreshNotifs();
}

setUnauthorizedHandler(() => { if (state.user) { state.user = null; showAuth(); toastInfo(t.sessionExpired); } });

(async function boot() {
  try { const r = await api.me(); state.user = r.user; start(); }
  catch (e) {
    if (e.code === 'network') { root.classList.remove('boot'); clear(root).append(h('div', { class: 'empty-state' }, h('div', {}, h('p', { text: t.offline }), h('button', { class: 'btn', type: 'button', onclick: () => location.reload(), text: t.retry })))); }
    else showAuth();
  }
})();
