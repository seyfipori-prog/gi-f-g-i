// Minimal reactive store + event bus.
const subs = new Map();
export const bus = {
  on(ev, fn) { if (!subs.has(ev)) subs.set(ev, new Set()); subs.get(ev).add(fn); return () => subs.get(ev).delete(fn); },
  emit(ev, data) { (subs.get(ev) || []).forEach((fn) => { try { fn(data); } catch (e) { console.error(e); } }); },
};
export const state = {
  user: null,
  chats: [],            // chat list items
  activeChatId: null,
  unreadNotifs: 0,
  notifPriority: 'normal',
  online: false,
};
export function setState(patch, ev) { Object.assign(state, patch); if (ev) bus.emit(ev, state); }
