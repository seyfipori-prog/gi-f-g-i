// END-TO-END ENCRYPTION — SCAFFOLD ONLY. Disabled. NOT used by the app.
// Telegraph currently encrypts messages SERVER-SIDE at rest (AES-GCM). The server can read plaintext.
// That is not E2EE and the UI never claims it is. See SECURITY.md for the full design.
// These helpers generate/export an ECDH P-256 identity and derive a shared AES-GCM key using Web Crypto.
// To ship real E2EE you still need: private-key storage (non-extractable CryptoKey in IndexedDB),
// key exchange per conversation, safety-number verification, encrypted attachments, multi-device sync.
export const E2EE_ENABLED = false;

export async function generateIdentity() {
  const kp = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveKey']);
  const publicJwk = await crypto.subtle.exportKey('jwk', kp.publicKey);
  return { privateKey: kp.privateKey, publicJwk };
}
export async function deriveConversationKey(privateKey, peerPublicJwk) {
  const peer = await crypto.subtle.importKey('jwk', peerPublicJwk, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  return crypto.subtle.deriveKey({ name: 'ECDH', public: peer }, privateKey, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
export async function encryptMessage(key, plaintext, aad) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(aad) }, key, new TextEncoder().encode(plaintext));
  return { iv, ct: new Uint8Array(ct) };
}
export async function decryptMessage(key, iv, ct, aad) {
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(aad) }, key, ct);
  return new TextDecoder().decode(pt);
}
