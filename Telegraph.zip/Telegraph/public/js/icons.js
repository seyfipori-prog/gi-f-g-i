const NS = 'http://www.w3.org/2000/svg';
const P = {
  plus: 'M12 5v14M5 12h14',
  menu: 'M4 7h16M4 12h16M4 17h16',
  search: 'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-4.3-4.3',
  send: 'M5 12l14-8-4 16-3-6-7-2z',
  clip: 'M20 11l-8.5 8.5a5 5 0 0 1-7-7L13 4a3.5 3.5 0 0 1 5 5l-8.5 8.5a2 2 0 0 1-3-3L14 7',
  mic: 'M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3zM6 11a6 6 0 0 0 12 0M12 17v4',
  stop: 'M7 7h10v10H7z',
  x: 'M6 6l12 12M18 6L6 18',
  bell: 'M6 16V11a6 6 0 0 1 12 0v5l2 2H4zM10 21h4',
  settings: 'M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM19 12l2-1-2-4-2 .5a7 7 0 0 0-2-1.2L14 4h-4l-1 2.3a7 7 0 0 0-2 1.2L5 7l-2 4 2 1a7 7 0 0 0 0 2l-2 1 2 4 2-.5a7 7 0 0 0 2 1.2L10 22h4l1-2.3a7 7 0 0 0 2-1.2l2 .5 2-4-2-1a7 7 0 0 0 0-2z',
  logout: 'M9 4H5v16h4M16 8l4 4-4 4M20 12H9',
  reply: 'M10 8L4 13l6 5v-3c6 0 9 1 10 5 0-6-3-10-10-10z',
  copy: 'M8 8h11v12H8zM5 16V4h11',
  edit: 'M4 20h4L19 9l-4-4L4 16zM13 7l4 4',
  trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13',
  pin: 'M12 17v5M8 3h8l-1 6 3 4H6l3-4z',
  clock: 'M12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16zM12 8v4l3 2',
  check: 'M5 12l5 5 9-10',
  file: 'M7 3h7l5 5v13H7zM14 3v5h5',
  video: 'M4 6h11v12H4zM15 10l5-3v10l-5-3',
  download: 'M12 4v11M7 11l5 5 5-5M5 20h14',
  users: 'M9 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM3 20a6 6 0 0 1 12 0M17 11a2.5 2.5 0 1 0 0-5M21 20a5 5 0 0 0-4-5',
  down: 'M6 9l6 6 6-6',
  play: 'M8 5l11 7-11 7z',
  pause: 'M8 5v14M16 5v14',
  flag: 'M5 21V4M5 4h12l-2 4 2 4H5',
  shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z',
};
export function icon(name, cls = '') {
  const s = document.createElementNS(NS, 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'icon ' + cls); s.setAttribute('aria-hidden', 'true');
  const p = document.createElementNS(NS, 'path'); p.setAttribute('d', P[name] || P.file); s.append(p);
  return s;
}
export function ticks(n) { // 1 = sent, 2 = delivered/read
  const s = icon('check'); if (n < 2) return s;
  const w = document.createElement('span'); w.style.display = 'inline-flex';
  const b = icon('check'); b.style.marginInlineStart = '-9px'; w.append(icon('check'), b); return w;
}
