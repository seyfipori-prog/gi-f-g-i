// Persian strings, error-code map and locale-aware formatters.
export const t = {
  appName: 'تلگراف', newChat: 'گفتگوی جدید', search: 'جستجو در گفتگوها و پیام‌ها…', logout: 'خروج', settings: 'تنظیمات',
  login: 'ورود', register: 'ثبت‌نام', username: 'نام کاربری', password: 'گذرواژه', displayName: 'نام نمایشی',
  today: 'امروز', yesterday: 'دیروز', noChats: 'هنوز گفتگویی ندارید.', noResults: 'نتیجه‌ای پیدا نشد.',
  pickChat: 'یک گفتگو را انتخاب کنید', pickChatSub: 'یا گفتگوی تازه‌ای شروع کنید.',
  typeMsg: 'پیام خود را بنویسید…', send: 'ارسال', attach: 'پیوست', voice: 'پیام صوتی',
  reply: 'پاسخ', copy: 'کپی', edit: 'ویرایش', delete: 'حذف', pin: 'سنجاق', unpin: 'برداشتن سنجاق',
  download: 'دانلود', open: 'باز کردن', cancel: 'انصراف', save: 'ذخیره', confirm: 'تأیید', close: 'بستن',
  copied: 'کپی شد', edited: 'ویرایش‌شده', deletedMsg: 'این پیام حذف شد', you: 'شما', online: 'آنلاین', typing: 'در حال نوشتن…',
  priority: 'اولویت', timer: 'پیام زمان‌دار', removeTimer: 'حذف زمان‌بندی', customTimer: 'زمان دلخواه…',
  members: 'اعضا', addMember: 'افزودن عضو', leave: 'ترک گفتگو', deleteChat: 'حذف گفتگو', rename: 'تغییر نام',
  notifications: 'اعلان‌ها', markAllRead: 'خواندن همه', noNotifs: 'اعلانی وجود ندارد.',
  recording: 'در حال ضبط…', uploadFailed: 'بارگذاری ناموفق بود', pinned: 'پیام سنجاق‌شده',
  loadingMore: 'در حال بارگذاری…', sessionExpired: 'نشست شما منقضی شد. دوباره وارد شوید.', offline: 'اتصال قطع است…',
  prio: { normal: 'معمولی', good: 'خوب', important: 'مهم', critical: 'بحرانی' },
  ttlOpts: [['۳۰ ثانیه', 30], ['۵ دقیقه', 300], ['۱ ساعت', 3600], ['۲۴ ساعت', 86400]],
  profile: 'پروفایل', changePassword: 'تغییر گذرواژه', currentPassword: 'گذرواژه فعلی', newPassword: 'گذرواژه جدید',
  enableNotifs: 'فعال‌سازی اعلان مرورگر', passwordChanged: 'گذرواژه تغییر کرد', saved: 'ذخیره شد',
  e2eeNote: 'پیام‌ها در سرور رمزنگاری می‌شوند (رمزنگاری سمت سرور)؛ این به معنای رمزنگاری سرتاسری نیست.',
  usernameHint: 'حروف انگلیسی، عدد، _ و . (۳ تا ۳۲ نویسه)', passwordHint: 'حداقل ۸ نویسه',
  chatTitle: 'عنوان گفتگو', membersHint: 'نام کاربری اعضا (با ویرگول جدا کنید)', create: 'ایجاد', add: 'افزودن',
  expiresIn: 'حذف خودکار', mic_denied: 'دسترسی به میکروفون ممکن نیست', mic_unsupported: 'مرورگر شما ضبط صدا را پشتیبانی نمی‌کند',
  dropFiles: 'فایل‌ها را اینجا رها کنید', chats: 'گفتگوها', messages: 'پیام‌ها', files: 'فایل‌ها', jumpLatest: 'رفتن به آخرین پیام',
  seconds: 'ثانیه', minutes: 'دقیقه', hours: 'ساعت', days: 'روز', customTtlPrompt: 'مدت زمان (۵ ثانیه تا ۳۰ روز)', unit: 'واحد', amount: 'مقدار',
  confirmDeleteMsg: 'این پیام برای همه حذف شود؟', confirmDeleteChat: 'این گفتگو برای همه اعضا به‌طور کامل حذف شود؟', confirmLeave: 'از این گفتگو خارج می‌شوید؟',
  connecting: 'در حال اتصال…', retry: 'تلاش دوباره',
};
const ERR = {
  invalid_credentials: 'نام کاربری یا گذرواژه نادرست است.', username_taken: 'این نام کاربری قبلاً گرفته شده است.',
  bad_username: 'نام کاربری معتبر نیست (۳ تا ۳۲ نویسه: حروف انگلیسی، عدد، _ و .).', weak_password: 'گذرواژه باید ۸ تا ۱۲۸ نویسه باشد.',
  registration_closed: 'ثبت‌نام فعلاً بسته است.', rate_limited: 'درخواست‌های زیادی ارسال شد. کمی بعد دوباره تلاش کنید.',
  unauthorized: 'ابتدا وارد شوید.', csrf: 'درخواست نامعتبر است. صفحه را بازنشانی کنید.', bad_origin: 'درخواست نامعتبر است.',
  chat_not_found: 'گفتگو پیدا نشد.', message_not_found: 'پیام پیدا نشد یا منقضی شده است.', file_not_found: 'فایل پیدا نشد.',
  user_not_found: 'کاربر پیدا نشد.', not_your_message: 'فقط فرستنده می‌تواند این کار را انجام دهد.', owner_only: 'فقط مالک گفتگو مجاز است.',
  empty_message: 'پیام خالی است.', empty_title: 'عنوان نمی‌تواند خالی باشد.', bad_priority: 'اولویت نامعتبر است.', bad_ttl: 'زمان نامعتبر است (۵ ثانیه تا ۳۰ روز).',
  not_editable: 'این پیام قابل ویرایش نیست.', too_many_pins: 'تعداد پیام‌های سنجاق‌شده به حد مجاز رسیده است.', chat_full: 'ظرفیت اعضای گفتگو تکمیل است.',
  file_too_large: 'حجم فایل از حد مجاز بیشتر است.', unsupported_type: 'نوع فایل پشتیبانی نمی‌شود.', file_blocked: 'محتوای فایل با نوع اعلام‌شده نمی‌خواند یا مسدود شد.',
  empty_file: 'فایل خالی است.', length_required: 'اندازه فایل مشخص نیست.', body_too_large: 'درخواست بیش از حد بزرگ است.', bad_attachment: 'پیوست نامعتبر است.',
  upload_failed: 'بارگذاری ناموفق بود.', bad_member: 'عضو نامعتبر است.', not_found: 'پیدا نشد.', method_not_allowed: 'درخواست نامعتبر است.',
  network: 'اتصال به سرور برقرار نشد.', server_misconfigured: 'سرور درست پیکربندی نشده است.',
};
export const errText = (code) => ERR[code] || 'خطایی رخ داد. دوباره تلاش کنید.';

const nf = new Intl.NumberFormat('fa-IR');
const timeF = new Intl.DateTimeFormat('fa-IR', { hour: '2-digit', minute: '2-digit', hour12: false });
const dateF = new Intl.DateTimeFormat('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' });
const shortF = new Intl.DateTimeFormat('fa-IR', { month: 'short', day: 'numeric' });
export const fmt = {
  num: (n) => nf.format(n),
  time: (ts) => timeF.format(new Date(ts)),
  date: (ts) => dateF.format(new Date(ts)),
  short: (ts) => shortF.format(new Date(ts)),
  dayKey: (ts) => { const d = new Date(ts); return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`; },
  dayLabel(ts) {
    const k = fmt.dayKey(ts);
    if (k === fmt.dayKey(Date.now())) return t.today;
    if (k === fmt.dayKey(Date.now() - 864e5)) return t.yesterday;
    return fmt.date(ts);
  },
  listTime(ts) { return fmt.dayKey(ts) === fmt.dayKey(Date.now()) ? fmt.time(ts) : fmt.short(ts); },
  size(b) {
    if (b < 1024) return nf.format(b) + ' B';
    if (b < 1048576) return nf.format(Math.round(b / 1024)) + ' KB';
    return nf.format(Math.round(b / 104857.6) / 10) + ' MB';
  },
  dur(ms) { const s = Math.max(0, Math.round(ms / 1000)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; },
  remaining(ts) {
    const s = Math.max(0, Math.ceil((ts - Date.now()) / 1000));
    if (s < 60) return nf.format(s) + ' ثانیه';
    if (s < 3600) return nf.format(Math.ceil(s / 60)) + ' دقیقه';
    if (s < 86400) return nf.format(Math.ceil(s / 3600)) + ' ساعت';
    return nf.format(Math.ceil(s / 86400)) + ' روز';
  },
};
