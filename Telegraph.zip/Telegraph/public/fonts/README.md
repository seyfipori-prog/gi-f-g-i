# Fonts

The UI uses **Vazirmatn** when available. To self-host it (the CSP allows only same-origin fonts):

1. Download `Vazirmatn[wght].woff2` from https://github.com/rastikerdar/vazirmatn
2. Save it here as `Vazirmatn.woff2`.
3. Uncomment the `@font-face` block in `public/css/fonts.css`.

Without the file the app falls back to system fonts (Tahoma / Segoe UI / system-ui), which render Persian correctly.
