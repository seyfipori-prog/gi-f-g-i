# Logo assets
Derived from the logo image supplied by the project owner (`source-original.jpg`).
- `telegraph-mark.png` — shield mark, transparent background
- `telegraph-lockup.png` — mark + TELEGRAPH wordmark, transparent (the "AI MESSAGING PLATFORM" tagline was intentionally left out)
- `favicon-32.png`, `icon-192.png`, `icon-512.png`, `apple-touch-icon.png` — app icons
Replace these files to rebrand; paths are referenced from `index.html`, `manifest.webmanifest` and the UI.
