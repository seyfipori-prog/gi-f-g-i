-- Telegraph consolidated schema snapshot (generated from migrations/*.sql).
-- Fresh installs should run: wrangler d1 migrations apply telegraph-db --remote

-- Telegraph core schema. Timestamps are unix epoch milliseconds.

CREATE TABLE users (
  id            TEXT PRIMARY KEY,
  username      TEXT NOT NULL COLLATE NOCASE UNIQUE,
  display_name  TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  color         TEXT NOT NULL DEFAULT '#34d399',
  created_at    INTEGER NOT NULL,
  last_seen_at  INTEGER
);

CREATE TABLE sessions (
  id           TEXT PRIMARY KEY,               -- SHA-256(token) hex; the token itself is never stored
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at   INTEGER NOT NULL,
  expires_at   INTEGER NOT NULL,
  last_used_at INTEGER NOT NULL,
  ip_hash      TEXT,
  user_agent   TEXT
);
CREATE INDEX idx_sessions_user    ON sessions(user_id);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

CREATE TABLE chats (
  id              TEXT PRIMARY KEY,
  title           TEXT NOT NULL,
  type            TEXT NOT NULL DEFAULT 'chat',
  created_by      TEXT NOT NULL REFERENCES users(id),
  created_at      INTEGER NOT NULL,
  updated_at      INTEGER NOT NULL,
  last_message_at INTEGER
);
CREATE INDEX idx_chats_updated ON chats(updated_at DESC);

CREATE TABLE chat_members (
  chat_id   TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  user_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role      TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('owner','member')),
  muted     INTEGER NOT NULL DEFAULT 0,
  joined_at INTEGER NOT NULL,
  PRIMARY KEY (chat_id, user_id)
) WITHOUT ROWID;
CREATE INDEX idx_chat_members_user ON chat_members(user_id);

CREATE TABLE messages (
  seq          INTEGER PRIMARY KEY AUTOINCREMENT,   -- monotonic cursor for pagination
  id           TEXT NOT NULL UNIQUE,
  chat_id      TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  sender_id    TEXT NOT NULL REFERENCES users(id),
  kind         TEXT NOT NULL DEFAULT 'text' CHECK (kind IN ('text','file','voice','system')),
  body         TEXT,                                -- 'enc1:<keyId>:<iv>:<ciphertext>' (server-side encryption at rest)
  priority     TEXT NOT NULL DEFAULT 'normal' CHECK (priority IN ('normal','good','important','critical')),
  reply_to_id  TEXT REFERENCES messages(id) ON DELETE SET NULL,
  e2ee_version INTEGER,                             -- NULL = server-side encryption only (see SECURITY.md)
  created_at   INTEGER NOT NULL,
  edited_at    INTEGER,
  deleted_at   INTEGER,                             -- tombstone: body is NULLed
  expires_at   INTEGER                              -- enforced server-side in every query + purge job
);
CREATE INDEX idx_messages_chat_seq      ON messages(chat_id, seq);
CREATE INDEX idx_messages_chat_priority ON messages(chat_id, priority, seq);
CREATE INDEX idx_messages_expires       ON messages(expires_at) WHERE expires_at IS NOT NULL;
CREATE INDEX idx_messages_sender        ON messages(sender_id);
CREATE INDEX idx_messages_reply         ON messages(reply_to_id) WHERE reply_to_id IS NOT NULL;

CREATE TABLE message_status (
  message_id   TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  chat_id      TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,   -- the recipient
  status       TEXT NOT NULL DEFAULT 'sent' CHECK (status IN ('sent','delivered','read')),
  delivered_at INTEGER,
  read_at      INTEGER,
  PRIMARY KEY (message_id, user_id)
) WITHOUT ROWID;
CREATE INDEX idx_status_unread ON message_status(user_id, chat_id) WHERE read_at IS NULL;

CREATE TABLE attachments (
  id          TEXT PRIMARY KEY,                     -- public identifier used by /api/files/:id
  chat_id     TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  message_id  TEXT REFERENCES messages(id) ON DELETE CASCADE,   -- NULL until the message is sent
  uploader_id TEXT NOT NULL REFERENCES users(id),
  r2_key      TEXT NOT NULL UNIQUE,                 -- never exposed to clients
  filename    TEXT NOT NULL,                        -- encrypted + sanitized
  mime        TEXT NOT NULL,                        -- detected/allow-listed, not browser-trusted
  size        INTEGER NOT NULL,
  category    TEXT NOT NULL CHECK (category IN ('image','video','audio','pdf','document')),
  is_voice    INTEGER NOT NULL DEFAULT 0,
  duration_ms INTEGER,
  scan_status TEXT NOT NULL DEFAULT 'skipped',      -- hook for malware scanning: pending|clean|infected|skipped
  created_at  INTEGER NOT NULL,
  deleted_at  INTEGER
);
CREATE INDEX idx_attachments_message ON attachments(message_id);
CREATE INDEX idx_attachments_chat    ON attachments(chat_id);
CREATE INDEX idx_attachments_orphans ON attachments(created_at) WHERE message_id IS NULL;

CREATE TABLE notifications (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  chat_id    TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  type       TEXT NOT NULL DEFAULT 'normal' CHECK (type IN ('normal','good','important','critical')),
  title      TEXT NOT NULL,                         -- sender display name
  preview    TEXT,                                  -- encrypted
  created_at INTEGER NOT NULL,
  read_at    INTEGER
);
CREATE INDEX idx_notifications_user    ON notifications(user_id, read_at, created_at DESC);
CREATE INDEX idx_notifications_message ON notifications(message_id);
CREATE INDEX idx_notifications_chat    ON notifications(user_id, chat_id) WHERE read_at IS NULL;

CREATE TABLE pinned_messages (
  chat_id    TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  pinned_by  TEXT NOT NULL REFERENCES users(id),
  pinned_at  INTEGER NOT NULL,
  PRIMARY KEY (chat_id, message_id)
) WITHOUT ROWID;

-- Blind index for message/filename search over encrypted content.
-- token = HMAC-SHA256(INDEX_KEY, normalized word). Plain words are never stored.
CREATE TABLE message_tokens (
  message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  chat_id    TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  token      TEXT NOT NULL,
  PRIMARY KEY (message_id, token)
) WITHOUT ROWID;
CREATE INDEX idx_tokens_lookup ON message_tokens(chat_id, token);

-- Public identity keys: scaffolding for future true end-to-end encryption (see SECURITY.md).
CREATE TABLE user_keys (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  algorithm  TEXT NOT NULL,
  public_key TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  revoked_at INTEGER
);
CREATE INDEX idx_user_keys_user ON user_keys(user_id, revoked_at);

-- Fixed-window counters for the rate limiter (src/security/ratelimit.js).
CREATE TABLE rate_limits (
  key          TEXT PRIMARY KEY,
  window_start INTEGER NOT NULL,
  count        INTEGER NOT NULL
) WITHOUT ROWID;
CREATE INDEX idx_rate_limits_window ON rate_limits(window_start);
