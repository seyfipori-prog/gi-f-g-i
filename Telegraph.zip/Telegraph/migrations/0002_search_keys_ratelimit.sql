-- Blind index for message/filename search over encrypted content.
-- token = HMAC-SHA256(INDEX_KEY, normalized word). Plain words are never stored.
CREATE TABLE message_tokens (
  message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  chat_id    TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  token      TEXT NOT NULL,
  PRIMARY KEY (message_id, token)
) WITHOUT ROWID;
CREATE INDEX idx_tokens_lookup ON message_tokens(chat_id, token);

-- Public identity keys: scaffolding for future true end-to-end encryption (see SECURITY.md).
CREATE TABLE user_keys (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  algorithm  TEXT NOT NULL,
  public_key TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  revoked_at INTEGER
);
CREATE INDEX idx_user_keys_user ON user_keys(user_id, revoked_at);

-- Fixed-window counters for the rate limiter (src/security/ratelimit.js).
CREATE TABLE rate_limits (
  key          TEXT PRIMARY KEY,
  window_start INTEGER NOT NULL,
  count        INTEGER NOT NULL
) WITHOUT ROWID;
CREATE INDEX idx_rate_limits_window ON rate_limits(window_start);
