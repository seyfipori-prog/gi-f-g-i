// Telegraph - single Cloudflare Worker entry point.
//   fetch      -> /api/*  REST API        (src/api)
//              -> /ws/*   WebSockets      (src/api/ws.js -> Durable Objects)
//              -> others  static frontend (public/ via the ASSETS binding)
//   scheduled  -> expiry purge + housekeeping (src/chat/cleanup.js)
import { handleRequest } from './src/api/router.js';
import { runScheduled } from './src/chat/cleanup.js';

export { ChatRoom } from './src/realtime/ChatRoom.js';
export { UserHub } from './src/realtime/UserHub.js';

export default {
  fetch(request, env, ctx) {
    return handleRequest(request, env, ctx);
  },
  scheduled(event, env, ctx) {
    ctx.waitUntil(runScheduled(env));
  },
};
