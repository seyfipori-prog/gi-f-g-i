import { HttpError, json, readJson, requireId } from '../security/http.js';
import * as chat from '../chat/service.js';
import { searchMessages } from '../chat/service.js';
import { isId } from '../security/http.js';

const bg = (execCtx, p) => execCtx && execCtx.waitUntil && execCtx.waitUntil(p.catch(() => {}));

export async function list({ env, url, user }) {
  const q = (url.searchParams.get('q') || '').trim().slice(0, 60);
  return json({ chats: await chat.listChats(env, user.id, q) });
}

export async function create({ request, env, user }) {
  const b = await readJson(request);
  return json(await chat.createChat(env, user, b), 201);
}

export async function get({ env, params, user }) {
  return json(await chat.getChat(env, user.id, requireId(params.id, 'chat_not_found')));
}

export async function rename({ request, env, execCtx, params, user }) {
  const b = await readJson(request);
  return json(await chat.renameChat(env, execCtx, user, requireId(params.id, 'chat_not_found'), b.title));
}

export async function remove({ env, execCtx, params, user }) {
  return json(await chat.deleteOrLeaveChat(env, execCtx, user, requireId(params.id, 'chat_not_found')));
}

export async function addMember({ request, env, execCtx, params, user }) {
  const b = await readJson(request);
  return json({ member: await chat.addMember(env, execCtx, user, requireId(params.id, 'chat_not_found'), b.username) }, 201);
}

export async function removeMember({ env, execCtx, params, user }) {
  return json(await chat.removeMember(env, execCtx, user, requireId(params.id, 'chat_not_found'), params.userId));
}

export async function listMessages({ env, execCtx, params, url, user }) {
  const chatId = requireId(params.id, 'chat_not_found');
  await chat.requireMember(env, chatId, user.id);
  const page = await chat.fetchPage(env, user.id, chatId, {
    before: url.searchParams.get('before'), limit: url.searchParams.get('limit'),
  });
  bg(execCtx, chat.markDeliveredForViewer(env, chatId, user.id));
  return json(page);
}

export async function createMessage({ request, env, execCtx, params, user }) {
  const b = await readJson(request, 32 * 1024);
  const message = await chat.createMessage(env, execCtx, user, requireId(params.id, 'chat_not_found'), b);
  return json({ message }, 201);
}

export async function markRead({ env, params, user }) {
  const chatId = requireId(params.id, 'chat_not_found');
  await chat.requireMember(env, chatId, user.id);
  return json({ updated: await chat.markRead(env, chatId, user.id) });
}

export async function search({ env, url, user }) {
  const chatId = url.searchParams.get('chat_id');
  if (chatId && !isId(chatId)) throw new HttpError(400, 'bad_chat');
  const results = await searchMessages(env, user.id, {
    q: (url.searchParams.get('q') || '').slice(0, 100),
    priority: url.searchParams.get('priority') || null,
    chatId: chatId || null,
    scope: url.searchParams.get('scope') || 'all',
    limit: url.searchParams.get('limit'),
  });
  return json({ results });
}
