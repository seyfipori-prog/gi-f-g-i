import { json, readJson, requireId } from '../security/http.js';
import * as chat from '../chat/service.js';

export async function edit({ request, env, execCtx, params, user }) {
  const b = await readJson(request, 32 * 1024);
  return json({ message: await chat.editMessage(env, execCtx, user, params.id, b) });
}

export async function remove({ env, execCtx, params, user }) {
  return json(await chat.deleteMessage(env, execCtx, user, params.id));
}

export async function priority({ request, env, execCtx, params, user }) {
  const b = await readJson(request);
  return json({ message: await chat.setPriority(env, execCtx, user, params.id, b.priority) });
}

export async function pin({ env, execCtx, params, user }) {
  return json(await chat.togglePin(env, execCtx, user, params.id));
}

export async function expiry({ request, env, execCtx, params, user }) {
  const b = await readJson(request);
  return json({ message: await chat.setExpiry(env, execCtx, user, params.id, b.ttl_seconds) });
}

// POST /api/messages/:id/reply  -> same as sending a message with reply_to_id set.
export async function reply({ request, env, execCtx, params, user }) {
  const target = await chat.requireMessage(env, params.id, user.id);
  const b = await readJson(request, 32 * 1024);
  const message = await chat.createMessage(env, execCtx, user, target.chat_id, { ...b, reply_to_id: target.id });
  return json({ message }, 201);
}
