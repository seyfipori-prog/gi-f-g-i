import { json, requireId } from '../security/http.js';
import * as n from '../notifications/service.js';

export async function list({ env, url, user }) {
  return json(await n.listNotifications(env, user.id, {
    unreadOnly: url.searchParams.get('unread') === '1', limit: url.searchParams.get('limit'),
  }));
}

export async function read({ env, params, user }) {
  await n.markNotificationRead(env, user.id, requireId(params.id, 'notification_not_found'));
  return json({ ok: true });
}

export async function readAll({ env, user }) {
  await n.markAllRead(env, user.id);
  return json({ ok: true });
}
