import { HttpError, isId } from '../security/http.js';
import { assertSameOrigin } from '../security/csrf.js';
import { authenticate } from '../auth/session.js';
import { rateLimit } from '../security/ratelimit.js';
import { requireMember } from '../chat/service.js';
import { connectSocket } from '../chat/realtime.js';

// /ws/:chatId  -> ChatRoom Durable Object (messages, status, typing, presence)
// /ws/inbox    -> UserHub Durable Object  (chat list updates, notifications)
// Authorization happens HERE, before the upgrade is forwarded.
export async function handleWs(request, env, url) {
  if (request.headers.get('upgrade') !== 'websocket') throw new HttpError(426, 'upgrade_required');
  if (!request.headers.get('origin')) throw new HttpError(403, 'bad_origin'); // browsers always send it on WS
  assertSameOrigin(request, env);
  const auth = await authenticate(env, request);
  if (!auth) throw new HttpError(401, 'unauthorized');
  await rateLimit(env, `ws:${auth.user.id}`, 120, 60);
  const target = decodeURIComponent(url.pathname.slice('/ws/'.length));
  if (target === 'inbox') return connectSocket(env, request, 'hub', auth.user.id, auth);
  if (!isId(target)) throw new HttpError(404, 'chat_not_found');
  await requireMember(env, target, auth.user.id);
  return connectSocket(env, request, 'room', target, { ...auth, chatId: target });
}
