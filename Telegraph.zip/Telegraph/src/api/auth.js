import { HttpError, json, readJson, requireId, clientIp } from '../security/http.js';
import { limitByIp, rateLimit } from '../security/ratelimit.js';
import { cleanLine, escapeLike } from '../security/text.js';
import { hashPassword, verifyPassword, verifyDummy } from '../auth/password.js';
import { createSession, sessionCookie, clearCookie, destroySession, destroyOtherSessions } from '../auth/session.js';
import { kickUser } from '../chat/realtime.js';

const COLORS = ['#34d399', '#60a5fa', '#f472b6', '#fbbf24', '#a78bfa', '#fb923c', '#2dd4bf', '#f87171'];
const isSecure = (url) => url.protocol === 'https:';

function validateUsername(v) {
  const username = String(v || '').trim().toLowerCase();
  if (!/^[a-z0-9_.]{3,32}$/.test(username)) throw new HttpError(400, 'bad_username');
  return username;
}
function validatePassword(v) {
  const password = typeof v === 'string' ? v : '';
  if (password.length < 8 || password.length > 128) throw new HttpError(400, 'weak_password');
  return password;
}

export async function register({ request, env, url }) {
  if (env.REGISTRATION_OPEN === 'false') throw new HttpError(403, 'registration_closed');
  await limitByIp(env, request, 'register', 10, 3600);
  const b = await readJson(request);
  const username = validateUsername(b.username);
  const password = validatePassword(b.password);
  const display = cleanLine(b.display_name || '', 40) || username;
  const id = crypto.randomUUID();
  const color = COLORS[username.length % COLORS.length];
  const hash = await hashPassword(password);
  try {
    await env.DB.prepare('INSERT INTO users (id, username, display_name, password_hash, color, created_at) VALUES (?,?,?,?,?,?)')
      .bind(id, username, display, hash, color, Date.now()).run();
  } catch (e) {
    if (/UNIQUE/i.test(String(e && e.message))) throw new HttpError(409, 'username_taken');
    throw e;
  }
  const s = await createSession(env, request, id);
  return json({ user: { id, username, display_name: display, color } }, 201,
    { 'set-cookie': sessionCookie(s.token, s.expiresAt, isSecure(url)) });
}

export async function login({ request, env, url }) {
  await limitByIp(env, request, 'login', 30, 600);
  const b = await readJson(request);
  const username = String(b.username || '').trim().toLowerCase().slice(0, 40);
  const password = typeof b.password === 'string' ? b.password.slice(0, 200) : '';
  await rateLimit(env, `login:user:${username}`, 8, 600);
  const row = await env.DB.prepare('SELECT id, username, display_name, color, password_hash FROM users WHERE username = ?').bind(username).first();
  const ok = row ? await verifyPassword(password, row.password_hash) : await verifyDummy(password);
  if (!ok) throw new HttpError(401, 'invalid_credentials');
  const s = await createSession(env, request, row.id);
  return json({ user: { id: row.id, username: row.username, display_name: row.display_name, color: row.color } }, 200,
    { 'set-cookie': sessionCookie(s.token, s.expiresAt, isSecure(url)) });
}

export async function logout({ env, url, session, user }) {
  await destroySession(env, session.id);
  await kickUser(env, user.id);
  return json({ ok: true }, 200, { 'set-cookie': clearCookie(isSecure(url)) });
}

export async function me({ user, session }) {
  return json({ user, session_expires_at: session.expiresAt });
}

export async function updateMe({ request, env, user }) {
  const b = await readJson(request);
  const display = cleanLine(b.display_name || '', 40);
  if (!display) throw new HttpError(400, 'empty_name');
  await env.DB.prepare('UPDATE users SET display_name = ? WHERE id = ?').bind(display, user.id).run();
  return json({ user: { ...user, display_name: display } });
}

export async function changePassword({ request, env, user, session }) {
  await rateLimit(env, `pwchange:${user.id}`, 5, 600);
  const b = await readJson(request);
  const row = await env.DB.prepare('SELECT password_hash FROM users WHERE id = ?').bind(user.id).first();
  if (!(await verifyPassword(String(b.current_password || ''), row.password_hash))) throw new HttpError(401, 'invalid_credentials');
  const next = validatePassword(b.new_password);
  await env.DB.prepare('UPDATE users SET password_hash = ? WHERE id = ?').bind(await hashPassword(next), user.id).run();
  await destroyOtherSessions(env, user.id, session.id);
  return json({ ok: true });
}

export async function searchUsers({ env, url, user }) {
  await rateLimit(env, `usersearch:${user.id}`, 60, 60);
  const q = cleanLine(url.searchParams.get('q') || '', 32).toLowerCase().replace(/^@/, '');
  if (q.length < 2) return json({ users: [] });
  const rows = (await env.DB.prepare(
    "SELECT username, display_name, color FROM users WHERE username LIKE ? ESCAPE '\\' AND id != ? ORDER BY username LIMIT 8"
  ).bind(`${escapeLike(q)}%`, user.id).all()).results;
  return json({ users: rows });
}

// Public identity keys (scaffolding for future E2EE; see SECURITY.md).
export async function putKey({ request, env, user }) {
  const b = await readJson(request, 4096);
  if (b.algorithm !== 'ECDH-P256' || typeof b.public_key !== 'object' || b.public_key === null) throw new HttpError(400, 'bad_key');
  const pub = JSON.stringify(b.public_key);
  if (pub.length > 1024 || b.public_key.kty !== 'EC' || b.public_key.crv !== 'P-256' || b.public_key.d) throw new HttpError(400, 'bad_key');
  const now = Date.now();
  const id = crypto.randomUUID();
  await env.DB.batch([
    env.DB.prepare('UPDATE user_keys SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL').bind(now, user.id),
    env.DB.prepare('INSERT INTO user_keys (id, user_id, algorithm, public_key, created_at) VALUES (?,?,?,?,?)').bind(id, user.id, b.algorithm, pub, now),
  ]);
  return json({ id }, 201);
}

export async function getKey({ env, params, user }) {
  const name = String(params.username || '').toLowerCase();
  const row = await env.DB.prepare(
    `SELECT u.id AS user_id, u.username, k.id, k.algorithm, k.public_key, k.created_at
       FROM users u JOIN user_keys k ON k.user_id = u.id AND k.revoked_at IS NULL
      WHERE u.username = ? AND EXISTS (SELECT 1 FROM chat_members a JOIN chat_members b ON a.chat_id = b.chat_id
                                        WHERE a.user_id = ? AND b.user_id = u.id)
      ORDER BY k.created_at DESC LIMIT 1`
  ).bind(name, user.id).first();
  if (!row) throw new HttpError(404, 'key_not_found');
  return json({ key: { ...row, public_key: JSON.parse(row.public_key) } });
}
