import { HttpError, json, log } from '../security/http.js';
import { assertCsrf } from '../security/csrf.js';
import { withSecurityHeaders } from '../security/headers.js';
import { authenticate } from '../auth/session.js';
import { serveUi } from '../ui/serve.js';
import { handleWs } from './ws.js';
import { uploadFile, downloadFile, discardUpload } from '../files/store.js';
import * as auth from './auth.js';
import * as chats from './chats.js';
import * as messages from './messages.js';
import * as notifications from './notifications.js';

// [method, path pattern, handler, requiresAuth]
const ROUTES = [
  ['POST', '/api/auth/register', auth.register, false],
  ['POST', '/api/auth/login', auth.login, false],
  ['POST', '/api/auth/logout', auth.logout, true],
  ['POST', '/api/auth/password', auth.changePassword, true],
  ['GET', '/api/me', auth.me, true],
  ['PATCH', '/api/me', auth.updateMe, true],
  ['GET', '/api/users/search', auth.searchUsers, true],
  ['PUT', '/api/keys', auth.putKey, true],
  ['GET', '/api/keys/:username', auth.getKey, true],

  ['GET', '/api/chats', chats.list, true],
  ['POST', '/api/chats', chats.create, true],
  ['GET', '/api/chats/:id', chats.get, true],
  ['PATCH', '/api/chats/:id', chats.rename, true],
  ['DELETE', '/api/chats/:id', chats.remove, true],
  ['POST', '/api/chats/:id/members', chats.addMember, true],
  ['DELETE', '/api/chats/:id/members/:userId', chats.removeMember, true],
  ['POST', '/api/chats/:id/read', chats.markRead, true],
  ['GET', '/api/chats/:id/messages', chats.listMessages, true],
  ['POST', '/api/chats/:id/messages', chats.createMessage, true],

  ['PATCH', '/api/messages/:id', messages.edit, true],
  ['DELETE', '/api/messages/:id', messages.remove, true],
  ['PATCH', '/api/messages/:id/priority', messages.priority, true],
  ['PATCH', '/api/messages/:id/expiry', messages.expiry, true],
  ['POST', '/api/messages/:id/reply', messages.reply, true],
  ['POST', '/api/messages/:id/pin', messages.pin, true],

  ['GET', '/api/search', chats.search, true],

  ['POST', '/api/files', uploadFile, true],
  ['GET', '/api/files/:id', downloadFile, true],
  ['DELETE', '/api/files/:id', discardUpload, true],

  ['GET', '/api/notifications', notifications.list, true],
  ['POST', '/api/notifications/read-all', notifications.readAll, true],
  ['PATCH', '/api/notifications/:id/read', notifications.read, true],
].map(([method, path, handler, needsAuth]) => ({
  method, handler, needsAuth,
  regex: new RegExp('^' + path.replace(/:[a-zA-Z]+/g, '([^/]+)') + '$'),
  names: [...path.matchAll(/:([a-zA-Z]+)/g)].map((m) => m[1]),
}));

async function handleApi(request, env, execCtx, url) {
  const path = url.pathname.replace(/\/+$/, '') || '/';
  let matched = null;
  let pathExists = false;
  for (const r of ROUTES) {
    const m = r.regex.exec(path);
    if (!m) continue;
    pathExists = true;
    if (r.method !== request.method) continue;
    const params = {};
    r.names.forEach((n, i) => { params[n] = decodeURIComponent(m[i + 1]); });
    matched = { r, params };
    break;
  }
  if (!matched) throw new HttpError(pathExists ? 405 : 404, pathExists ? 'method_not_allowed' : 'not_found');

  assertCsrf(request, env);
  const ctx = { request, env, execCtx, url, params: matched.params, user: null, session: null };
  if (matched.r.needsAuth) {
    const a = await authenticate(env, request);
    if (!a) throw new HttpError(401, 'unauthorized');
    ctx.user = a.user;
    ctx.session = a.session;
  }
  return matched.r.handler(ctx);
}

function errorResponse(e) {
  if (e instanceof HttpError) {
    const headers = e.retryAfter ? { 'retry-after': String(e.retryAfter) } : {};
    return json({ error: { code: e.code, message: e.message } }, e.status, headers);
  }
  log('error', 'unhandled', { message: String(e && e.message), stack: String(e && e.stack).slice(0, 600) });
  return json({ error: { code: 'internal', message: 'Internal error' } }, 500);
}

export async function handleRequest(request, env, execCtx) {
  const url = new URL(request.url);
  let response;
  try {
    if (url.pathname.startsWith('/api/')) response = await handleApi(request, env, execCtx, url);
    else if (url.pathname.startsWith('/ws/')) response = await handleWs(request, env, url);
    else response = await serveUi(request, env);
  } catch (e) {
    response = errorResponse(e);
  }
  return withSecurityHeaders(response, request);
}
