// Serves the static frontend from public/ (Workers Assets) and falls back to the SPA shell
// for client-side routes such as /c/<chatId>. Unknown file-like paths stay 404.
import { HttpError } from '../security/http.js';

export async function serveUi(request, env) {
  if (request.method !== 'GET' && request.method !== 'HEAD') throw new HttpError(405, 'method_not_allowed');
  const url = new URL(request.url);
  let res = await env.ASSETS.fetch(request);
  if (res.status === 404 && !/\.[a-z0-9]{1,8}$/i.test(url.pathname)) {
    res = await env.ASSETS.fetch(new Request(new URL('/', url), request));
  }
  return res;
}
