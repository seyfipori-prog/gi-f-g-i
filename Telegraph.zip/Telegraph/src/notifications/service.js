// Notification persistence. A notification is created per recipient when a message is sent
// (see chat/service.js createMessage); its `type` mirrors the message priority and follows it
// when the sender changes the priority. The UI renders type -> coloured "!" circle.
import { HttpError, clamp } from '../security/http.js';
import { safeDecrypt } from '../security/crypto.js';

export async function listNotifications(env, userId, { unreadOnly, limit }) {
  const now = Date.now();
  limit = clamp(Math.floor(Number(limit)) || 30, 1, 100);
  const rows = (await env.DB.prepare(
    `SELECT n.id, n.chat_id, n.message_id, n.type, n.title, n.preview, n.created_at, n.read_at, c.title AS chat_title
       FROM notifications n
       JOIN chats c ON c.id = n.chat_id
       JOIN messages m ON m.id = n.message_id
      WHERE n.user_id = ? ${unreadOnly ? 'AND n.read_at IS NULL' : ''} AND m.deleted_at IS NULL
        AND (m.expires_at IS NULL OR m.expires_at > ?)
      ORDER BY n.created_at DESC LIMIT ?`
  ).bind(userId, now, limit).all()).results;
  const unread = await env.DB.prepare(
    `SELECT COUNT(*) AS n FROM notifications n JOIN messages m ON m.id = n.message_id
      WHERE n.user_id = ? AND n.read_at IS NULL AND m.deleted_at IS NULL AND (m.expires_at IS NULL OR m.expires_at > ?)`
  ).bind(userId, now).first();
  const notifications = await Promise.all(rows.map(async (r) => ({
    id: r.id, chat_id: r.chat_id, chat_title: r.chat_title, message_id: r.message_id, priority: r.type,
    title: r.title, preview: (await safeDecrypt(env, `chat:${r.chat_id}`, r.preview, `np:${r.message_id}`)) || '',
    created_at: r.created_at, read: !!r.read_at,
  })));
  return { notifications, unread_count: unread.n };
}

export async function markNotificationRead(env, userId, id) {
  const res = await env.DB.prepare('UPDATE notifications SET read_at = COALESCE(read_at, ?) WHERE id = ? AND user_id = ?')
    .bind(Date.now(), id, userId).run();
  if (!res.meta.changes) throw new HttpError(404, 'notification_not_found');
}

export async function markAllRead(env, userId) {
  await env.DB.prepare('UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL').bind(Date.now(), userId).run();
}
