// Password hashing with PBKDF2-SHA256 (Web Crypto). Workers cap PBKDF2 at 100,000 iterations.
// Stored format: pbkdf2-sha256$<iterations>$<salt b64url>$<hash b64url>
import { b64uEncode, b64uDecode, timingSafeEqual } from '../security/crypto.js';

const ITERATIONS = 100000;
const te = new TextEncoder();

async function derive(password, salt, iterations) {
  const key = await crypto.subtle.importKey('raw', te.encode(password), 'PBKDF2', false, ['deriveBits']);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, 256));
}

export async function hashPassword(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const hash = await derive(password, salt, ITERATIONS);
  return `pbkdf2-sha256$${ITERATIONS}$${b64uEncode(salt)}$${b64uEncode(hash)}`;
}

export async function verifyPassword(password, stored) {
  const [alg, iter, salt, hash] = String(stored).split('$');
  if (alg !== 'pbkdf2-sha256') return false;
  const iterations = Math.min(Number(iter) || ITERATIONS, 100000);
  const actual = await derive(password, b64uDecode(salt), iterations);
  return timingSafeEqual(actual, b64uDecode(hash));
}

let dummy;
// Burn equivalent CPU when the username does not exist (prevents user enumeration by timing).
export async function verifyDummy(password) {
  dummy ||= await hashPassword('telegraph-dummy-password');
  await verifyPassword(password, dummy);
  return false;
}
