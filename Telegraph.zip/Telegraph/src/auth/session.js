import { randomToken, sha256Hex } from '../security/crypto.js';
import { clientIp } from '../security/http.js';

export const COOKIE = 'tg_session';
const HOUR = 3600e3;
const DAY = 24 * HOUR;
const ABSOLUTE_MAX = 30 * DAY;

const ttlMs = (env) => Math.max(1, Number(env.SESSION_TTL_DAYS) || 14) * DAY;

export function readCookie(request, name) {
  const header = request.headers.get('cookie');
  if (!header) return null;
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0 && part.slice(0, i).trim() === name) return decodeURIComponent(part.slice(i + 1).trim());
  }
  return null;
}

export function sessionCookie(token, expiresAt, secure) {
  return `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Expires=${new Date(expiresAt).toUTCString()}${secure ? '; Secure' : ''}`;
}
export function clearCookie(secure) {
  return `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure ? '; Secure' : ''}`;
}

export async function createSession(env, request, userId) {
  const token = randomToken(32);
  const id = await sha256Hex(token);
  const now = Date.now();
  const expiresAt = now + ttlMs(env);
  await env.DB.prepare(
    'INSERT INTO sessions (id, user_id, created_at, expires_at, last_used_at, ip_hash, user_agent) VALUES (?,?,?,?,?,?,?)'
  ).bind(id, userId, now, expiresAt, now, (await sha256Hex(clientIp(request))).slice(0, 16),
    (request.headers.get('user-agent') || '').slice(0, 200)).run();
  return { token, expiresAt };
}

// Returns { user, session } or null. Sliding expiration, capped by an absolute lifetime.
export async function authenticate(env, request) {
  const token = readCookie(request, COOKIE);
  if (!token || token.length > 100) return null;
  const id = await sha256Hex(token);
  const now = Date.now();
  const row = await env.DB.prepare(
    `SELECT s.id AS sid, s.created_at, s.expires_at, s.last_used_at,
            u.id, u.username, u.display_name, u.color
       FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id = ?`
  ).bind(id).first();
  if (!row) return null;
  if (row.expires_at <= now) {
    await env.DB.prepare('DELETE FROM sessions WHERE id = ?').bind(id).run();
    return null;
  }
  let expiresAt = row.expires_at;
  if (now - row.last_used_at > HOUR) {
    expiresAt = Math.min(row.created_at + ABSOLUTE_MAX, now + ttlMs(env));
    await env.DB.prepare('UPDATE sessions SET last_used_at = ?, expires_at = ? WHERE id = ?').bind(now, expiresAt, id).run();
  }
  return {
    user: { id: row.id, username: row.username, display_name: row.display_name, color: row.color },
    session: { id: row.sid, token, expiresAt },
  };
}

export const destroySession = (env, id) => env.DB.prepare('DELETE FROM sessions WHERE id = ?').bind(id).run();
export const destroyOtherSessions = (env, userId, keepId) =>
  env.DB.prepare('DELETE FROM sessions WHERE user_id = ? AND id != ?').bind(userId, keepId).run();
