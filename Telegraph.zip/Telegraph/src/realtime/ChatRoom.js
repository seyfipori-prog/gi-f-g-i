// One Durable Object per chat. Uses the WebSocket Hibernation API, so idle rooms cost nothing.
// The Worker authenticates the user and verifies chat membership BEFORE forwarding the upgrade;
// the identity headers below can only be set by the Worker (the DO is not publicly reachable).
import { purgeExpired } from '../chat/cleanup.js';
import { log } from '../security/http.js';

export class ChatRoom {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    this.state.setWebSocketAutoResponse(new WebSocketRequestResponsePair('ping', 'pong'));
  }

  sockets() {
    return this.state.getWebSockets().filter((s) => s.readyState === 1);
  }

  onlineIds(except) {
    const ids = new Set();
    for (const s of this.sockets()) {
      if (s === except) continue;
      const a = s.deserializeAttachment();
      if (a) ids.add(a.userId);
    }
    return [...ids];
  }

  send(ws, payload) {
    try { ws.send(JSON.stringify(payload)); } catch { /* socket gone */ }
  }

  broadcast(payload, exceptUserId) {
    const text = JSON.stringify(payload);
    for (const s of this.sockets()) {
      const a = s.deserializeAttachment();
      if (exceptUserId && a && a.userId === exceptUserId) continue;
      try { s.send(text); } catch { /* ignore */ }
    }
  }

  async fetch(request) {
    const url = new URL(request.url);

    if (url.pathname === '/connect') {
      if (request.headers.get('upgrade') !== 'websocket') return new Response('Expected websocket', { status: 426 });
      const userId = request.headers.get('x-tg-user');
      if (!userId) return new Response('Unauthorized', { status: 401 });
      const pair = new WebSocketPair();
      const [client, server] = Object.values(pair);
      const wasOnline = this.onlineIds().includes(userId);
      this.state.acceptWebSocket(server);
      server.serializeAttachment({
        userId,
        name: decodeURIComponent(request.headers.get('x-tg-name') || ''),
        exp: Number(request.headers.get('x-tg-exp')) || 0,
      });
      this.send(server, { type: 'hello', online: this.onlineIds() });
      if (!wasOnline) this.broadcast({ type: 'presence', user_id: userId, online: true }, userId);
      return new Response(null, { status: 101, webSocket: client });
    }

    if (request.method !== 'POST') return new Response('Not found', { status: 404 });
    const body = await request.json().catch(() => ({}));

    if (url.pathname === '/broadcast') {
      this.broadcast(body.payload, body.except_user || null);
      return Response.json({ online: this.onlineIds() });
    }
    if (url.pathname === '/schedule') {
      // Wake up at the earliest message expiry so clients learn about it in real time.
      const at = Number(body.at);
      if (body.chat_id) await this.state.storage.put('chat_id', body.chat_id);
      const current = await this.state.storage.getAlarm();
      if (at && (!current || at < current)) await this.state.storage.setAlarm(Math.max(at, Date.now() + 250));
      return Response.json({ ok: true });
    }
    if (url.pathname === '/kick') {
      for (const s of this.sockets()) {
        const a = s.deserializeAttachment();
        if (!body.user_id || (a && a.userId === body.user_id)) { try { s.close(4403, 'removed'); } catch { /* ignore */ } }
      }
      return Response.json({ ok: true });
    }
    return new Response('Not found', { status: 404 });
  }

  async webSocketMessage(ws, message) {
    if (typeof message !== 'string' || message.length > 2048) return;
    const att = ws.deserializeAttachment();
    if (!att) return;
    if (att.exp && Date.now() > att.exp) { try { ws.close(4401, 'session expired'); } catch { /* ignore */ } return; }
    let msg;
    try { msg = JSON.parse(message); } catch { return; }
    if (msg.type === 'typing') {
      this.broadcast({ type: 'typing', user_id: att.userId, name: att.name, on: !!msg.on }, att.userId);
    }
  }

  webSocketClose(ws) {
    const att = ws.deserializeAttachment();
    if (att && !this.onlineIds(ws).includes(att.userId)) {
      this.broadcast({ type: 'presence', user_id: att.userId, online: false }, att.userId);
    }
  }

  webSocketError(ws) {
    this.webSocketClose(ws);
  }

  async alarm() {
    try {
      const chatId = await this.state.storage.get('chat_id');
      if (!chatId) return;
      const purged = await purgeExpired(this.env, { chatId, limit: 200 });
      if (purged.length) this.broadcast({ type: 'messages.expired', ids: purged.map((r) => r.id) });
      const next = await this.env.DB.prepare(
        'SELECT MIN(expires_at) AS at FROM messages WHERE chat_id = ? AND expires_at IS NOT NULL'
      ).bind(chatId).first();
      if (next && next.at) await this.state.storage.setAlarm(Math.max(next.at, Date.now() + 1000));
    } catch (e) {
      log('error', 'room_alarm_failed', { message: String(e) });
    }
  }
}
