// One Durable Object per user: a personal "inbox" socket used for chat-list updates,
// notifications (the coloured "!" toast) and online/offline detection across all chats.
export class UserHub {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    this.state.setWebSocketAutoResponse(new WebSocketRequestResponsePair('ping', 'pong'));
  }

  sockets() {
    return this.state.getWebSockets().filter((s) => s.readyState === 1);
  }

  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === '/connect') {
      if (request.headers.get('upgrade') !== 'websocket') return new Response('Expected websocket', { status: 426 });
      const userId = request.headers.get('x-tg-user');
      if (!userId) return new Response('Unauthorized', { status: 401 });
      const pair = new WebSocketPair();
      const [client, server] = Object.values(pair);
      this.state.acceptWebSocket(server);
      server.serializeAttachment({ userId, exp: Number(request.headers.get('x-tg-exp')) || 0 });
      server.send(JSON.stringify({ type: 'hello' }));
      return new Response(null, { status: 101, webSocket: client });
    }
    if (request.method !== 'POST') return new Response('Not found', { status: 404 });
    const body = await request.json().catch(() => ({}));
    if (url.pathname === '/push') {
      const text = JSON.stringify(body.payload);
      const socks = this.sockets();
      for (const s of socks) { try { s.send(text); } catch { /* ignore */ } }
      return Response.json({ online: socks.length > 0 });
    }
    if (url.pathname === '/kick') {
      for (const s of this.sockets()) { try { s.close(4401, 'signed out'); } catch { /* ignore */ } }
      return Response.json({ ok: true });
    }
    return new Response('Not found', { status: 404 });
  }

  async webSocketMessage(ws, message) {
    const att = ws.deserializeAttachment();
    if (att && att.exp && Date.now() > att.exp) { try { ws.close(4401, 'session expired'); } catch { /* ignore */ } }
  }

  async webSocketClose(ws) {
    const att = ws.deserializeAttachment();
    if (att && !this.sockets().some((s) => s !== ws)) {
      await this.env.DB.prepare('UPDATE users SET last_seen_at = ? WHERE id = ?').bind(Date.now(), att.userId).run().catch(() => {});
    }
  }

  async webSocketError(ws) {
    await this.webSocketClose(ws);
  }
}
