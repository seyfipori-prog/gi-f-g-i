// Chat domain logic. D1 is the source of truth; realtime fan-out happens after commit.
import { HttpError, clamp, isId, log } from '../security/http.js';
import { encryptText, safeDecrypt, blindTokens } from '../security/crypto.js';
import { cleanBody, cleanLine, tokenize } from '../security/text.js';
import { rateLimit } from '../security/ratelimit.js';
import { broadcastToChat, pushToUser, pushToUsers, scheduleExpiry, kickFromChat } from './realtime.js';
import { deleteObjects } from '../files/objects.js';

export const PRIORITIES = ['normal', 'good', 'important', 'critical'];
export const scopeOf = (chatId) => `chat:${chatId}`;

export function normalizePriority(p) {
  if (p == null || p === '') return 'normal';
  if (!PRIORITIES.includes(p)) throw new HttpError(400, 'bad_priority');
  return p;
}

function normalizeTtl(v) {
  if (v == null || v === '') return null;
  const n = Number(v);
  if (!Number.isFinite(n) || n < 5 || n > 30 * 86400) throw new HttpError(400, 'bad_ttl');
  return Math.floor(n);
}

// ---------------------------------------------------------------- authorization

// Non-members get 404 (not 403) so chat ids cannot be probed.
export async function requireMember(env, chatId, userId) {
  const row = await env.DB.prepare(
    `SELECT c.id, c.title, c.type, c.created_by, cm.role, cm.muted
       FROM chats c JOIN chat_members cm ON cm.chat_id = c.id WHERE c.id = ? AND cm.user_id = ?`
  ).bind(chatId, userId).first();
  if (!row) throw new HttpError(404, 'chat_not_found');
  return row;
}

export async function requireMessage(env, messageId, userId) {
  if (!isId(messageId)) throw new HttpError(404, 'message_not_found');
  const row = await env.DB.prepare(
    `SELECT m.id, m.chat_id, m.sender_id, m.kind, m.priority, m.deleted_at, m.expires_at
       FROM messages m JOIN chat_members cm ON cm.chat_id = m.chat_id AND cm.user_id = ?
      WHERE m.id = ? AND (m.expires_at IS NULL OR m.expires_at > ?)`
  ).bind(userId, messageId, Date.now()).first();
  if (!row) throw new HttpError(404, 'message_not_found');
  return row;
}

async function requireOwnLiveMessage(env, messageId, userId) {
  const m = await requireMessage(env, messageId, userId);
  if (m.sender_id !== userId) throw new HttpError(403, 'not_your_message');
  if (m.deleted_at) throw new HttpError(404, 'message_not_found');
  return m;
}

// ---------------------------------------------------------------- message reads

const MSG_SELECT = `
SELECT m.seq, m.id, m.chat_id, m.sender_id, m.kind, m.body, m.priority, m.reply_to_id, m.e2ee_version,
       m.created_at, m.edited_at, m.deleted_at, m.expires_at,
       u.username AS s_username, u.display_name AS s_name, u.color AS s_color,
       c.title AS chat_title,
       r.id AS r_id, r.body AS r_body, r.deleted_at AS r_deleted, ru.display_name AS r_name,
       EXISTS(SELECT 1 FROM pinned_messages p WHERE p.message_id = m.id) AS pinned
  FROM messages m
  JOIN users u ON u.id = m.sender_id
  JOIN chats c ON c.id = m.chat_id
  LEFT JOIN messages r ON r.id = m.reply_to_id AND (r.expires_at IS NULL OR r.expires_at > ?)
  LEFT JOIN users ru ON ru.id = r.sender_id`;

export async function statusMap(env, ids) {
  const map = new Map(ids.map((id) => [id, 'sent']));
  if (!ids.length) return map;
  const rows = (await env.DB.prepare(
    `SELECT message_id, COUNT(*) AS n,
            SUM(CASE WHEN delivered_at IS NOT NULL THEN 1 ELSE 0 END) AS d,
            SUM(CASE WHEN read_at IS NOT NULL THEN 1 ELSE 0 END) AS r
       FROM message_status WHERE message_id IN (SELECT value FROM json_each(?)) GROUP BY message_id`
  ).bind(JSON.stringify(ids)).all()).results;
  for (const r of rows) map.set(r.message_id, r.r === r.n ? 'read' : r.d === r.n ? 'delivered' : 'sent');
  return map;
}

export async function hydrate(env, rows, viewerId) {
  if (!rows.length) return [];
  const ids = rows.map((r) => r.id);
  const own = rows.filter((r) => r.sender_id === viewerId && !r.deleted_at).map((r) => r.id);
  const [attRes, statuses] = await Promise.all([
    env.DB.prepare(
      `SELECT id, message_id, filename, mime, size, category, is_voice, duration_ms FROM attachments
        WHERE message_id IN (SELECT value FROM json_each(?)) AND deleted_at IS NULL ORDER BY created_at, id`
    ).bind(JSON.stringify(ids)).all(),
    statusMap(env, own),
  ]);
  const chatOf = new Map(rows.map((r) => [r.id, r.chat_id]));
  const byMsg = new Map();
  for (const a of attRes.results) {
    const name = (await safeDecrypt(env, scopeOf(chatOf.get(a.message_id)), a.filename, `a:${a.id}`)) || 'file';
    const list = byMsg.get(a.message_id) || [];
    list.push({ id: a.id, filename: name, mime: a.mime, size: a.size, category: a.category,
      is_voice: !!a.is_voice, duration_ms: a.duration_ms, url: `/api/files/${a.id}` });
    byMsg.set(a.message_id, list);
  }
  return Promise.all(rows.map(async (r) => {
    const deleted = !!r.deleted_at;
    const body = deleted ? null : await safeDecrypt(env, scopeOf(r.chat_id), r.body, `m:${r.id}`);
    let reply = null;
    if (r.reply_to_id) {
      if (r.r_id && !r.r_deleted) {
        const rb = await safeDecrypt(env, scopeOf(r.chat_id), r.r_body, `m:${r.r_id}`);
        reply = { id: r.r_id, sender_name: r.r_name, preview: rb ? rb.slice(0, 140) : '', deleted: false };
      } else {
        reply = { id: r.reply_to_id, sender_name: null, preview: null, deleted: true };
      }
    }
    return {
      id: r.id, seq: r.seq, chat_id: r.chat_id, chat_title: r.chat_title,
      sender: { id: r.sender_id, username: r.s_username, display_name: r.s_name, color: r.s_color },
      kind: r.kind, body, priority: r.priority, reply_to: reply,
      created_at: r.created_at, edited_at: r.edited_at, deleted, expires_at: r.expires_at,
      pinned: !!r.pinned, attachments: deleted ? [] : byMsg.get(r.id) || [],
      status: r.sender_id === viewerId && !deleted ? statuses.get(r.id) || 'sent' : undefined,
      e2ee: r.e2ee_version || null,
    };
  }));
}

export async function fetchPage(env, viewerId, chatId, { before, limit } = {}) {
  limit = clamp(Math.floor(Number(limit)) || 30, 1, 50);
  const now = Date.now();
  const binds = [now, chatId, now];
  let sql = `${MSG_SELECT} WHERE m.chat_id = ? AND (m.expires_at IS NULL OR m.expires_at > ?)`;
  const b = Number(before);
  if (Number.isFinite(b) && b > 0) { sql += ' AND m.seq < ?'; binds.push(b); }
  sql += ' ORDER BY m.seq DESC LIMIT ?';
  binds.push(limit + 1);
  const res = await env.DB.prepare(sql).bind(...binds).all();
  const hasMore = res.results.length > limit;
  const rows = res.results.slice(0, limit).reverse();
  return { messages: await hydrate(env, rows, viewerId), has_more: hasMore, next_before: rows.length ? rows[0].seq : null };
}

export async function fetchByIds(env, viewerId, ids) {
  if (!ids.length) return [];
  const now = Date.now();
  const res = await env.DB.prepare(
    `${MSG_SELECT} WHERE m.id IN (SELECT value FROM json_each(?)) AND (m.expires_at IS NULL OR m.expires_at > ?) ORDER BY m.seq`
  ).bind(now, JSON.stringify(ids), now).all();
  return hydrate(env, res.results, viewerId);
}

// ---------------------------------------------------------------- realtime helpers

async function memberIds(env, chatId) {
  return (await env.DB.prepare('SELECT user_id FROM chat_members WHERE chat_id = ?').bind(chatId).all()).results.map((r) => r.user_id);
}

async function emitStatuses(env, chatId, ids) {
  if (!ids.length) return;
  const map = await statusMap(env, ids.slice(0, 500));
  await broadcastToChat(env, chatId, { type: 'status', items: [...map].map(([id, status]) => ({ id, status })) });
}

export async function markDelivered(env, chatId, messageId, userIds) {
  if (!userIds.length) return;
  const res = await env.DB.prepare(
    `UPDATE message_status SET delivered_at = ?, status = CASE WHEN status = 'sent' THEN 'delivered' ELSE status END
      WHERE message_id = ? AND user_id IN (SELECT value FROM json_each(?)) AND delivered_at IS NULL`
  ).bind(Date.now(), messageId, JSON.stringify(userIds)).run();
  if (res.meta && res.meta.changes) await emitStatuses(env, chatId, [messageId]);
}

// Messages fetched by a recipient count as delivered.
export async function markDeliveredForViewer(env, chatId, userId) {
  const res = (await env.DB.prepare(
    `UPDATE message_status SET delivered_at = ?, status = CASE WHEN status = 'sent' THEN 'delivered' ELSE status END
      WHERE user_id = ? AND chat_id = ? AND delivered_at IS NULL RETURNING message_id`
  ).bind(Date.now(), userId, chatId).all()).results;
  if (res.length) await emitStatuses(env, chatId, res.map((r) => r.message_id));
}

export async function markRead(env, chatId, userId) {
  const now = Date.now();
  const rows = (await env.DB.prepare(
    `UPDATE message_status SET read_at = ?, delivered_at = COALESCE(delivered_at, ?), status = 'read'
      WHERE user_id = ? AND chat_id = ? AND read_at IS NULL RETURNING message_id`
  ).bind(now, now, userId, chatId).all()).results;
  await env.DB.prepare('UPDATE notifications SET read_at = ? WHERE user_id = ? AND chat_id = ? AND read_at IS NULL')
    .bind(now, userId, chatId).run();
  await emitStatuses(env, chatId, rows.map((r) => r.message_id));
  await pushToUser(env, userId, { type: 'chat.updated', chat_id: chatId });
  return rows.length;
}

// Broadcast a change to everyone watching the chat and refresh every member's chat list.
async function publishChange(env, chatId, payload, extraHub = null) {
  await broadcastToChat(env, chatId, payload);
  const ids = await memberIds(env, chatId);
  await pushToUsers(env, ids, { type: 'chat.updated', chat_id: chatId });
  if (extraHub) await pushToUsers(env, ids, extraHub);
}

async function fanoutNew(env, { chat, dto, senderId }) {
  const room = await broadcastToChat(env, chat.id, { type: 'message.new', message: dto });
  const members = (await env.DB.prepare('SELECT user_id FROM chat_members WHERE chat_id = ?').bind(chat.id).all()).results.map((r) => r.user_id);
  const notifs = new Map((await env.DB.prepare('SELECT id, user_id FROM notifications WHERE message_id = ?').bind(dto.id).all())
    .results.map((n) => [n.user_id, n.id]));
  const delivered = new Set(room);
  await Promise.all(members.map(async (uid) => {
    const payload = { type: 'chat.updated', chat_id: chat.id };
    if (uid !== senderId && notifs.has(uid)) {
      payload.notification = {
        id: notifs.get(uid), chat_id: chat.id, chat_title: chat.title, message_id: dto.id, priority: dto.priority,
        title: dto.sender.display_name, preview: (dto.body || '').slice(0, 120), kind: dto.kind, created_at: dto.created_at,
      };
    }
    const online = await pushToUser(env, uid, payload);
    if (online) delivered.add(uid);
  }));
  delivered.delete(senderId);
  await markDelivered(env, chat.id, dto.id, [...delivered]);
  if (dto.expires_at) await scheduleExpiry(env, chat.id, dto.expires_at);
}

const background = (execCtx, promise) => {
  const p = promise.catch((e) => log('error', 'background_failed', { message: String(e) }));
  if (execCtx && execCtx.waitUntil) execCtx.waitUntil(p);
  return p;
};

// ---------------------------------------------------------------- message mutations

async function attachmentTokenWords(env, chatId, rows) {
  const words = [];
  for (const a of rows) {
    const name = await safeDecrypt(env, scopeOf(chatId), a.filename, `a:${a.id}`);
    if (name) words.push(...tokenize(name, 10));
  }
  return words;
}

function tokenStatements(env, messageId, chatId, tokens) {
  if (!tokens.length) return [];
  return [env.DB.prepare('INSERT OR IGNORE INTO message_tokens (message_id, chat_id, token) SELECT ?, ?, value FROM json_each(?)')
    .bind(messageId, chatId, JSON.stringify(tokens))];
}

export async function createMessage(env, execCtx, user, chatId, input) {
  const chat = await requireMember(env, chatId, user.id);
  await rateLimit(env, `msg:${user.id}`, 90, 60);

  const priority = normalizePriority(input.priority);
  const text = cleanBody(input.body ?? '');
  const ttl = normalizeTtl(input.ttl_seconds);
  const attachmentIds = Array.isArray(input.attachment_ids) ? [...new Set(input.attachment_ids.filter(isId))].slice(0, 10) : [];
  if (!text && !attachmentIds.length) throw new HttpError(400, 'empty_message');

  const now = Date.now();
  if (input.reply_to_id != null) {
    const target = isId(input.reply_to_id) && await env.DB.prepare(
      'SELECT id FROM messages WHERE id = ? AND chat_id = ? AND deleted_at IS NULL AND (expires_at IS NULL OR expires_at > ?)'
    ).bind(input.reply_to_id, chatId, now).first();
    if (!target) throw new HttpError(400, 'bad_reply_target');
  }

  let atts = [];
  if (attachmentIds.length) {
    atts = (await env.DB.prepare(
      `SELECT id, filename, is_voice FROM attachments
        WHERE id IN (SELECT value FROM json_each(?)) AND chat_id = ? AND uploader_id = ? AND message_id IS NULL AND deleted_at IS NULL`
    ).bind(JSON.stringify(attachmentIds), chatId, user.id).all()).results;
    if (atts.length !== attachmentIds.length) throw new HttpError(400, 'bad_attachment');
  }

  const id = crypto.randomUUID();
  const kind = atts.length ? (atts.length === 1 && atts[0].is_voice ? 'voice' : 'file') : 'text';
  const expiresAt = ttl ? now + ttl * 1000 : null;
  const bodyEnc = text ? await encryptText(env, scopeOf(chatId), text, `m:${id}`) : null;
  const previewEnc = text ? await encryptText(env, scopeOf(chatId), text.slice(0, 120), `np:${id}`) : null;
  const words = [...new Set([...tokenize(text, 30), ...(await attachmentTokenWords(env, chatId, atts))])];
  const tokens = await blindTokens(env, words);

  const uuidSql = "lower(hex(randomblob(4))||'-'||hex(randomblob(2))||'-4'||substr(hex(randomblob(2)),2)||'-a'||substr(hex(randomblob(2)),2)||'-'||hex(randomblob(6)))";
  const stmts = [
    env.DB.prepare(
      `INSERT INTO messages (id, chat_id, sender_id, kind, body, priority, reply_to_id, created_at, expires_at)
       VALUES (?,?,?,?,?,?,?,?,?)`
    ).bind(id, chatId, user.id, kind, bodyEnc, priority, input.reply_to_id || null, now, expiresAt),
    env.DB.prepare(
      `INSERT INTO message_status (message_id, chat_id, user_id, status)
       SELECT ?, ?, user_id, 'sent' FROM chat_members WHERE chat_id = ? AND user_id != ?`
    ).bind(id, chatId, chatId, user.id),
    env.DB.prepare(
      `INSERT INTO notifications (id, user_id, chat_id, message_id, type, title, preview, created_at)
       SELECT ${uuidSql}, user_id, ?, ?, ?, ?, ?, ? FROM chat_members WHERE chat_id = ? AND user_id != ? AND muted = 0`
    ).bind(chatId, id, priority, user.display_name, previewEnc, now, chatId, user.id),
    env.DB.prepare('UPDATE chats SET updated_at = ?, last_message_at = ? WHERE id = ?').bind(now, now, chatId),
  ];
  if (atts.length) {
    stmts.push(env.DB.prepare(
      `UPDATE attachments SET message_id = ? WHERE id IN (SELECT value FROM json_each(?))
         AND chat_id = ? AND uploader_id = ? AND message_id IS NULL`
    ).bind(id, JSON.stringify(attachmentIds), chatId, user.id));
  }
  stmts.push(...tokenStatements(env, id, chatId, tokens));
  await env.DB.batch(stmts);

  const [dto] = await fetchByIds(env, user.id, [id]);
  background(execCtx, fanoutNew(env, { chat, dto, senderId: user.id }));
  return dto;
}

export async function editMessage(env, execCtx, user, messageId, input) {
  const m = await requireOwnLiveMessage(env, messageId, user.id);
  if (m.kind !== 'text' && m.kind !== 'file') throw new HttpError(400, 'not_editable');
  const text = cleanBody(input.body ?? '');
  if (!text && m.kind === 'text') throw new HttpError(400, 'empty_message');
  const bodyEnc = text ? await encryptText(env, scopeOf(m.chat_id), text, `m:${m.id}`) : null;
  const atts = (await env.DB.prepare('SELECT id, filename FROM attachments WHERE message_id = ?').bind(m.id).all()).results;
  const tokens = await blindTokens(env, [...new Set([...tokenize(text, 30), ...(await attachmentTokenWords(env, m.chat_id, atts))])]);
  await env.DB.batch([
    env.DB.prepare('UPDATE messages SET body = ?, edited_at = ? WHERE id = ?').bind(bodyEnc, Date.now(), m.id),
    env.DB.prepare('DELETE FROM message_tokens WHERE message_id = ?').bind(m.id),
    ...tokenStatements(env, m.id, m.chat_id, tokens),
  ]);
  const [dto] = await fetchByIds(env, user.id, [m.id]);
  background(execCtx, publishChange(env, m.chat_id, { type: 'message.updated', message: dto }));
  return dto;
}

export async function deleteMessage(env, execCtx, user, messageId) {
  const m = await requireOwnLiveMessage(env, messageId, user.id);
  const keys = (await env.DB.prepare('SELECT r2_key FROM attachments WHERE message_id = ?').bind(m.id).all()).results.map((r) => r.r2_key);
  await deleteObjects(env, keys);
  await env.DB.batch([
    env.DB.prepare('UPDATE messages SET body = NULL, deleted_at = ? WHERE id = ?').bind(Date.now(), m.id),
    env.DB.prepare('DELETE FROM attachments WHERE message_id = ?').bind(m.id),
    env.DB.prepare('DELETE FROM message_tokens WHERE message_id = ?').bind(m.id),
    env.DB.prepare('DELETE FROM pinned_messages WHERE message_id = ?').bind(m.id),
    env.DB.prepare('DELETE FROM notifications WHERE message_id = ?').bind(m.id),
    env.DB.prepare('DELETE FROM message_status WHERE message_id = ?').bind(m.id),
  ]);
  background(execCtx, publishChange(env, m.chat_id, { type: 'message.deleted', id: m.id, chat_id: m.chat_id }));
  return { ok: true };
}

export async function setPriority(env, execCtx, user, messageId, priority) {
  const m = await requireOwnLiveMessage(env, messageId, user.id);
  const p = normalizePriority(priority);
  await env.DB.batch([
    env.DB.prepare('UPDATE messages SET priority = ? WHERE id = ?').bind(p, m.id),
    env.DB.prepare('UPDATE notifications SET type = ? WHERE message_id = ?').bind(p, m.id),
  ]);
  const [dto] = await fetchByIds(env, user.id, [m.id]);
  background(execCtx, publishChange(env, m.chat_id, { type: 'message.updated', message: dto },
    { type: 'notification.updated', message_id: m.id, chat_id: m.chat_id, priority: p }));
  return dto;
}

export async function togglePin(env, execCtx, user, messageId) {
  const m = await requireMessage(env, messageId, user.id);
  if (m.deleted_at) throw new HttpError(404, 'message_not_found');
  const existing = await env.DB.prepare('SELECT 1 AS x FROM pinned_messages WHERE message_id = ?').bind(m.id).first();
  if (existing) {
    await env.DB.prepare('DELETE FROM pinned_messages WHERE message_id = ?').bind(m.id).run();
  } else {
    const count = await env.DB.prepare('SELECT COUNT(*) AS n FROM pinned_messages WHERE chat_id = ?').bind(m.chat_id).first();
    if (count.n >= 50) throw new HttpError(400, 'too_many_pins');
    await env.DB.prepare('INSERT INTO pinned_messages (chat_id, message_id, pinned_by, pinned_at) VALUES (?,?,?,?)')
      .bind(m.chat_id, m.id, user.id, Date.now()).run();
  }
  const [dto] = await fetchByIds(env, user.id, [m.id]);
  background(execCtx, publishChange(env, m.chat_id, { type: 'message.updated', message: dto }));
  return { pinned: !existing, message: dto };
}

export async function setExpiry(env, execCtx, user, messageId, ttlSeconds) {
  const m = await requireOwnLiveMessage(env, messageId, user.id);
  const ttl = normalizeTtl(ttlSeconds);
  const expiresAt = ttl ? Date.now() + ttl * 1000 : null;
  await env.DB.prepare('UPDATE messages SET expires_at = ? WHERE id = ?').bind(expiresAt, m.id).run();
  const [dto] = await fetchByIds(env, user.id, [m.id]);
  background(execCtx, (async () => {
    await publishChange(env, m.chat_id, { type: 'message.updated', message: dto });
    if (expiresAt) await scheduleExpiry(env, m.chat_id, expiresAt);
  })());
  return dto;
}

// ---------------------------------------------------------------- chats

export async function listChats(env, userId, q) {
  const now = Date.now();
  const like = q ? `%${q.replace(/[\\%_]/g, (c) => '\\' + c)}%` : null;
  const res = await env.DB.prepare(
    `SELECT c.id, c.title, c.type, c.created_by, c.created_at, c.updated_at, c.last_message_at, cm.role, cm.muted,
            (SELECT COUNT(*) FROM chat_members x WHERE x.chat_id = c.id) AS member_count,
            (SELECT COUNT(*) FROM message_status ms JOIN messages mm ON mm.id = ms.message_id
              WHERE ms.user_id = ? AND ms.chat_id = c.id AND ms.read_at IS NULL AND mm.deleted_at IS NULL
                AND (mm.expires_at IS NULL OR mm.expires_at > ?)) AS unread,
            lm.id AS lm_id, lm.body AS lm_body, lm.kind AS lm_kind, lm.priority AS lm_priority,
            lm.created_at AS lm_at, lm.sender_id AS lm_sender
       FROM chat_members cm
       JOIN chats c ON c.id = cm.chat_id
       LEFT JOIN messages lm ON lm.id = (
         SELECT m.id FROM messages m WHERE m.chat_id = c.id AND m.deleted_at IS NULL
            AND (m.expires_at IS NULL OR m.expires_at > ?) ORDER BY m.seq DESC LIMIT 1)
      WHERE cm.user_id = ? ${like ? "AND c.title LIKE ? ESCAPE '\\'" : ''}
      ORDER BY COALESCE(c.last_message_at, c.created_at) DESC LIMIT 80`
  ).bind(...[userId, now, now, userId].concat(like ? [like] : [])).all();
  return Promise.all(res.results.map(async (r) => {
    let last = null;
    if (r.lm_id) {
      const body = await safeDecrypt(env, scopeOf(r.id), r.lm_body, `m:${r.lm_id}`);
      last = { id: r.lm_id, kind: r.lm_kind, priority: r.lm_priority, created_at: r.lm_at,
        mine: r.lm_sender === userId, preview: body ? body.slice(0, 100) : '' };
    }
    return { id: r.id, title: r.title, role: r.role, muted: !!r.muted, member_count: r.member_count,
      unread: r.unread, created_at: r.created_at, last_activity: r.last_message_at || r.created_at, last_message: last };
  }));
}

export async function getChat(env, userId, chatId) {
  const chat = await requireMember(env, chatId, userId);
  const members = (await env.DB.prepare(
    `SELECT u.id, u.username, u.display_name, u.color, cm.role FROM chat_members cm JOIN users u ON u.id = cm.user_id
      WHERE cm.chat_id = ? ORDER BY cm.joined_at, u.id`
  ).bind(chatId).all()).results;
  const pinIds = (await env.DB.prepare(
    'SELECT message_id FROM pinned_messages WHERE chat_id = ? ORDER BY pinned_at DESC LIMIT 20'
  ).bind(chatId).all()).results.map((r) => r.message_id);
  const pinned = (await fetchByIds(env, userId, pinIds)).filter((m) => !m.deleted);
  return { chat: { id: chat.id, title: chat.title, role: chat.role, muted: !!chat.muted }, members, pinned };
}

export async function createChat(env, user, input) {
  await rateLimit(env, `chatnew:${user.id}`, 30, 3600);
  const title = cleanLine(input.title || '', 60) || 'گفتگوی جدید';
  const names = Array.isArray(input.members) ? [...new Set(input.members.map((n) => String(n).trim().toLowerCase().replace(/^@/, '')).filter(Boolean))].slice(0, 20) : [];
  let users = [];
  if (names.length) {
    users = (await env.DB.prepare('SELECT id, username FROM users WHERE username IN (SELECT value FROM json_each(?))')
      .bind(JSON.stringify(names)).all()).results;
    const found = new Set(users.map((u) => u.username.toLowerCase()));
    const missing = names.filter((n) => !found.has(n));
    if (missing.length) throw new HttpError(404, 'user_not_found', missing.join(', '));
  }
  const id = crypto.randomUUID();
  const now = Date.now();
  const stmts = [
    env.DB.prepare('INSERT INTO chats (id, title, created_by, created_at, updated_at) VALUES (?,?,?,?,?)').bind(id, title, user.id, now, now),
    env.DB.prepare("INSERT INTO chat_members (chat_id, user_id, role, joined_at) VALUES (?,?,'owner',?)").bind(id, user.id, now),
  ];
  for (const u of users) {
    if (u.id !== user.id) stmts.push(env.DB.prepare("INSERT INTO chat_members (chat_id, user_id, role, joined_at) VALUES (?,?,'member',?)").bind(id, u.id, now));
  }
  await env.DB.batch(stmts);
  await pushToUsers(env, [user.id, ...users.map((u) => u.id)], { type: 'chat.updated', chat_id: id });
  return getChat(env, user.id, id);
}

export async function renameChat(env, execCtx, user, chatId, title) {
  const chat = await requireMember(env, chatId, user.id);
  if (chat.role !== 'owner') throw new HttpError(403, 'owner_only');
  const t = cleanLine(title || '', 60);
  if (!t) throw new HttpError(400, 'empty_title');
  await env.DB.prepare('UPDATE chats SET title = ?, updated_at = ? WHERE id = ?').bind(t, Date.now(), chatId).run();
  background(execCtx, publishChange(env, chatId, { type: 'chat.renamed', chat_id: chatId, title: t }));
  return { id: chatId, title: t };
}

export async function addMember(env, execCtx, user, chatId, username) {
  const chat = await requireMember(env, chatId, user.id);
  if (chat.role !== 'owner') throw new HttpError(403, 'owner_only');
  const name = String(username || '').trim().toLowerCase().replace(/^@/, '');
  const target = await env.DB.prepare('SELECT id, username, display_name, color FROM users WHERE username = ?').bind(name).first();
  if (!target) throw new HttpError(404, 'user_not_found', name);
  const count = await env.DB.prepare('SELECT COUNT(*) AS n FROM chat_members WHERE chat_id = ?').bind(chatId).first();
  if (count.n >= 100) throw new HttpError(400, 'chat_full');
  await env.DB.prepare("INSERT OR IGNORE INTO chat_members (chat_id, user_id, role, joined_at) VALUES (?,?,'member',?)")
    .bind(chatId, target.id, Date.now()).run();
  background(execCtx, (async () => {
    await broadcastToChat(env, chatId, { type: 'members.changed', chat_id: chatId });
    await pushToUser(env, target.id, { type: 'chat.updated', chat_id: chatId });
  })());
  return { id: target.id, username: target.username, display_name: target.display_name, color: target.color, role: 'member' };
}

export async function removeMember(env, execCtx, user, chatId, targetId) {
  const chat = await requireMember(env, chatId, user.id);
  if (chat.role !== 'owner') throw new HttpError(403, 'owner_only');
  if (!isId(targetId) || targetId === user.id) throw new HttpError(400, 'bad_member');
  await env.DB.batch([
    env.DB.prepare('DELETE FROM chat_members WHERE chat_id = ? AND user_id = ?').bind(chatId, targetId),
    env.DB.prepare('DELETE FROM message_status WHERE chat_id = ? AND user_id = ?').bind(chatId, targetId),
    env.DB.prepare('DELETE FROM notifications WHERE chat_id = ? AND user_id = ?').bind(chatId, targetId),
  ]);
  background(execCtx, (async () => {
    await kickFromChat(env, chatId, targetId);
    await broadcastToChat(env, chatId, { type: 'members.changed', chat_id: chatId });
    await pushToUser(env, targetId, { type: 'chat.removed', chat_id: chatId });
  })());
  return { ok: true };
}

// Owner: deletes the chat for everyone (D1 rows cascade, R2 objects removed first).
// Member: leaves the chat.
export async function deleteOrLeaveChat(env, execCtx, user, chatId) {
  const chat = await requireMember(env, chatId, user.id);
  if (chat.role !== 'owner') {
    await env.DB.batch([
      env.DB.prepare('DELETE FROM chat_members WHERE chat_id = ? AND user_id = ?').bind(chatId, user.id),
      env.DB.prepare('DELETE FROM message_status WHERE chat_id = ? AND user_id = ?').bind(chatId, user.id),
      env.DB.prepare('DELETE FROM notifications WHERE chat_id = ? AND user_id = ?').bind(chatId, user.id),
    ]);
    background(execCtx, (async () => {
      await kickFromChat(env, chatId, user.id);
      await broadcastToChat(env, chatId, { type: 'members.changed', chat_id: chatId });
    })());
    return { left: true };
  }
  const members = await memberIds(env, chatId);
  for (let i = 0; i < 50; i++) {
    const keys = (await env.DB.prepare('SELECT r2_key FROM attachments WHERE chat_id = ? LIMIT 500').bind(chatId).all()).results.map((r) => r.r2_key);
    if (!keys.length) break;
    await deleteObjects(env, keys);
    await env.DB.prepare('DELETE FROM attachments WHERE r2_key IN (SELECT value FROM json_each(?))').bind(JSON.stringify(keys)).run();
  }
  await env.DB.prepare('DELETE FROM chats WHERE id = ?').bind(chatId).run();
  background(execCtx, (async () => {
    await broadcastToChat(env, chatId, { type: 'chat.removed', chat_id: chatId });
    await kickFromChat(env, chatId);
    await pushToUsers(env, members, { type: 'chat.removed', chat_id: chatId });
  })());
  return { deleted: true };
}

// ---------------------------------------------------------------- search

export async function searchMessages(env, userId, { q, priority, chatId, scope, limit }) {
  const now = Date.now();
  const words = tokenize(q || '', 5);
  if (q && q.trim() && !words.length) return [];
  if (!words.length && !priority) return [];
  if (priority && !PRIORITIES.includes(priority)) throw new HttpError(400, 'bad_priority');
  limit = clamp(Math.floor(Number(limit)) || 30, 1, 50);

  const binds = [userId];
  let sql = `SELECT m.id, m.seq FROM messages m
              WHERE m.deleted_at IS NULL AND (m.expires_at IS NULL OR m.expires_at > ?)
                AND m.chat_id IN (SELECT chat_id FROM chat_members WHERE user_id = ?)`;
  binds.unshift(now);
  if (chatId) { sql += ' AND m.chat_id = ?'; binds.push(chatId); }
  if (priority) { sql += ' AND m.priority = ?'; binds.push(priority); }
  if (words.length) {
    const tokens = await blindTokens(env, words);
    sql += ` AND m.id IN (SELECT message_id FROM message_tokens WHERE token IN (SELECT value FROM json_each(?))
                AND chat_id IN (SELECT chat_id FROM chat_members WHERE user_id = ?) GROUP BY message_id HAVING COUNT(DISTINCT token) = ?)`;
    binds.push(JSON.stringify(tokens), userId, tokens.length);
  }
  if (scope === 'files') sql += ' AND EXISTS (SELECT 1 FROM attachments a WHERE a.message_id = m.id AND a.deleted_at IS NULL)';
  sql += ' ORDER BY m.seq DESC LIMIT ?';
  binds.push(limit);
  const ids = (await env.DB.prepare(sql).bind(...binds).all()).results.map((r) => r.id);
  const msgs = await fetchByIds(env, userId, ids);
  return msgs.sort((a, b) => b.seq - a.seq);
}
