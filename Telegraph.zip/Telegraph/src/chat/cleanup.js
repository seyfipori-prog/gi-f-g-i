// Server-side expiry enforcement + housekeeping.
// Messages with expires_at <= now are already invisible to every query (see service.js);
// this module physically removes them (D1 rows cascade) and their R2 objects.
// Triggered by: the ChatRoom Durable Object alarm (timely) and the cron trigger (safety net).
import { log } from '../security/http.js';
import { deleteObjects } from '../files/objects.js';

export async function purgeExpired(env, { chatId = null, limit = 100 } = {}) {
  const now = Date.now();
  const rows = (await env.DB.prepare(
    `SELECT id, chat_id FROM messages WHERE expires_at IS NOT NULL AND expires_at <= ? ${chatId ? 'AND chat_id = ?' : ''}
      ORDER BY expires_at LIMIT ?`
  ).bind(...(chatId ? [now, chatId, limit] : [now, limit])).all()).results;
  if (!rows.length) return [];
  const ids = JSON.stringify(rows.map((r) => r.id));
  const keys = (await env.DB.prepare(
    'SELECT r2_key FROM attachments WHERE message_id IN (SELECT value FROM json_each(?))'
  ).bind(ids).all()).results.map((r) => r.r2_key);
  await deleteObjects(env, keys); // if R2 fails we throw and retry next run: rows stay until files are gone
  await env.DB.prepare('DELETE FROM messages WHERE id IN (SELECT value FROM json_each(?))').bind(ids).run();
  return rows;
}

export async function runScheduled(env) {
  const now = Date.now();
  try {
    for (let i = 0; i < 10; i++) {
      const purged = await purgeExpired(env, { limit: 200 });
      if (purged.length < 200) break;
    }
    // Uploads that were never attached to a message (abandoned composer drafts).
    const orphans = (await env.DB.prepare(
      'SELECT id, r2_key FROM attachments WHERE message_id IS NULL AND created_at < ? LIMIT 200'
    ).bind(now - 3600e3).all()).results;
    if (orphans.length) {
      await deleteObjects(env, orphans.map((o) => o.r2_key));
      await env.DB.prepare('DELETE FROM attachments WHERE id IN (SELECT value FROM json_each(?))')
        .bind(JSON.stringify(orphans.map((o) => o.id))).run();
    }
    await env.DB.prepare('DELETE FROM sessions WHERE expires_at < ?').bind(now).run();
    await env.DB.prepare('DELETE FROM rate_limits WHERE window_start < ?').bind(now - 86400e3).run();
    log('info', 'cleanup_done', { orphans: orphans.length });
  } catch (e) {
    log('error', 'cleanup_failed', { message: String(e) });
  }
}
