// Thin client for the Durable Objects. Realtime is best-effort: D1 is the source of truth,
// so a failure here is logged and never fails the HTTP request.
import { log } from '../security/http.js';

const roomStub = (env, chatId) => env.CHAT_ROOM.get(env.CHAT_ROOM.idFromName(chatId));
const hubStub = (env, userId) => env.USER_HUB.get(env.USER_HUB.idFromName(userId));

async function post(stub, path, body) {
  const res = await stub.fetch(`https://do.internal${path}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return res.json();
}

export async function broadcastToChat(env, chatId, payload, exceptUser = null) {
  try {
    const r = await post(roomStub(env, chatId), '/broadcast', { payload, except_user: exceptUser });
    return r.online || [];
  } catch (e) {
    log('warn', 'broadcast_failed', { message: String(e) });
    return [];
  }
}

export async function pushToUser(env, userId, payload) {
  try {
    const r = await post(hubStub(env, userId), '/push', { payload });
    return !!r.online;
  } catch (e) {
    log('warn', 'push_failed', { message: String(e) });
    return false;
  }
}

export const pushToUsers = (env, userIds, payload) => Promise.all(userIds.map((id) => pushToUser(env, id, payload)));

export async function scheduleExpiry(env, chatId, at) {
  try { await post(roomStub(env, chatId), '/schedule', { at, chat_id: chatId }); } catch (e) { log('warn', 'schedule_failed', { message: String(e) }); }
}

export async function kickFromChat(env, chatId, userId = null) {
  try { await post(roomStub(env, chatId), '/kick', { user_id: userId }); } catch { /* ignore */ }
}

export async function kickUser(env, userId) {
  try { await post(hubStub(env, userId), '/kick', {}); } catch { /* ignore */ }
}

// Forward an authenticated WebSocket upgrade to the right Durable Object.
export function connectSocket(env, request, kind, name, { user, session, chatId }) {
  const stub = kind === 'room' ? roomStub(env, name) : hubStub(env, name);
  const headers = new Headers(request.headers);
  headers.set('x-tg-user', user.id);
  headers.set('x-tg-name', encodeURIComponent(user.display_name));
  headers.set('x-tg-exp', String(session.expiresAt));
  if (chatId) headers.set('x-tg-chat', chatId);
  return stub.fetch(new Request('https://do.internal/connect', { method: 'GET', headers }));
}
