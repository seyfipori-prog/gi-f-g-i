// Upload allow-list. The browser-provided MIME type and filename are NEVER trusted:
// the declared type must be on this list AND the file's leading bytes must match its signature.
import { HttpError } from '../security/http.js';

const MB = 1024 * 1024;

// sig: which magic-number check applies (see sniff.js)
export const TYPES = {
  'image/jpeg': { cat: 'image', ext: 'jpg', max: 15 * MB, sig: 'jpeg' },
  'image/png': { cat: 'image', ext: 'png', max: 15 * MB, sig: 'png' },
  'image/gif': { cat: 'image', ext: 'gif', max: 15 * MB, sig: 'gif' },
  'image/webp': { cat: 'image', ext: 'webp', max: 15 * MB, sig: 'webp' },
  'video/mp4': { cat: 'video', ext: 'mp4', max: 50 * MB, sig: 'mp4' },
  'video/quicktime': { cat: 'video', ext: 'mov', max: 50 * MB, sig: 'mp4' },
  'video/webm': { cat: 'video', ext: 'webm', max: 50 * MB, sig: 'webm' },
  'audio/webm': { cat: 'audio', ext: 'webm', max: 20 * MB, sig: 'webm' },
  'audio/ogg': { cat: 'audio', ext: 'ogg', max: 20 * MB, sig: 'ogg' },
  'audio/mp4': { cat: 'audio', ext: 'm4a', max: 20 * MB, sig: 'mp4' },
  'audio/mpeg': { cat: 'audio', ext: 'mp3', max: 20 * MB, sig: 'mp3' },
  'audio/wav': { cat: 'audio', ext: 'wav', max: 20 * MB, sig: 'wav' },
  'application/pdf': { cat: 'pdf', ext: 'pdf', max: 30 * MB, sig: 'pdf' },
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': { cat: 'document', ext: 'docx', max: 25 * MB, sig: 'zip' },
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': { cat: 'document', ext: 'xlsx', max: 25 * MB, sig: 'zip' },
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': { cat: 'document', ext: 'pptx', max: 25 * MB, sig: 'zip' },
  'application/msword': { cat: 'document', ext: 'doc', max: 25 * MB, sig: 'ole' },
  'application/vnd.ms-excel': { cat: 'document', ext: 'xls', max: 25 * MB, sig: 'ole' },
  'application/vnd.ms-powerpoint': { cat: 'document', ext: 'ppt', max: 25 * MB, sig: 'ole' },
  'text/plain': { cat: 'document', ext: 'txt', max: 5 * MB, sig: 'text' },
  'text/csv': { cat: 'document', ext: 'csv', max: 5 * MB, sig: 'text' },
  'application/zip': { cat: 'document', ext: 'zip', max: 25 * MB, sig: 'zip', downloadOnly: true },
};

const ALIASES = {
  'image/jpg': 'image/jpeg', 'image/pjpeg': 'image/jpeg', 'audio/x-wav': 'audio/wav', 'audio/wave': 'audio/wav',
  'audio/mp3': 'audio/mpeg', 'audio/x-m4a': 'audio/mp4', 'video/x-matroska': 'video/webm',
  'application/x-zip-compressed': 'application/zip', 'application/csv': 'text/csv',
};

const EXT_TO_MIME = Object.fromEntries(
  Object.entries(TYPES).map(([mime, v]) => [v.ext, mime]).concat([['jpeg', 'image/jpeg'], ['mpga', 'audio/mpeg']]));

// Categories safe to render inline in the browser (never html/svg/js).
export const INLINE_CATEGORIES = new Set(['image', 'video', 'audio', 'pdf']);

export function resolveType(declaredMime, filename) {
  let mime = String(declaredMime || '').split(';')[0].trim().toLowerCase();
  mime = ALIASES[mime] || mime;
  if (!mime || mime === 'application/octet-stream') {
    const ext = (String(filename).match(/\.([A-Za-z0-9]{1,8})$/) || [])[1];
    mime = (ext && EXT_TO_MIME[ext.toLowerCase()]) || '';
  }
  const spec = TYPES[mime];
  if (!spec) throw new HttpError(415, 'unsupported_type');
  return { mime, spec };
}

// Reduce a user-supplied filename to something safe to store and show.
// Path components are dropped, dangerous characters removed, and the extension is forced to match
// the detected type, so "invoice.pdf.exe" can never keep a misleading extension.
export function sanitizeFilename(name, spec) {
  let n = String(name || '').normalize('NFC');
  n = n.split(/[\\/]/).pop();
  n = n.replace(/[\u0000-\u001F\u007F\u202A-\u202E\u2066-\u2069\uFEFF]/g, '')
       .replace(/[<>:"|?*]/g, '_')
       .replace(/^\.+/, '')
       .replace(/\s+/g, ' ')
       .trim();
  n = n.replace(/\.[A-Za-z0-9]{1,8}$/, '');
  if (!n) n = 'file';
  return `${n.slice(0, 100)}.${spec.ext}`;
}

// R2 key: only server-generated identifiers. User input never reaches the key.
export function newStorageKey(chatId, userId) {
  return `chats/${chatId}/${userId}/${crypto.randomUUID()}`;
}
