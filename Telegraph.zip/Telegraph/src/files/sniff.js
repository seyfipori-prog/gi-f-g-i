// Magic-number validation, done while the upload streams to R2 (no buffering of the whole file).
import { HttpError } from '../security/http.js';

const startsWith = (b, ...bytes) => bytes.every((v, i) => b[i] === v);
const ascii = (b, from, str) => [...str].every((c, i) => b[from + i] === c.charCodeAt(0));

const CHECKS = {
  jpeg: (b) => startsWith(b, 0xff, 0xd8, 0xff),
  png: (b) => startsWith(b, 0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a),
  gif: (b) => ascii(b, 0, 'GIF87a') || ascii(b, 0, 'GIF89a'),
  webp: (b) => ascii(b, 0, 'RIFF') && ascii(b, 8, 'WEBP'),
  mp4: (b) => ascii(b, 4, 'ftyp'),
  webm: (b) => startsWith(b, 0x1a, 0x45, 0xdf, 0xa3),
  ogg: (b) => ascii(b, 0, 'OggS'),
  mp3: (b) => ascii(b, 0, 'ID3') || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0),
  wav: (b) => ascii(b, 0, 'RIFF') && ascii(b, 8, 'WAVE'),
  pdf: (b) => ascii(b, 0, '%PDF-'),
  zip: (b) => startsWith(b, 0x50, 0x4b, 0x03, 0x04),
  ole: (b) => startsWith(b, 0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1),
  text: () => true, // checked per chunk below (no NUL bytes, valid UTF-8 start)
};

// Hook for stronger validation later (ClamAV/VirusTotal-style scanning, Office macro inspection,
// image re-encoding...). Return { status: 'clean' | 'pending' | 'skipped' } or throw HttpError.
export async function scanFile(/* env, { key, mime, size } */) {
  return { status: 'skipped' };
}

export function validatingStream(spec, maxBytes, state) {
  let seen = 0;
  let head = new Uint8Array(0);
  let verified = false;
  const decoder = new TextDecoder('utf-8', { fatal: true });
  const fail = (code, status) => {
    const err = new HttpError(status, code);
    state.error = err;
    throw err;
  };
  const verify = () => {
    if (head.length < 12 && spec.sig !== 'text' && head.length < 4) fail('content_mismatch', 415);
    if (!CHECKS[spec.sig](head)) fail('content_mismatch', 415);
    verified = true;
    head = null;
  };
  return new TransformStream({
    transform(chunk, controller) {
      seen += chunk.byteLength;
      if (seen > maxBytes) fail('file_too_large', 413);
      if (!verified) {
        const merged = new Uint8Array(head.length + chunk.byteLength);
        merged.set(head);
        merged.set(chunk, head.length);
        head = merged;
        if (head.length >= 16) verify();
      }
      if (spec.sig === 'text') {
        if (chunk.includes(0)) fail('content_mismatch', 415);
        try { decoder.decode(chunk, { stream: true }); } catch { fail('content_mismatch', 415); }
      }
      controller.enqueue(chunk);
    },
    flush() {
      if (seen === 0) fail('empty_file', 400);
      if (!verified) verify();
    },
  });
}
