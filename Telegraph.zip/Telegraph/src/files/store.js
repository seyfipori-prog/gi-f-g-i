// R2 + D1 handling for attachments: upload (streaming), download (range-aware), delete.
import { HttpError, json, log, clamp, requireId } from '../security/http.js';
import { rateLimit } from '../security/ratelimit.js';
import { encryptText, safeDecrypt } from '../security/crypto.js';
import { cleanLine } from '../security/text.js';
import { resolveType, sanitizeFilename, newStorageKey, INLINE_CATEGORIES } from './policy.js';
import { validatingStream, scanFile } from './sniff.js';
import { requireMember } from '../chat/service.js';

export async function uploadFile({ request, env, url, user }) {
  const chatId = requireId(url.searchParams.get('chat'), 'chat_not_found');
  await requireMember(env, chatId, user.id);
  await rateLimit(env, `upload:${user.id}`, 40, 600);

  const length = Number(request.headers.get('content-length'));
  if (!Number.isFinite(length) || length <= 0) throw new HttpError(411, 'length_required');
  if (!request.body) throw new HttpError(400, 'empty_file');

  const rawName = cleanLine(url.searchParams.get('name') || 'file', 255);
  const { mime, spec } = resolveType(request.headers.get('content-type'), rawName);
  if (length > spec.max) throw new HttpError(413, 'file_too_large');

  const isVoice = url.searchParams.get('voice') === '1' && spec.cat === 'audio';
  const duration = isVoice ? clamp(Number(url.searchParams.get('duration')) || 0, 0, 3600e3) : null;
  const filename = isVoice ? `voice.${spec.ext}` : sanitizeFilename(rawName, spec);
  const key = newStorageKey(chatId, user.id);
  const id = crypto.randomUUID();

  const state = { error: null };
  const { readable, writable } = new FixedLengthStream(length);
  const piping = request.body.pipeThrough(validatingStream(spec, spec.max, state)).pipeTo(writable);
  try {
    await Promise.all([
      env.FILES.put(key, readable, { httpMetadata: { contentType: mime }, customMetadata: { chat: chatId, uploader: user.id, attachment: id } }),
      piping,
    ]);
  } catch (e) {
    await env.FILES.delete(key).catch(() => {});
    if (state.error) throw state.error;
    log('warn', 'upload_failed', { message: String(e) });
    throw new HttpError(400, 'upload_failed');
  }

  let scan;
  try {
    scan = await scanFile(env, { key, mime, size: length });
  } catch (e) {
    await env.FILES.delete(key).catch(() => {});
    throw e;
  }

  const now = Date.now();
  const encName = await encryptText(env, `chat:${chatId}`, filename, `a:${id}`);
  await env.DB.prepare(
    `INSERT INTO attachments (id, chat_id, message_id, uploader_id, r2_key, filename, mime, size, category, is_voice, duration_ms, scan_status, created_at)
     VALUES (?,?,NULL,?,?,?,?,?,?,?,?,?,?)`
  ).bind(id, chatId, user.id, key, encName, mime, length, spec.cat, isVoice ? 1 : 0, duration, scan.status, now).run();

  return json({ attachment: { id, filename, mime, size: length, category: spec.cat, is_voice: isVoice, duration_ms: duration, url: `/api/files/${id}` } }, 201);
}

function contentDisposition(kind, filename) {
  const ascii = filename.replace(/[^\x20-\x7e]/g, '_').replace(/["\\]/g, '_');
  return `${kind}; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(filename).replace(/['()*]/g, (c) => '%' + c.charCodeAt(0).toString(16))}`;
}

export async function downloadFile({ request, env, params, url, user }) {
  const id = requireId(params.id, 'file_not_found');
  const row = await env.DB.prepare(
    `SELECT a.id, a.chat_id, a.message_id, a.uploader_id, a.r2_key, a.filename, a.mime, a.category, a.scan_status,
            m.deleted_at AS m_deleted, m.expires_at AS m_expires
       FROM attachments a LEFT JOIN messages m ON m.id = a.message_id
      WHERE a.id = ? AND a.deleted_at IS NULL`
  ).bind(id).first();
  if (!row) throw new HttpError(404, 'file_not_found');
  await requireMember(env, row.chat_id, user.id).catch(() => { throw new HttpError(404, 'file_not_found'); });

  const now = Date.now();
  if (!row.message_id) {
    if (row.uploader_id !== user.id) throw new HttpError(404, 'file_not_found'); // unsent upload: uploader only
  } else if (row.m_deleted || (row.m_expires && row.m_expires <= now)) {
    throw new HttpError(404, 'file_not_found');
  }
  if (row.scan_status === 'infected' || row.scan_status === 'pending') throw new HttpError(423, 'file_blocked');

  const object = await env.FILES.get(row.r2_key, { range: request.headers });
  if (!object) throw new HttpError(404, 'file_not_found');

  const name = (await safeDecrypt(env, `chat:${row.chat_id}`, row.filename, `a:${row.id}`)) || 'file';
  const download = url.searchParams.get('download') === '1' || !INLINE_CATEGORIES.has(row.category) || row.mime === 'application/zip';
  const headers = new Headers({
    'content-type': row.mime,
    'accept-ranges': 'bytes',
    'content-disposition': contentDisposition(download ? 'attachment' : 'inline', name),
    'x-content-type-options': 'nosniff',
    etag: object.httpEtag,
    'cache-control': row.m_expires ? 'private, no-store' : 'private, max-age=600',
  });
  if (row.mime !== 'application/pdf') headers.set('content-security-policy', "default-src 'none'; sandbox");
  let status = 200;
  if (object.range && request.headers.get('range')) {
    const { offset = 0, length = object.size - offset } = object.range;
    headers.set('content-range', `bytes ${offset}-${offset + length - 1}/${object.size}`);
    headers.set('content-length', String(length));
    status = 206;
  } else {
    headers.set('content-length', String(object.size));
  }
  return new Response(object.body, { status, headers });
}

// Delete an upload that was never attached to a message (user removed it from the composer).
export async function discardUpload({ env, params, user }) {
  const id = requireId(params.id, 'file_not_found');
  const row = await env.DB.prepare('SELECT r2_key FROM attachments WHERE id = ? AND uploader_id = ? AND message_id IS NULL')
    .bind(id, user.id).first();
  if (!row) throw new HttpError(404, 'file_not_found');
  await env.FILES.delete(row.r2_key);
  await env.DB.prepare('DELETE FROM attachments WHERE id = ?').bind(id).run();
  return json({ ok: true });
}
