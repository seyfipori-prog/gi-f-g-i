// Bulk R2 deletion (R2 allows up to 1000 keys per call).
export async function deleteObjects(env, keys) {
  for (let i = 0; i < keys.length; i += 500) await env.FILES.delete(keys.slice(i, i + 500));
}
