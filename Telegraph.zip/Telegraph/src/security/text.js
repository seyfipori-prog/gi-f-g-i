// Input sanitising + tokenising helpers.

// Strip control chars and bidi override/isolate characters (used for visual spoofing).
const BAD_CHARS = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u202A-\u202E\u2066-\u2069\uFEFF]/g;

export function cleanLine(s, max = 60) {
  if (typeof s !== 'string') return '';
  return s.normalize('NFC').replace(BAD_CHARS, '').replace(/\s+/g, ' ').trim().slice(0, max);
}

export function cleanBody(s, max = 8000) {
  if (typeof s !== 'string') return '';
  return s.normalize('NFC').replace(BAD_CHARS, '').replace(/\r\n?/g, '\n').trim().slice(0, max);
}

const DIGITS = { '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4', '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
  '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4', '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9' };

// Normalise Persian/Arabic variants so searches match regardless of keyboard.
export function normalizeForSearch(s) {
  return String(s)
    .normalize('NFKC')
    .replace(/[۰-۹٠-٩]/g, (d) => DIGITS[d])
    .replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/ە/g, 'ه')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '') // harakat + tatweel
    .toLowerCase();
}

export function tokenize(text, max = 30) {
  const words = normalizeForSearch(text || '').match(/[\p{L}\p{N}]+/gu) || [];
  const out = new Set();
  for (const w of words) {
    if (w.length < 2 && !/^\d$/.test(w)) continue;
    out.add(w.slice(0, 40));
    if (out.size >= max) break;
  }
  return [...out];
}

export function escapeLike(s) {
  return s.replace(/[\\%_]/g, (c) => '\\' + c);
}
