import { HttpError, clientIp, log } from './http.js';

// Fixed-window rate limiter backed by D1 (table rate_limits).
// To switch to Cloudflare's native Rate Limiting binding, change the body of `hit()` only;
// every caller goes through `rateLimit()`.
async function hit(env, key, windowMs) {
  const now = Date.now();
  const row = await env.DB.prepare(
    `INSERT INTO rate_limits (key, window_start, count) VALUES (?, ?, 1)
     ON CONFLICT(key) DO UPDATE SET
       count = CASE WHEN window_start < ? THEN 1 ELSE count + 1 END,
       window_start = CASE WHEN window_start < ? THEN ? ELSE window_start END
     RETURNING count, window_start`
  ).bind(key, now, now - windowMs, now - windowMs, now).first();
  return { count: row.count, resetMs: row.window_start + windowMs - now };
}

export async function rateLimit(env, key, limit, windowSeconds) {
  let result;
  try {
    result = await hit(env, key, windowSeconds * 1000);
  } catch (e) {
    log('error', 'ratelimit_failed', { message: String(e) }); // fail open on infrastructure errors
    return;
  }
  if (result.count > limit) {
    const err = new HttpError(429, 'rate_limited');
    err.retryAfter = Math.max(1, Math.ceil(result.resetMs / 1000));
    throw err;
  }
}

export const limitByIp = (env, request, scope, limit, windowSeconds) =>
  rateLimit(env, `${scope}:ip:${clientIp(request)}`, limit, windowSeconds);
