import { HttpError } from './http.js';

// CSRF defence in depth:
//  1. Session cookie is SameSite=Lax + HttpOnly.
//  2. Every state-changing request must carry a custom header. Browsers cannot attach it
//     cross-site without a CORS preflight, and this Worker never answers preflights.
//  3. If an Origin header is present it must match the app origin.
export const CSRF_HEADER = 'x-telegraph-request';

export function expectedOrigin(request, env) {
  return env.APP_ORIGIN ? env.APP_ORIGIN.replace(/\/$/, '') : new URL(request.url).origin;
}

export function assertSameOrigin(request, env) {
  const origin = request.headers.get('origin');
  if (origin && origin !== expectedOrigin(request, env)) throw new HttpError(403, 'bad_origin');
}

export function assertCsrf(request, env) {
  const m = request.method;
  if (m === 'GET' || m === 'HEAD' || m === 'OPTIONS') return;
  assertSameOrigin(request, env);
  if (request.headers.get(CSRF_HEADER) !== '1') throw new HttpError(403, 'csrf');
}
