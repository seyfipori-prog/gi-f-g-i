// SERVER-SIDE encryption at rest (Web Crypto). This is NOT end-to-end encryption:
// the Worker holds the keys and can read content. See SECURITY.md for the E2EE roadmap
// and public/js/e2ee.js for the client-side scaffolding.
//
// Format of stored ciphertext:  enc1:<keyId>:<iv base64url>:<ciphertext base64url>
//  - AES-256-GCM with a fresh 96-bit IV per value
//  - per-conversation key = HKDF-SHA256(masterKey[keyId], info = scope)
//  - AAD binds the ciphertext to its row (message/attachment id) so values cannot be swapped
//  - key rotation: add a new id to MASTER_KEYS, set ACTIVE_KEY_ID; old ids remain for decryption.

import { HttpError } from './http.js';

const te = new TextEncoder();
const td = new TextDecoder();

export function b64uEncode(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export function b64uDecode(str) {
  const b = atob(str.replace(/-/g, '+').replace(/_/g, '/'));
  const out = new Uint8Array(b.length);
  for (let i = 0; i < b.length; i++) out[i] = b.charCodeAt(i);
  return out;
}
export const hex = (bytes) => [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('');

export async function sha256Hex(input) {
  const data = typeof input === 'string' ? te.encode(input) : input;
  return hex(new Uint8Array(await crypto.subtle.digest('SHA-256', data)));
}

const masterCache = new Map();
const derivedCache = new Map();
let indexKeyCache = null;

function parseKeys(env) {
  let map;
  try {
    map = JSON.parse(env.MASTER_KEYS || '');
  } catch {
    throw new HttpError(500, 'server_misconfigured', 'MASTER_KEYS secret is missing or invalid');
  }
  if (!map || typeof map !== 'object' || !Object.keys(map).length)
    throw new HttpError(500, 'server_misconfigured', 'MASTER_KEYS is empty');
  return map;
}

async function masterKey(env, keyId) {
  const ck = `${keyId}|${env.MASTER_KEYS}`;
  if (masterCache.has(ck)) return masterCache.get(ck);
  const map = parseKeys(env);
  if (!map[keyId]) throw new HttpError(500, 'unknown_key_id', `Key id ${keyId} not configured`);
  const bytes = b64uDecode(String(map[keyId]).replace(/=+$/, ''));
  if (bytes.length !== 32) throw new HttpError(500, 'server_misconfigured', 'Master keys must be 32 bytes');
  const key = await crypto.subtle.importKey('raw', bytes, 'HKDF', false, ['deriveKey']);
  masterCache.set(ck, key);
  return key;
}

async function scopedKey(env, keyId, scope) {
  const ck = `${keyId}|${scope}|${env.MASTER_KEYS}`;
  if (derivedCache.has(ck)) return derivedCache.get(ck);
  const base = await masterKey(env, keyId);
  const key = await crypto.subtle.deriveKey(
    { name: 'HKDF', hash: 'SHA-256', salt: new Uint8Array(0), info: te.encode(`telegraph/v1/${scope}`) },
    base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  if (derivedCache.size > 2000) derivedCache.clear();
  derivedCache.set(ck, key);
  return key;
}

export async function encryptText(env, scope, plaintext, aad) {
  const keyId = String(env.ACTIVE_KEY_ID || '1');
  const key = await scopedKey(env, keyId, scope);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: te.encode(aad) }, key, te.encode(plaintext)));
  return `enc1:${keyId}:${b64uEncode(iv)}:${b64uEncode(ct)}`;
}

export async function decryptText(env, scope, stored, aad) {
  if (stored == null) return null;
  const parts = String(stored).split(':');
  if (parts.length !== 4 || parts[0] !== 'enc1') throw new HttpError(500, 'bad_ciphertext');
  const key = await scopedKey(env, parts[1], scope);
  const pt = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: b64uDecode(parts[2]), additionalData: te.encode(aad) }, key, b64uDecode(parts[3]));
  return td.decode(pt);
}

// Never let a single undecryptable row break a whole page.
export async function safeDecrypt(env, scope, stored, aad) {
  try { return await decryptText(env, scope, stored, aad); } catch { return null; }
}

// Blind index token for searchable encryption: HMAC-SHA256(INDEX_KEY, word) -> 24 hex chars.
export async function blindToken(env, word) {
  if (!indexKeyCache || indexKeyCache.raw !== env.INDEX_KEY) {
    let bytes;
    try { bytes = b64uDecode(String(env.INDEX_KEY || '').replace(/=+$/, '')); } catch { bytes = new Uint8Array(0); }
    if (bytes.length !== 32) throw new HttpError(500, 'server_misconfigured', 'INDEX_KEY secret is missing or invalid');
    indexKeyCache = { raw: env.INDEX_KEY, key: await crypto.subtle.importKey('raw', bytes, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']) };
  }
  const sig = new Uint8Array(await crypto.subtle.sign('HMAC', indexKeyCache.key, te.encode(word)));
  return hex(sig.slice(0, 12));
}
export const blindTokens = (env, words) => Promise.all(words.map((w) => blindToken(env, w)));

export function randomToken(bytes = 32) {
  return b64uEncode(crypto.getRandomValues(new Uint8Array(bytes)));
}

export function timingSafeEqual(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}
