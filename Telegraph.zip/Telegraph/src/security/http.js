// Small HTTP helpers shared by every API module.

export class HttpError extends Error {
  constructor(status, code, message) {
    super(message || code);
    this.status = status;
    this.code = code;
  }
}

export function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers },
  });
}

export async function readJson(request, maxBytes = 64 * 1024) {
  const type = request.headers.get('content-type') || '';
  if (!type.includes('application/json')) throw new HttpError(415, 'json_required');
  const len = Number(request.headers.get('content-length') || 0);
  if (len > maxBytes) throw new HttpError(413, 'body_too_large');
  const text = await request.text();
  if (text.length > maxBytes) throw new HttpError(413, 'body_too_large');
  try {
    const v = JSON.parse(text);
    if (v === null || typeof v !== 'object') throw new Error('not object');
    return v;
  } catch {
    throw new HttpError(400, 'invalid_json');
  }
}

export function log(level, event, data = {}) {
  // Structured logs surface in Workers Logs / `wrangler tail`. Never log secrets or message bodies.
  console[level === 'error' ? 'error' : level === 'warn' ? 'warn' : 'log'](JSON.stringify({ level, event, ...data }));
}

const ID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
export const isId = (v) => typeof v === 'string' && ID_RE.test(v);
export function requireId(v, code = 'not_found') {
  if (!isId(v)) throw new HttpError(404, code);
  return v;
}

export function clientIp(request) {
  return request.headers.get('cf-connecting-ip') || request.headers.get('x-forwarded-for') || 'local';
}

export const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
