// Security headers applied to every response served by the Worker.

export function securityHeaders(request) {
  const url = new URL(request.url);
  const wsScheme = url.protocol === 'https:' ? 'wss' : 'ws';
  const csp = [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self'",
    "img-src 'self' data: blob:",
    "media-src 'self' blob:",
    "font-src 'self'",
    `connect-src 'self' ${wsScheme}://${url.host}`,
    "object-src 'none'",
    "base-uri 'none'",
    "form-action 'self'",
    "frame-ancestors 'none'",
    "manifest-src 'self'",
  ].join('; ');
  return {
    'content-security-policy': csp,
    'x-content-type-options': 'nosniff',
    'x-frame-options': 'DENY',
    'referrer-policy': 'no-referrer',
    'permissions-policy': 'microphone=(self), camera=(), geolocation=(), payment=()',
    'cross-origin-opener-policy': 'same-origin',
    'cross-origin-resource-policy': 'same-origin',
    ...(url.protocol === 'https:' ? { 'strict-transport-security': 'max-age=31536000; includeSubDomains' } : {}),
  };
}

export function withSecurityHeaders(response, request) {
  if (response.status === 101) return response; // WebSocket upgrade must be returned untouched
  const res = new Response(response.body, response);
  for (const [k, v] of Object.entries(securityHeaders(request))) {
    // A per-response CSP (e.g. file downloads) wins over the default one.
    if (k === 'content-security-policy' && res.headers.has(k)) continue;
    res.headers.set(k, v);
  }
  return res;
}
