// Test harness: runs the REAL Worker code in Node with shims for D1 (node:sqlite), R2 and Durable Objects.
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { webcrypto } from 'node:crypto';

if (!globalThis.crypto) globalThis.crypto = webcrypto;
globalThis.FixedLengthStream = class extends TransformStream {
  constructor(len) { super(); this.expectedLength = len; }
};

class Stmt {
  constructor(db, sql) { this.db = db; this.sql = sql; this.args = []; }
  bind(...a) { this.args = a.map((v) => (v === undefined ? null : v)); return this; }
  async first() { return this.db.prepare(this.sql).get(...this.args) ?? null; }
  async all() { return { results: this.db.prepare(this.sql).all(...this.args), meta: {} }; }
  async run() { const i = this.db.prepare(this.sql).run(...this.args); return { meta: { changes: Number(i.changes) } }; }
  _exec() { return this.db.prepare(this.sql).all(...this.args); }
}
class D1 {
  constructor() {
    this.db = new DatabaseSync(':memory:');
    this.db.exec('PRAGMA foreign_keys = ON');
    this.db.exec(readFileSync(new URL('../schema.sql', import.meta.url), 'utf8'));
  }
  prepare(sql) { return new Stmt(this.db, sql); }
  async batch(stmts) {
    this.db.exec('BEGIN');
    try { const out = stmts.map((s) => ({ results: s._exec() })); this.db.exec('COMMIT'); return out; }
    catch (e) { this.db.exec('ROLLBACK'); throw e; }
  }
}

class R2 {
  constructor() { this.objects = new Map(); }
  async put(key, stream, opts = {}) {
    const chunks = [];
    const reader = stream.getReader();
    for (;;) { const { done, value } = await reader.read(); if (done) break; chunks.push(Buffer.from(value)); }
    this.objects.set(key, { data: Buffer.concat(chunks), opts });
  }
  async get(key, opts = {}) {
    const o = this.objects.get(key);
    if (!o) return null;
    let data = o.data; let range;
    const h = opts.range && opts.range.get && opts.range.get('range');
    if (h) {
      const m = /bytes=(\d*)-(\d*)/.exec(h);
      const start = m[1] ? Number(m[1]) : 0; const end = m[2] ? Number(m[2]) : data.length - 1;
      data = data.subarray(start, end + 1); range = { offset: start, length: data.length };
    }
    return { body: new Blob([data]).stream(), size: o.data.length, httpEtag: '"etag"', range };
  }
  async delete(keys) { for (const k of [].concat(keys)) this.objects.delete(k); }
}

// Durable Object mocks: record traffic, let tests decide who is "online".
export function makeDoNamespace(log, onlineFor) {
  return {
    idFromName: (n) => n,
    get: (name) => ({
      async fetch(url, init) {
        const path = new URL(url).pathname;
        const body = init && init.body ? JSON.parse(init.body) : {};
        log.push({ name, path, body });
        if (path === '/push') return Response.json({ online: onlineFor(name) });
        if (path === '/broadcast') return Response.json({ online: onlineFor(name, true) });
        return Response.json({ ok: true });
      },
    }),
  };
}

export function makeEnv() {
  const k = () => Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString('base64');
  const rooms = []; const hubs = [];
  const online = { hub: new Set(), room: new Set() };
  return {
    DB: new D1(), FILES: new R2(),
    CHAT_ROOM: makeDoNamespace(rooms, (n, isRoom) => (isRoom ? [...online.room] : online.hub.has(n))),
    USER_HUB: makeDoNamespace(hubs, (n) => online.hub.has(n)),
    ASSETS: { fetch: async () => new Response('<html></html>', { status: 200 }) },
    MASTER_KEYS: JSON.stringify({ 1: k(), 2: k() }), ACTIVE_KEY_ID: '1', INDEX_KEY: k(),
    REGISTRATION_OPEN: 'true', SESSION_TTL_DAYS: '14', APP_ORIGIN: '',
    _rooms: rooms, _hubs: hubs, _online: online,
  };
}
