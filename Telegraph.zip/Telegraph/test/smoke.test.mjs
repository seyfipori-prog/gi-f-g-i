import assert from 'node:assert/strict';
import { handleRequest } from '../src/api/router.js';
import { runScheduled, purgeExpired } from '../src/chat/cleanup.js';
import { makeEnv } from './harness.mjs';

const env = makeEnv();
const ORIGIN = 'http://localhost';
let passed = 0;
const ok = (name) => { passed++; console.log('  ok  ', name); };

async function call(method, path, { body, cookie, raw, headers = {}, csrf = true } = {}) {
  const h = new Headers({ origin: ORIGIN, ...headers });
  if (csrf) h.set('x-telegraph-request', '1');
  if (cookie) h.set('cookie', cookie);
  let payload;
  if (raw) payload = raw;
  else if (body !== undefined) { h.set('content-type', 'application/json'); payload = JSON.stringify(body); }
  const ctx = { pending: [], waitUntil(p) { this.pending.push(p); } };
  const req = new Request(ORIGIN + path, { method, headers: h, body: payload, duplex: 'half' });
  const res = await handleRequest(req, env, ctx);
  await Promise.all(ctx.pending);
  let data = null;
  if ((res.headers.get('content-type') || '').includes('json')) data = await res.json();
  return { status: res.status, data, headers: res.headers, res };
}
const cookieOf = (r) => r.headers.get('set-cookie').split(';')[0];

// ---------------------------------------------------------------- auth
let r = await call('POST', '/api/auth/register', { body: { username: 'alice', password: 'correct-horse-1', display_name: 'آلیس' } });
assert.equal(r.status, 201); const alice = cookieOf(r); const aliceId = r.data.user.id;
assert.match(r.headers.get('set-cookie'), /HttpOnly/);
r = await call('POST', '/api/auth/register', { body: { username: 'bob', password: 'correct-horse-2', display_name: 'باب' } });
assert.equal(r.status, 201); const bob = cookieOf(r); const bobId = r.data.user.id;
r = await call('POST', '/api/auth/register', { body: { username: 'eve', password: 'correct-horse-3' } });
const eve = cookieOf(r);
r = await call('POST', '/api/auth/register', { body: { username: 'Alice', password: 'whatever-123' } });
assert.equal(r.status, 409); ok('register + duplicate username');
r = await call('POST', '/api/auth/register', { body: { username: 'x', password: 'short' } });
assert.equal(r.status, 400);
const row = await env.DB.prepare('SELECT password_hash FROM users WHERE username = ?').bind('alice').first();
assert.ok(row.password_hash.startsWith('pbkdf2-sha256$100000$') && !row.password_hash.includes('correct-horse')); ok('password hashed with PBKDF2');
const sess = await env.DB.prepare('SELECT id FROM sessions LIMIT 1').first();
assert.equal(sess.id.length, 64); assert.ok(!alice.includes(sess.id)); ok('session stores token hash only');

r = await call('GET', '/api/me', { cookie: alice }); assert.equal(r.data.user.username, 'alice');
r = await call('GET', '/api/me'); assert.equal(r.status, 401); ok('unauthenticated rejected');
r = await call('POST', '/api/chats', { cookie: alice, body: { title: 'x' }, csrf: false }); assert.equal(r.status, 403, 'csrf header required'); ok('CSRF header enforced');
r = await call('POST', '/api/chats', { cookie: alice, body: { title: 'x' }, headers: { origin: 'https://evil.example' } }); assert.equal(r.status, 403); ok('cross-origin rejected');
r = await call('POST', '/api/auth/login', { body: { username: 'alice', password: 'wrong-password' } }); assert.equal(r.status, 401);
r = await call('POST', '/api/auth/login', { body: { username: 'nobody', password: 'wrong-password' } }); assert.equal(r.status, 401);
r = await call('POST', '/api/auth/login', { body: { username: 'alice', password: 'correct-horse-1' } }); assert.equal(r.status, 200); ok('login');

// ---------------------------------------------------------------- chats + messages
r = await call('POST', '/api/chats', { cookie: alice, body: { title: 'پروژه تلگراف', members: ['bob'] } });
assert.equal(r.status, 201); const chatId = r.data.chat.id; assert.equal(r.data.members.length, 2);
r = await call('POST', '/api/chats', { cookie: alice, body: { title: 'bad', members: ['ghost'] } }); assert.equal(r.status, 404);
r = await call('GET', `/api/chats/${chatId}`, { cookie: eve }); assert.equal(r.status, 404); ok('non-member cannot open chat');

env._online.hub.add(bobId); // bob is online (inbox socket)
r = await call('POST', `/api/chats/${chatId}/messages`, { cookie: alice, body: { body: 'سلام بابا! گزارش مهم است', priority: 'important' } });
assert.equal(r.status, 201); const m1 = r.data.message;
assert.equal(m1.body, 'سلام بابا! گزارش مهم است'); assert.equal(m1.priority, 'important'); assert.equal(m1.status, 'sent');
const raw = await env.DB.prepare('SELECT body FROM messages WHERE id = ?').bind(m1.id).first();
assert.ok(raw.body.startsWith('enc1:1:') && !raw.body.includes('سلام')); ok('message stored encrypted at rest');
assert.ok(env._rooms.some((e) => e.path === '/broadcast' && e.body.payload.type === 'message.new')); ok('message broadcast to chat room');
const push = env._hubs.find((e) => e.name === bobId && e.body.payload.notification);
assert.equal(push.body.payload.notification.priority, 'important'); ok('notification pushed with priority');
const st = await env.DB.prepare('SELECT status FROM message_status WHERE message_id = ? AND user_id = ?').bind(m1.id, bobId).first();
assert.equal(st.status, 'delivered'); ok('delivered state set for online recipient');

r = await call('POST', `/api/chats/${chatId}/messages`, { cookie: eve, body: { body: 'intruder' } }); assert.equal(r.status, 404);
r = await call('POST', `/api/chats/${chatId}/messages`, { cookie: alice, body: { body: '' } }); assert.equal(r.status, 400);
r = await call('POST', `/api/chats/${chatId}/messages`, { cookie: alice, body: { body: 'x', priority: 'purple' } }); assert.equal(r.status, 400); ok('validation');
r = await call('POST', `/api/chats/${chatId}/messages`, { cookie: alice, body: { body: '<img src=x onerror=alert(1)>' } });
assert.equal(r.data.message.body, '<img src=x onerror=alert(1)>'); // stored verbatim; the UI renders with textContent

// reply
r = await call('POST', `/api/messages/${m1.id}/reply`, { cookie: bob, body: { body: 'دریافت شد' } });
assert.equal(r.status, 201); assert.equal(r.data.message.reply_to.id, m1.id); assert.equal(r.data.message.reply_to.sender_name, 'آلیس'); ok('reply');
const m2 = r.data.message;

// priority: only own message
r = await call('PATCH', `/api/messages/${m1.id}/priority`, { cookie: bob, body: { priority: 'critical' } }); assert.equal(r.status, 403);
r = await call('PATCH', `/api/messages/${m1.id}/priority`, { cookie: alice, body: { priority: 'critical' } });
assert.equal(r.data.message.priority, 'critical');
const nt = await env.DB.prepare('SELECT type FROM notifications WHERE message_id = ?').bind(m1.id).first();
assert.equal(nt.type, 'critical'); ok('priority change (own only) updates message + notification');

// edit / delete authorisation
r = await call('PATCH', `/api/messages/${m1.id}`, { cookie: bob, body: { body: 'hijack' } }); assert.equal(r.status, 403);
r = await call('PATCH', `/api/messages/${m1.id}`, { cookie: alice, body: { body: 'سلام ویرایش‌شده گزارش' } });
assert.ok(r.data.message.edited_at); ok('edit');

// search
r = await call('GET', '/api/search?q=' + encodeURIComponent('گزارش'), { cookie: bob });
assert.equal(r.data.results.length, 1); assert.equal(r.data.results[0].id, m1.id);
r = await call('GET', '/api/search?q=' + encodeURIComponent('گزارش') + '&priority=good', { cookie: bob }); assert.equal(r.data.results.length, 0);
r = await call('GET', '/api/search?priority=critical', { cookie: bob }); assert.equal(r.data.results.length, 1);
r = await call('GET', '/api/search?q=' + encodeURIComponent('گزارش'), { cookie: eve }); assert.equal(r.data.results.length, 0); ok('blind-index search + priority filter + isolation');
r = await call('GET', '/api/search?q=' + encodeURIComponent('بابا'), { cookie: bob });
assert.equal(r.data.results.length, 0, 'edited message re-indexed (old word gone)'); ok('search index updated on edit');

// pin
r = await call('POST', `/api/messages/${m1.id}/pin`, { cookie: bob }); assert.equal(r.data.pinned, true);
r = await call('GET', `/api/chats/${chatId}`, { cookie: alice }); assert.equal(r.data.pinned.length, 1);
r = await call('POST', `/api/messages/${m1.id}/pin`, { cookie: bob }); assert.equal(r.data.pinned, false); ok('pin toggle');

// pagination
for (let i = 0; i < 35; i++) await call('POST', `/api/chats/${chatId}/messages`, { cookie: alice, body: { body: `پیام شماره ${i}` } });
r = await call('GET', `/api/chats/${chatId}/messages?limit=20`, { cookie: bob });
assert.equal(r.data.messages.length, 20); assert.equal(r.data.has_more, true);
const seqs = r.data.messages.map((m) => m.seq); assert.deepEqual(seqs, [...seqs].sort((a, b) => a - b));
r = await call('GET', `/api/chats/${chatId}/messages?limit=20&before=${r.data.next_before}`, { cookie: bob });
assert.equal(r.data.messages.length, 18); ok('pagination (cursor)');

// read receipts
r = await call('POST', `/api/chats/${chatId}/read`, { cookie: bob }); assert.ok(r.data.updated > 0);
r = await call('GET', `/api/chats/${chatId}/messages?limit=5`, { cookie: alice });
assert.ok(r.data.messages.filter((m) => m.sender.id === aliceId).every((m) => m.status === 'read')); ok('read state');
r = await call('GET', '/api/chats', { cookie: bob }); assert.equal(r.data.chats[0].unread, 0); assert.ok(r.data.chats[0].last_message.preview);
r = await call('GET', '/api/chats?q=' + encodeURIComponent('تلگراف'), { cookie: bob }); assert.equal(r.data.chats.length, 1); ok('chat list + unread + title search');

// ---------------------------------------------------------------- expiry (server enforced)
r = await call('POST', `/api/chats/${chatId}/messages`, { cookie: alice, body: { body: 'این پیام می‌سوزد', ttl_seconds: 30 } });
const burn = r.data.message; assert.ok(burn.expires_at > Date.now());
assert.ok(env._rooms.some((e) => e.path === '/schedule')); ok('expiry scheduled on room');
r = await call('POST', `/api/chats/${chatId}/messages`, { cookie: alice, body: { body: 'x', ttl_seconds: 1 } }); assert.equal(r.status, 400);
await env.DB.prepare('UPDATE messages SET expires_at = ? WHERE id = ?').bind(Date.now() - 1000, burn.id).run();
r = await call('GET', `/api/chats/${chatId}/messages?limit=50`, { cookie: bob });
assert.ok(!r.data.messages.some((m) => m.id === burn.id)); ok('expired message hidden by API (before purge)');
r = await call('GET', '/api/search?q=' + encodeURIComponent('می‌سوزد'), { cookie: bob }); assert.equal(r.data.results.length, 0);
r = await call('PATCH', `/api/messages/${burn.id}/priority`, { cookie: alice, body: { priority: 'good' } }); assert.equal(r.status, 404); ok('expired message not accessible');
const purged = await purgeExpired(env); assert.equal(purged.length, 1);
assert.equal(await env.DB.prepare('SELECT 1 FROM messages WHERE id = ?').bind(burn.id).first(), null); ok('purge removes row');

// ---------------------------------------------------------------- files
const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(2000, 7)]);
const up = (bytes, type, name, who = alice, extra = '') => call('POST', `/api/files?chat=${chatId}&name=${encodeURIComponent(name)}${extra}`,
  { cookie: who, raw: bytes, headers: { 'content-type': type, 'content-length': String(bytes.length) } });
r = await up(png, 'image/png', '../../etc/passwd.png');
assert.equal(r.status, 201); const att = r.data.attachment; assert.equal(att.filename, 'passwd.png'); assert.equal(att.category, 'image'); ok('upload + filename sanitised (path traversal)');
const keyRow = await env.DB.prepare('SELECT r2_key, filename FROM attachments WHERE id = ?').bind(att.id).first();
assert.match(keyRow.r2_key, new RegExp(`^chats/${chatId}/${aliceId}/[0-9a-f-]{36}$`)); assert.ok(keyRow.filename.startsWith('enc1:')); ok('safe R2 key + encrypted filename');
r = await up(Buffer.from('<html><script>alert(1)</script></html>'), 'text/html', 'x.html'); assert.equal(r.status, 415);
r = await up(Buffer.from('<svg onload=alert(1)>'), 'image/svg+xml', 'x.svg'); assert.equal(r.status, 415);
r = await up(Buffer.from('MZ\x90\x00 exe'), 'image/png', 'evil.png'); assert.equal(r.status, 415); assert.equal(r.data.error.code, 'content_mismatch'); ok('MIME allow-list + magic-number check');
const before = env.FILES.objects.size;
r = await up(Buffer.alloc(100, 0), 'text/plain', 'bin.txt'); assert.equal(r.status, 415); assert.equal(env.FILES.objects.size, before, 'rejected upload leaves nothing in R2');
r = await call('POST', `/api/files?chat=${chatId}&name=a.png`, { cookie: alice, raw: png, headers: { 'content-type': 'image/png' } }); assert.ok([411, 201].includes(r.status));
const big = { length: 16 * 1024 * 1024 };
r = await call('POST', `/api/files?chat=${chatId}&name=a.png`, { cookie: alice, raw: png, headers: { 'content-type': 'image/png', 'content-length': String(big.length) } }); assert.equal(r.status, 413); ok('size limit');
r = await up(png, 'image/png', 'x.png', eve); assert.equal(r.status, 404); ok('non-member cannot upload');

r = await call('GET', `/api/files/${att.id}`, { cookie: bob }); assert.equal(r.status, 404, 'unsent upload visible to uploader only');
r = await call('GET', `/api/files/${att.id}`, { cookie: alice }); assert.equal(r.status, 200);
r = await call('POST', `/api/chats/${chatId}/messages`, { cookie: alice, body: { body: 'تصویر پیوست', attachment_ids: [att.id] } });
assert.equal(r.status, 201); const fm = r.data.message; assert.equal(fm.kind, 'file'); assert.equal(fm.attachments[0].filename, 'passwd.png'); ok('attachment linked to message');
r = await call('POST', `/api/chats/${chatId}/messages`, { cookie: alice, body: { body: 'again', attachment_ids: [att.id] } }); assert.equal(r.status, 400); ok('attachment cannot be reused');
r = await call('GET', `/api/files/${att.id}`, { cookie: bob });
assert.equal(r.status, 200); assert.equal(r.headers.get('content-type'), 'image/png'); assert.match(r.headers.get('content-disposition'), /^inline/);
assert.equal(r.headers.get('x-content-type-options'), 'nosniff'); assert.match(r.headers.get('content-security-policy'), /sandbox/);
assert.equal((await r.res.arrayBuffer()).byteLength, png.length); ok('authorised download');
r = await call('GET', `/api/files/${att.id}`, { cookie: eve }); assert.equal(r.status, 404);
r = await call('GET', `/api/files/${att.id}`); assert.equal(r.status, 401); ok('file authorization (non-member / anonymous)');
r = await call('GET', `/api/files/${att.id}`, { cookie: bob, headers: { range: 'bytes=0-9' } }); assert.equal(r.status, 206); assert.equal(r.headers.get('content-range'), `bytes 0-9/${png.length}`); ok('range requests');
r = await call('GET', '/api/search?q=passwd&scope=files', { cookie: bob }); assert.equal(r.data.results.length, 1); ok('attachment filename search');

const webm = Buffer.concat([Buffer.from([0x1a, 0x45, 0xdf, 0xa3]), Buffer.alloc(500, 1)]);
r = await up(webm, 'audio/webm;codecs=opus', 'voice.webm', alice, '&voice=1&duration=4200'); assert.equal(r.status, 201);
r = await call('POST', `/api/chats/${chatId}/messages`, { cookie: alice, body: { attachment_ids: [r.data.attachment.id] } });
assert.equal(r.data.message.kind, 'voice'); assert.equal(r.data.message.attachments[0].duration_ms, 4200); ok('voice message');

// deleting a message removes its R2 object
const objBefore = env.FILES.objects.size;
r = await call('DELETE', `/api/messages/${fm.id}`, { cookie: bob }); assert.equal(r.status, 403);
r = await call('DELETE', `/api/messages/${fm.id}`, { cookie: alice }); assert.equal(r.status, 200);
assert.equal(env.FILES.objects.size, objBefore - 1);
r = await call('GET', `/api/chats/${chatId}/messages?limit=50`, { cookie: bob });
const tomb = r.data.messages.find((m) => m.id === fm.id); assert.ok(tomb.deleted && tomb.body === null && tomb.attachments.length === 0); ok('delete -> tombstone + R2 object removed');

// orphan cleanup
r = await up(png, 'image/png', 'orphan.png'); const orphanId = r.data.attachment.id;
await env.DB.prepare('UPDATE attachments SET created_at = ? WHERE id = ?').bind(Date.now() - 2 * 3600e3, orphanId).run();
const n0 = env.FILES.objects.size; await runScheduled(env); assert.equal(env.FILES.objects.size, n0 - 1); ok('cron removes orphan uploads');

// ---------------------------------------------------------------- notifications
r = await call('GET', '/api/notifications?unread=1', { cookie: bob }); assert.ok(r.data.unread_count > 0);
const nid = r.data.notifications[0].id; assert.ok(['normal', 'good', 'important', 'critical'].includes(r.data.notifications[0].priority));
r = await call('PATCH', `/api/notifications/${nid}/read`, { cookie: alice }); assert.equal(r.status, 404);
r = await call('PATCH', `/api/notifications/${nid}/read`, { cookie: bob }); assert.equal(r.status, 200); ok('notifications');

// ---------------------------------------------------------------- members / rate limit / headers / logout
r = await call('POST', `/api/chats/${chatId}/members`, { cookie: bob, body: { username: 'eve' } }); assert.equal(r.status, 403);
r = await call('POST', `/api/chats/${chatId}/members`, { cookie: alice, body: { username: 'eve' } }); assert.equal(r.status, 201);
r = await call('GET', `/api/chats/${chatId}`, { cookie: eve }); assert.equal(r.status, 200);
r = await call('DELETE', `/api/chats/${chatId}/members/${(await env.DB.prepare("SELECT id FROM users WHERE username='eve'").first()).id}`, { cookie: alice });
r = await call('GET', `/api/chats/${chatId}`, { cookie: eve }); assert.equal(r.status, 404); ok('member add/remove (owner only)');

r = await call('GET', '/api/me', { cookie: alice });
for (const h of ['content-security-policy', 'x-content-type-options', 'x-frame-options', 'referrer-policy']) assert.ok(r.headers.get(h), h);
assert.match(r.headers.get('content-security-policy'), /script-src 'self'/); ok('security headers');

for (let i = 0; i < 10; i++) r = await call('POST', '/api/auth/login', { body: { username: 'bob', password: 'nope-nope-nope' } });
assert.equal(r.status, 429); assert.ok(r.headers.get('retry-after')); ok('login rate limiting');

r = await call('POST', '/api/auth/logout', { cookie: alice }); assert.equal(r.status, 200);
r = await call('GET', '/api/me', { cookie: alice }); assert.equal(r.status, 401); ok('logout invalidates session');
await env.DB.prepare('UPDATE sessions SET expires_at = ?').bind(Date.now() - 1).run();
r = await call('GET', '/api/me', { cookie: bob }); assert.equal(r.status, 401); ok('session expiry');

// chat deletion (owner) cascades and removes files
r = await call('POST', '/api/auth/login', { body: { username: 'alice', password: 'correct-horse-1' } });
// (login limiter for alice unaffected)
const alice2 = cookieOf(r);
r = await call('DELETE', `/api/chats/${chatId}`, { cookie: alice2 }); assert.equal(r.data.deleted, true);
assert.equal(env.FILES.objects.size, 0);
assert.equal((await env.DB.prepare('SELECT COUNT(*) n FROM messages').first()).n, 0); ok('chat delete cascades (D1 + R2)');

r = await call('GET', '/api/nope', { cookie: alice2 }); assert.equal(r.status, 404);
r = await call('GET', '/'); assert.equal(r.status, 200); assert.ok(r.headers.get('content-security-policy')); ok('UI served with security headers');

console.log(`\n${passed} checks passed`);
